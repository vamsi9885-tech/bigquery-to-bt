package com.optum.dap.api.dto;

import org.junit.jupiter.api.Test;
import com.optum.dap.api.dto.ClientsDetailsDto;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

public class ClientsDetailsDtoTest {

    @Test
    public void testIsActiveGetterSetter() {
        ClientsDetailsDto dto = new ClientsDetailsDto();

        dto.setActive(true);
        assertTrue(dto.isActive(), "Expected isActive to return true");

        dto.setActive(false);
        assertFalse(dto.isActive(), "Expected isActive to return false");
    }
}
