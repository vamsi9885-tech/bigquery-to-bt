package com.optum.dap.api.repository;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.optum.dap.api.model.RuntimeSettings;
import com.optum.dap.api.model.RuntimeSettingConfig;

/**
 * Unit tests for IRuntimeSettingsRepository.
 * Uses Mockito for pure unit testing without database interaction.
 */
@ExtendWith(MockitoExtension.class)
public class IRuntimeSettingsRepositoryTest {

    @Mock
    private IRuntimeSettingsRepository runtimeSettingsRepository;

    private UUID feedIdentifier;
    private UUID runTimeConfigId;
    private RuntimeSettings testSettings;

    @BeforeEach
    public void setup() {
        // Initialize test data
        feedIdentifier = UUID.randomUUID();
        runTimeConfigId = UUID.randomUUID();
        
        // Create a sample RuntimeSettings entity for testing
        testSettings = RuntimeSettings.builder()
            .runTimeConfigId(runTimeConfigId)
            .feedIdentifier(feedIdentifier)
            .isAdhocRun(false)
            .extractionType("PERIODIC")
            .splitBy(1)
            .adhocStartDate(LocalDate.now())
            .adhocEndDate(LocalDate.now().plusDays(7))
            .periodicStartDate(LocalDateTime.now().plusDays(14))
            .lagOffset(2)
            .lagTolerance(1)
            .enableRunStatusNotification(true)
            .notifyType("STANDARD")
            .runtimeSettingConfig(new RuntimeSettingConfig())
            .build();
    }

    @Test
    @DisplayName("Should find RuntimeSettings by feed identifier")
    public void testFindByFeedIdentifier() {
        // Given
        when(runtimeSettingsRepository.findByFeedIdentifier(feedIdentifier)).thenReturn(Optional.of(testSettings));
        
        // When
        Optional<RuntimeSettings> foundSettings = runtimeSettingsRepository.findByFeedIdentifier(feedIdentifier);
        
        // Then
        assertTrue(foundSettings.isPresent());
        assertEquals(runTimeConfigId, foundSettings.get().getRunTimeConfigId());
        assertEquals(feedIdentifier, foundSettings.get().getFeedIdentifier());
        assertEquals(false, foundSettings.get().isAdhocRun());
        assertEquals("PERIODIC", foundSettings.get().getExtractionType());
        
        // Verify that the method was called exactly once with the correct parameter
        verify(runtimeSettingsRepository, times(1)).findByFeedIdentifier(feedIdentifier);
    }

    @Test
    @DisplayName("Should return empty when feed identifier does not exist")
    public void testFindByFeedIdentifier_NotFound() {
        // Given
        UUID nonExistentId = UUID.randomUUID();
        when(runtimeSettingsRepository.findByFeedIdentifier(nonExistentId)).thenReturn(Optional.empty());
        
        // When
        Optional<RuntimeSettings> foundSettings = runtimeSettingsRepository.findByFeedIdentifier(nonExistentId);
        
        // Then
        assertFalse(foundSettings.isPresent());
        
        // Verify that the method was called exactly once with the correct parameter
        verify(runtimeSettingsRepository, times(1)).findByFeedIdentifier(nonExistentId);
    }

    @Test
    @DisplayName("Should save and find by ID")
    public void testSaveAndFindById() {
        // Given
        RuntimeSettings newSettings = RuntimeSettings.builder()
            .runTimeConfigId(runTimeConfigId)
            .feedIdentifier(feedIdentifier)
            .isAdhocRun(true)
            .extractionType("ADHOC")
            .build();
            
        when(runtimeSettingsRepository.save(newSettings)).thenReturn(newSettings);
        when(runtimeSettingsRepository.findById(runTimeConfigId)).thenReturn(Optional.of(newSettings));
        
        // When
        runtimeSettingsRepository.save(newSettings);
        Optional<RuntimeSettings> foundById = runtimeSettingsRepository.findById(runTimeConfigId);
        
        // Then
        assertTrue(foundById.isPresent());
        assertEquals(runTimeConfigId, foundById.get().getRunTimeConfigId());
        assertEquals(feedIdentifier, foundById.get().getFeedIdentifier());
        assertEquals(true, foundById.get().isAdhocRun());
        assertEquals("ADHOC", foundById.get().getExtractionType());
        
        // Verify that the methods were called with the correct parameters
        verify(runtimeSettingsRepository, times(1)).save(newSettings);
        verify(runtimeSettingsRepository, times(1)).findById(runTimeConfigId);
    }

    @Test
    @DisplayName("Should update existing runtime settings")
    public void testUpdateRuntimeSettings() {
        // Given
        RuntimeSettings updatedSettings = RuntimeSettings.builder()
            .runTimeConfigId(runTimeConfigId)
            .feedIdentifier(feedIdentifier)
            .isAdhocRun(false)
            .extractionType("PERIODIC")
            .lagOffset(5)
            .lagTolerance(2)
            .enableRunStatusNotification(false)
            .build();
            
        when(runtimeSettingsRepository.findById(runTimeConfigId)).thenReturn(Optional.of(testSettings), Optional.of(updatedSettings));
        when(runtimeSettingsRepository.save(any(RuntimeSettings.class))).thenReturn(updatedSettings);
        
        // When
        Optional<RuntimeSettings> settingsToUpdate = runtimeSettingsRepository.findById(runTimeConfigId);
        assertTrue(settingsToUpdate.isPresent());
        
        // Update fields
        RuntimeSettings settings = settingsToUpdate.get();
        settings.setLagOffset(5);
        settings.setLagTolerance(2);
        settings.setEnableRunStatusNotification(false);
        
        runtimeSettingsRepository.save(settings);
        Optional<RuntimeSettings> found = runtimeSettingsRepository.findById(runTimeConfigId);
        
        // Then
        assertTrue(found.isPresent());
        assertEquals(Integer.valueOf(5), found.get().getLagOffset());
        assertEquals(Integer.valueOf(2), found.get().getLagTolerance());
        assertEquals(Boolean.FALSE, found.get().getEnableRunStatusNotification());
        
        // Verify that the methods were called with the correct parameters
        verify(runtimeSettingsRepository, times(2)).findById(runTimeConfigId);
        verify(runtimeSettingsRepository, times(1)).save(any(RuntimeSettings.class));
    }

    @Test
    @DisplayName("Should delete runtime settings")
    public void testDeleteRuntimeSettings() {
        // Given
        doNothing().when(runtimeSettingsRepository).deleteById(runTimeConfigId);
        when(runtimeSettingsRepository.findById(runTimeConfigId)).thenReturn(Optional.empty());
        
        // When
        runtimeSettingsRepository.deleteById(runTimeConfigId);
        Optional<RuntimeSettings> found = runtimeSettingsRepository.findById(runTimeConfigId);
        
        // Then
        assertFalse(found.isPresent());
        
        // Verify that the methods were called with the correct parameters
        verify(runtimeSettingsRepository, times(1)).deleteById(runTimeConfigId);
        verify(runtimeSettingsRepository, times(1)).findById(runTimeConfigId);
    }

    @Test
    @DisplayName("Should find all runtime settings")
    public void testFindAll() {
        // Given
        UUID newRunTimeConfigId = UUID.randomUUID();
        UUID newFeedIdentifier = UUID.randomUUID();
        
        RuntimeSettings newSettings = RuntimeSettings.builder()
            .runTimeConfigId(newRunTimeConfigId)
            .feedIdentifier(newFeedIdentifier)
            .isAdhocRun(true)
            .build();
            
        List<RuntimeSettings> settingsList = Arrays.asList(testSettings, newSettings);
        when(runtimeSettingsRepository.findAll()).thenReturn(settingsList);
        
        // When
        List<RuntimeSettings> allSettings = runtimeSettingsRepository.findAll();
        
        // Then
        assertNotNull(allSettings);
        assertEquals(2, allSettings.size());
        
        // Verify that the method was called exactly once
        verify(runtimeSettingsRepository, times(1)).findAll();
    }
}