package com.optum.dap.api.service.impl;

import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigDto;
import com.optum.dap.api.dto.ExtractionSettingsDto;
import com.optum.dap.api.dto.FeedConfigUpdateRequestDto;
import com.optum.dap.api.dto.FeedResponseDto;
import com.optum.dap.api.exception.BadRequestException;
import com.optum.dap.api.exception.RecordAlreadyExistException;
import com.optum.dap.api.dto.FileTransferSettingsDto;
import com.optum.dap.api.exception.RecordNotFoundException;
import com.optum.dap.api.model.Clients;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.repository.ClientsRepository;
import com.optum.dap.api.repository.FeedsRepository;
import com.optum.dap.api.transformer.FeedConfigTransformer;
import com.optum.dap.api.service.IAuditService;
import com.optum.dap.api.validation.FeedConfigValidator;
import com.optum.dap.api.utils.DeepCopyUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class FeedServiceImplTest {
    @Mock
    private FeedsRepository feedsRepository;
    @Mock
    private ClientsRepository clientsRepository;
    @Mock
    private IAuditService auditService;

    @Mock
    private FeedConfigTransformer feedConfigTransformer;
    
    @Mock
    private DeepCopyUtil deepCopyUtil;
    @Mock
    private FeedConfigValidator feedConfigValidator;
    @InjectMocks
    private FeedServiceImpl service;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Setup default behavior for deepCopyUtil
        when(deepCopyUtil.deepCopy(any(), any(Class.class))).thenAnswer(invocation -> invocation.getArgument(0));
    }
   

    @Test
    @DisplayName("createFeedConfig throws RecordAlreadyExistException if feed exists")
    void createFeedConfig_duplicateFeedName() {
        FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
        dto.setFeedName("feedA");
        dto.setFeedType(FeedType.PULL);
        dto.setIsActive(true);
        dto.setStatus(FeedStatus.PENDING);
        dto.setFrequencyId(1);
        dto.setConnectorType("SFTP");
        dto.setConnectorVersion("1.0");
        dto.setFeedConfig(new FeedConfigDto());
        when(clientsRepository.findById("client01")).thenReturn(Optional.of(new Clients()));
        doThrow(new RecordAlreadyExistException("Feed with name feedA already exists for client client01"))
            .when(feedConfigValidator).validateCreateRequest(dto, "client01");
        assertThatThrownBy(() -> service.createFeedConfig("client01", dto))
                .isInstanceOf(RecordAlreadyExistException.class);
    }

    @Test
    @DisplayName("createFeedConfig throws BadRequestException if fileTransferSettings provided for PUSH")
    void createFeedConfig_fileTransferSettingsForPush() {
        FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
        dto.setFeedName("feedB");
        dto.setFeedType(FeedType.PUSH);
        dto.setIsActive(true);
        dto.setStatus(FeedStatus.PENDING);
        dto.setFrequencyId(1);
        dto.setConnectorType("SFTP");
        dto.setConnectorVersion("1.0");
        FeedConfigDto feedConfigDto = new FeedConfigDto();
        feedConfigDto.setFileTransferSettings(new FileTransferSettingsDto());
        dto.setFeedConfig(feedConfigDto);
        when(clientsRepository.findById("client01")).thenReturn(Optional.of(new Clients()));
        doThrow(new BadRequestException("fileTransferSettings is not required for feed type PUSH"))
            .when(feedConfigValidator).validateCreateRequest(dto, "client01");
        assertThatThrownBy(() -> service.createFeedConfig("client01", dto))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("fileTransferSettings is not required for feed type PUSH");
    }

    @Test
    @DisplayName("updateFeedConfig throws RecordNotFoundException if feed does not belong to client")
    void updateFeedConfig_feedNotBelongToClient() {
        FeedConfigUpdateRequestDto dto = new FeedConfigUpdateRequestDto();
        dto.setFeedName("feedC");
        dto.setFeedType(FeedType.PULL);
        dto.setIsActive(true);
        dto.setStatus(FeedStatus.PENDING);
        dto.setFrequencyId(1);
        dto.setConnectorType("SFTP");
        dto.setConnectorVersion("1.0");
        dto.setFeedConfig(new FeedConfigDto());
        Clients client = new Clients();
        client.setClientId("client01");
        Feeds feed = new Feeds();
        feed.setClient(null); // Simulate feed not belonging to client
        when(clientsRepository.findById("client01")).thenReturn(Optional.of(client));
        when(feedsRepository.findById(any())).thenReturn(Optional.of(feed));
        assertThatThrownBy(() -> service.updateFeedConfig("client01", UUID.randomUUID().toString(), dto))
                .isInstanceOf(RecordNotFoundException.class)
                .hasMessageContaining("Feed does not belong to the specified client");
    }

    @Test
    @DisplayName("updateFeedConfig throws BadRequestException if feed is ACTIVE")
    void updateFeedConfig_feedIsActive() {
        FeedConfigUpdateRequestDto dto = new FeedConfigUpdateRequestDto();
        dto.setFeedName("feedD");
        dto.setFeedType(FeedType.PULL);
        dto.setIsActive(true);
        dto.setStatus(FeedStatus.PENDING);
        dto.setFrequencyId(1);
        dto.setConnectorType("SFTP");
        dto.setConnectorVersion("1.0");
        dto.setFeedConfig(new FeedConfigDto());
        Clients client = new Clients();
        client.setClientId("client01");
        Feeds feed = new Feeds();
        feed.setClient(client);
        feed.setStatus(FeedStatus.ACTIVE);
        when(clientsRepository.findById("client01")).thenReturn(Optional.of(client));
        when(feedsRepository.findById(any())).thenReturn(Optional.of(feed));
        doThrow(new BadRequestException("Feed is in Active mode and cannot be updated"))
            .when(feedConfigValidator).validateUpdateRequest(dto, feed);
        assertThatThrownBy(() -> service.updateFeedConfig("client01", UUID.randomUUID().toString(), dto))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("Feed is in Active mode and cannot be updated");
    }

    @Test
    @DisplayName("createFeedConfig success path")
    void createFeedConfig_success() {
        FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
        dto.setFeedName("feedE");
        dto.setFeedType(FeedType.PULL);
        dto.setIsActive(true);
        dto.setStatus(FeedStatus.PENDING);
        dto.setFrequencyId(1);
        dto.setConnectorType("SFTP");
        dto.setConnectorVersion("1.0");
        FeedConfigDto feedConfigDto = new FeedConfigDto();
        feedConfigDto.setExtractionSettings(new ExtractionSettingsDto());
        dto.setFeedConfig(feedConfigDto);
        Clients client = new Clients();
        client.setClientId("client01");
        
        Feeds feed = new Feeds();
        feed.setFeedIdentifier(UUID.randomUUID()); // Set a valid identifier
        
        when(clientsRepository.findById("client01")).thenReturn(Optional.of(client));
        when(feedConfigTransformer.toEntity(eq(dto), eq(client))).thenReturn(feed);
        when(feedsRepository.save(any(Feeds.class))).thenReturn(feed);
        when(feedConfigTransformer.toResponseDto(feed)).thenReturn(new FeedResponseDto());
        
        FeedResponseDto response = service.createFeedConfig("client01", dto);
        
        assertThat(response).isNotNull();
        verify(feedsRepository).save(any(Feeds.class));
    }
}
