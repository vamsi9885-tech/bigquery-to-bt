package com.optum.dap.api.service;

import com.optum.dap.api.dto.ClientsDetailsDto;
import com.optum.dap.api.dto.ClientsResponseDto;
import com.optum.dap.api.model.Clients;
import com.optum.dap.api.service.impl.ClientsServiceImpl;
import com.optum.dap.api.projection.IClientsProjection;
import com.optum.dap.api.repository.ClientsRepository;
import com.optum.dap.api.transformer.ClientDetailsTransformer;
import com.optum.dap.api.service.IAuditService;
import com.optum.dap.api.utils.DeepCopyUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Optional;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.optum.dap.api.dto.ClientRequestDto;
import com.optum.dap.api.exception.RecordNotFoundException;
import com.optum.dap.api.exception.RecordAlreadyExistException;

/**
 * Unit tests for ClientsService.
 */
class ClientsServiceTest {
    @Mock
    private ClientsRepository clientsRepository;

    @Mock
    private ClientDetailsTransformer clientDetailsTransformer;
    @Mock
    private IAuditService auditService;
    
    @Mock
    private DeepCopyUtil deepCopyUtil;

    @InjectMocks
    private ClientsServiceImpl clientsService;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("getAllClients returns list of DTOs")
    void testGetAllClients() {
        IClientsProjection projection = mock(IClientsProjection.class);
        ClientsDetailsDto dto = new ClientsDetailsDto();
        List<IClientsProjection> projections = Arrays.asList(projection);
        List<ClientsDetailsDto> dtos = Arrays.asList(dto);
        when(clientsRepository.findAllProjectedBy()).thenReturn(projections);
        when(clientDetailsTransformer.toClientsDetailsDtoList(projections)).thenReturn(dtos);
        List<ClientsDetailsDto> result = clientsService.getAllClients();
        assertThat(result).hasSize(1);
        assertThat(result.get(0)).isEqualTo(dto);
    }

    @Test
    @DisplayName("getClientDetailsById returns DTO when found")
    void testGetClientDetailsById_Success() {
        Clients client = new Clients();
        ClientsResponseDto dto = new ClientsResponseDto();
        when(clientsRepository.findById("1")).thenReturn(Optional.of(client));
        when(clientDetailsTransformer.toClientsResponseDto(client)).thenReturn(dto); // FIXED
        ClientsResponseDto result = clientsService.getClientDetailsById("1");
        assertThat(result).isEqualTo(dto);
    }

    @Test
    @DisplayName("getClientDetailsById throws when not found")
    void testGetClientDetailsById_NotFound() {
        when(clientsRepository.findById("1")).thenReturn(Optional.empty());
        assertThrows(RecordNotFoundException.class, () -> clientsService.getClientDetailsById("1"));
    }

    @Test
    @DisplayName("createClient saves new client")
    void testCreateClient_Success() {
        ClientRequestDto dto = new ClientRequestDto();
        dto.setClientId("1");
        dto.setClientName("Test Client");
        dto.setActive(true);
        Clients client = new Clients();
        when(clientsRepository.existsById("1")).thenReturn(false);
        when(clientDetailsTransformer.toClientsEntity(dto)).thenReturn(client);
        clientsService.createClient(dto);
        verify(clientsRepository).save(any(Clients.class));
    }

    @Test
    @DisplayName("createClient throws if client exists")
    void testCreateClient_Exists() {
        ClientRequestDto dto = new ClientRequestDto();
        dto.setClientId("1");
        dto.setClientName("Test Client");
        dto.setActive(true);
        when(clientsRepository.existsById("1")).thenReturn(true);
        assertThrows(RecordAlreadyExistException.class, () -> clientsService.createClient(dto));
    }

    @Test
    @DisplayName("updateClient updates existing client")
    void testUpdateClient_Success() {
        ClientRequestDto dto = new ClientRequestDto();
        dto.setClientId("1");
        dto.setClientName("Test Client");
        dto.setActive(true);
        Clients client = new Clients();
        when(clientsRepository.findById("1")).thenReturn(Optional.of(client));
        when(deepCopyUtil.deepCopy(any(), any())).thenReturn(client);
        clientsService.updateClient("1", dto);
        verify(clientsRepository).save(client);
    }

    @Test
    @DisplayName("updateClient throws if not found")
    void testUpdateClient_NotFound() {
        ClientRequestDto dto = new ClientRequestDto();
        dto.setClientId("1");
        dto.setActive(true);    
        when(clientsRepository.findById("1")).thenReturn(Optional.empty());
        assertThrows(RecordNotFoundException.class, () -> clientsService.updateClient("1", dto));
    }
}