package com.optum.dap.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.dap.api.config.JwtTokenProvider;
import com.optum.dap.api.constants.Constant;
import com.optum.dap.api.dto.ConnectionSettingsDto;
import com.optum.dap.api.dto.ExtractionSettingsDto;
import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigDto;
import com.optum.dap.api.dto.FeedConfigUpdateRequestDto;
import com.optum.dap.api.dto.FeedResponseDto;
import com.optum.dap.api.service.IFeedService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Unit tests for FeedController.
 * Tests all endpoints and verifies correct response handling.
 */
@WebMvcTest(FeedController.class)
class FeedControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private IFeedService feedService;
    @MockBean
    private JwtTokenProvider jwtTokenProvider;
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser
    @DisplayName("POST /api/clients/{clientId}/feeds - success")
    void createFeedConfig_success() throws Exception {
        FeedConfigCreateRequestDto requestDto = new FeedConfigCreateRequestDto();
        requestDto.setFeedName("testteed");
        requestDto.setFeedType(Constant.FeedType.PULL);
        requestDto.setIsActive(true);
        requestDto.setStatus(Constant.FeedStatus.PENDING);
        requestDto.setConnectorType("SFTP");
        requestDto.setConnectorVersion("1.0");
        requestDto.setFrequencyId(1);

        FeedConfigDto feedConfigDto = new FeedConfigDto();
        ExtractionSettingsDto extractionSettings = new ExtractionSettingsDto();
        extractionSettings.setRollingDate(0);
        extractionSettings.setFileNameFormat("file.csv");
        extractionSettings.setRowDelimiter(Constant.RowDelimiter.LF);
        extractionSettings.setColumnDelimiter(",");
        extractionSettings.setQuote(false);
        extractionSettings.setStorageBasePath("/tmp");
        extractionSettings.setFilter("m==1");
        feedConfigDto.setExtractionSettings(extractionSettings);

        ConnectionSettingsDto connectionSettings = new ConnectionSettingsDto();
        connectionSettings.setType(Constant.ConnectionType.MSSQL);
        connectionSettings.setConnectionString("jdbc:test");
        connectionSettings.setNtfsFolderPath("/ntfs");
        feedConfigDto.setConnectionSettings(connectionSettings);
        feedConfigDto.setFileTransferSettings(null);
        requestDto.setFeedConfig(feedConfigDto);

        FeedResponseDto responseDto = new FeedResponseDto();
        responseDto.setFeedName("testteed");
      //  responseDto.setFeedIdentifier(UUID.randomUUID().toString());
        responseDto.setFeedType(Constant.FeedType.PULL);
        responseDto.setStatus(Constant.FeedStatus.PENDING);
        Mockito.when(feedService.createFeedConfig(eq("client01"), any())).thenReturn(responseDto);
         mockMvc.perform(post("/api/clients/client01/feeds")
            .with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf())
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(requestDto)))
            .andExpect(status().isOk())
            .andReturn();
    }

    @Test
    @WithMockUser
    @DisplayName("PUT /api/clients/{clientId}/feeds/{feedIdentifier} - success")
    void updateFeedConfig_success() throws Exception {
        FeedConfigUpdateRequestDto requestDto = new FeedConfigUpdateRequestDto();
        requestDto.setFeedIdentifier("a3f1d7c2-8eab-4e4f-bb3e-9c7f6a5d28b1");
        requestDto.setFeedName("testfeed");
        requestDto.setFeedType(Constant.FeedType.PULL);
        requestDto.setIsActive(true);
        requestDto.setStatus(Constant.FeedStatus.PENDING);
        requestDto.setConnectorType("SFTP");
        requestDto.setConnectorVersion("1.0");
        requestDto.setFrequencyId(1);

        FeedConfigDto feedConfigDto = new FeedConfigDto();
        ExtractionSettingsDto extractionSettings = new ExtractionSettingsDto();
        extractionSettings.setRollingDate(0);
        extractionSettings.setFileNameFormat("file.csv");
        extractionSettings.setRowDelimiter(Constant.RowDelimiter.LF);
        extractionSettings.setColumnDelimiter(",");
        extractionSettings.setQuote(false);
        extractionSettings.setStorageBasePath("/tmp");
        extractionSettings.setFilter("m==1");
        feedConfigDto.setExtractionSettings(extractionSettings);

        ConnectionSettingsDto connectionSettings = new ConnectionSettingsDto();
        connectionSettings.setType(Constant.ConnectionType.MSSQL);
        connectionSettings.setConnectionString("jdbc:test");
        connectionSettings.setNtfsFolderPath("/ntfs");
        feedConfigDto.setConnectionSettings(connectionSettings);
        feedConfigDto.setFileTransferSettings(null);
        requestDto.setFeedConfig(feedConfigDto);

        FeedResponseDto responseDto = new FeedResponseDto();
        responseDto.setFeedName("testfeed");
        Mockito.when(feedService.updateFeedConfig(eq("client01"), eq("a3f1d7c2-8eab-4e4f-bb3e-9c7f6a5d28b1"), any())).thenReturn(responseDto);
        var mvcResult =  mockMvc.perform(put("/api/clients/client01/feeds/a3f1d7c2-8eab-4e4f-bb3e-9c7f6a5d28b1")
                .with(org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(requestDto)))
                .andExpect(status().isOk()) // Expecting a 200 OK response
                .andReturn();
        String responseContent = mvcResult.getResponse().getContentAsString();
        System.out.println("Response: " + responseContent);
        // Verify the response content
        Map<String, Object> responseMap = objectMapper.readValue(responseContent, Map.class);
        assertThat(responseMap.get("message")).isEqualTo("Feed testfeed updated successfully");
        assertThat(responseMap.get("data")).isNotNull();

    }
}
