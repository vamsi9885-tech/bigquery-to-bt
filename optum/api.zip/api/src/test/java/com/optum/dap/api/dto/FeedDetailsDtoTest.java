package com.optum.dap.api.dto;

import org.junit.jupiter.api.Test;
import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.dto.FeedDetailsDto;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import com.optum.dap.api.constants.Constant.FeedStatus;


import static org.junit.jupiter.api.Assertions.*;

public class FeedDetailsDtoTest {

    @Test
    public void testIsActiveGetterSetter() {
        FeedDetailsDto dto = new FeedDetailsDto();
        dto.setActive(true);
        assertTrue(dto.isActive());

        dto.setActive(false);
        assertFalse(dto.isActive());
    }
}
