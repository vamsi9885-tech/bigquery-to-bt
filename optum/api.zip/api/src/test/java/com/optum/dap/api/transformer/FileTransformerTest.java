package com.optum.dap.api.transformer;

import com.optum.dap.api.dto.FileDto;
import com.optum.dap.api.model.Files;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class FileTransformerTest {

    private final FileTransformer transformer = new FileTransformer();

    @Test
    void testToDtoAndToEntity() {
        FileDto dto = new FileDto();
        dto.setFileId("file-1");
        dto.setOrder(1);
        dto.setFileNameFormat("test.csv");
        dto.setLogicalFileName("test.csv");
        dto.setPartCount(1);
        dto.setPartStartSeq(1);
        dto.setParameters(java.util.Collections.emptyList());
        dto.setFilter("filter");
        dto.setIsMandatory(true);

        UUID feedId = UUID.randomUUID();
        String user = "system";
        Files entity = transformer.toEntity(dto, feedId, user);
        assertNotNull(entity);
        assertEquals(feedId, entity.getFeedIdentifier());
        assertEquals("test.csv", entity.getLogicalFileName());
        assertEquals(user, entity.getCreatedBy());
        assertTrue(entity.isActive());
        assertNotNull(entity.getFileConfig());

        // Example of correct Mockito usage for overloaded methods:
        // when(fileTransformer.toEntity(any(FileDto.class), any(UUID.class), any(String.class))).thenReturn(entity);
        // when(fileTransformer.toEntity(any(FileDto.class), any(Feeds.class), any(String.class))).thenReturn(entity);

        FileDto mappedDto = transformer.toDto(entity);
        assertNotNull(mappedDto);
        assertEquals("test.csv", mappedDto.getLogicalFileName());
    }
}
