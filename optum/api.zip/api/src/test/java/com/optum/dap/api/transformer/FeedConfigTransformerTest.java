package com.optum.dap.api.transformer;

import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigDto;
import com.optum.dap.api.dto.ExtractionSettingsDto;
import com.optum.dap.api.dto.FeedResponseDto;
import com.optum.dap.api.service.IFeedFrequencyService;
import com.optum.dap.api.model.Clients;
import com.optum.dap.api.model.ConnectorConfig;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.model.FeedConfig;
import com.optum.dap.api.model.FeedFrequency;
import com.optum.dap.api.model.ExtractionSettings;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class FeedConfigTransformerTest {
    @Mock
    private IFeedFrequencyService feedFrequencyResolver;
    @InjectMocks
    private FeedConfigTransformer transformer;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("toEntity maps DTO to Feeds entity correctly")
    void toEntity_mapsDtoToEntity() {
        FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
        dto.setFeedName("feedA");
        dto.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PULL);
        dto.setIsActive(true);
        dto.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.PENDING);
        dto.setFrequencyId(1); // Use frequencyId instead
        dto.setConnectorType("SFTP");
        dto.setConnectorVersion("1.0");
        FeedConfigDto feedConfigDto = new FeedConfigDto();
        ExtractionSettingsDto extractionSettingsDto = new ExtractionSettingsDto();
        feedConfigDto.setExtractionSettings(extractionSettingsDto);
        feedConfigDto.setConnectionSettings(null);
        feedConfigDto.setFileTransferSettings(null);
        dto.setFeedConfig(feedConfigDto);
        Clients client = new Clients();
        Feeds entity = transformer.toEntity(dto, client);
        assertThat(entity.getFeedName()).isEqualTo("feedA");
        assertThat(entity.getFeedType()).isEqualTo(com.optum.dap.api.constants.Constant.FeedType.PULL);
        assertThat(entity.getConnectorConfig()).isNotNull();
        assertThat(entity.getConnectorConfig().getConnectorType()).isEqualTo("SFTP");
        assertThat(entity.getConnectorConfig().getEmrVersion()).isEqualTo("1.0");
        assertThat(entity.getClient()).isEqualTo(client);
        assertThat(entity.getFeedConfig()).isNotNull();
    }

    @Test
    @DisplayName("toResponseDto maps Feeds entity to FeedResponseDto correctly")
    void toResponseDto_mapsEntityToDto() {

        FeedFrequency freqEntity = new FeedFrequency();
        freqEntity.setFrequencyType("WEEKLY");
        freqEntity.setFrequencyId(1);
        when(feedFrequencyResolver.resolveById(2)).thenReturn(freqEntity);
        
        Feeds entity = new Feeds();
        entity.setFeedName("feedB");
        entity.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PUSH);
        entity.setActive(false);
        entity.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE);
        entity.setFrequencyId(2); // Use frequencyId instead for test
        entity.setFeedIdentifier(java.util.UUID.randomUUID());
        ConnectorConfig connectorConfig = new ConnectorConfig();
        connectorConfig.setConnectorType("SFTP");
        connectorConfig.setEmrVersion("1.0");
        entity.setConnectorConfig(connectorConfig);
        // FIX: Use FeedConfigDto, not FeedConfig
        FeedConfig feedConfig= new FeedConfig();
        ExtractionSettings extractionSettings = new ExtractionSettings();
        feedConfig.setExtractionSettings(extractionSettings);
        feedConfig.setConnectionSettings(null);
        feedConfig.setFileTransferSettings(null);
        entity.setFeedConfig(feedConfig);
        
        // Mock the frequency resolver to avoid NPE

        FeedResponseDto dto = transformer.toResponseDto(entity);
        assertThat(dto.getFeedName()).isEqualTo("feedB");
        assertThat(dto.getFeedType()).isEqualTo(com.optum.dap.api.constants.Constant.FeedType.PUSH);
        assertThat(dto.getConnectorType()).isEqualTo("SFTP");
        assertThat(dto.getConnectorVersion()).isEqualTo("1.0");
        assertThat(dto.getFeedConfig()).isNotNull();
        assertThat(dto.getFeedFrequency()).isEqualTo("WEEKLY");
    }
}