package com.optum.dap.api.transformer;

import com.optum.dap.api.constants.Constant;
import com.optum.dap.api.dto.CronSettingsDto;
import com.optum.dap.api.dto.RuntimeConfigDto;
import com.optum.dap.api.model.RuntimeSettings;
import com.optum.dap.api.model.ConnectorConfig;
import com.optum.dap.api.model.CronSettings;
import com.optum.dap.api.repository.IFeedFrequencyRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.assertj.core.api.Assertions.assertThat;

import com.optum.dap.api.model.RuntimeSettingConfig;

class RuntimeConfigTransformerTest {
    
    @InjectMocks
    private RuntimeConfigTransformer transformer;
    
    @Mock
    private IFeedFrequencyRepository feedFrequencyRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void toDto_shouldMapEntityToDto() {
        // Prepare CronSettingsDto
        CronSettings cron = new CronSettings();
        cron.setTimeOfDay("10:24");
        cron.setDayOfWeek("1");
        cron.setDayOfMonth("15");
        cron.setMonthOfYear("6");
        
        // Prepare RuntimeSettingConfig with CronSetting
        RuntimeSettingConfig entityConfig = new RuntimeSettingConfig();
        entityConfig.setCronSettings(cron);
        
        // Prepare RuntimeSettings entity
        RuntimeSettings entity = RuntimeSettings.builder()
                .runTimeConfigId(java.util.UUID.randomUUID())
                .feedIdentifier(java.util.UUID.randomUUID())
                .isAdhocRun(false)
                .extractionType("periodic")
                .splitBy(1)
                .adhocStartDate(java.time.LocalDate.now())
                .adhocEndDate(java.time.LocalDate.now())
                .periodicStartDate(java.time.LocalDateTime.now())
                .lagOffset(3)
                .lagTolerance(1)
                .notifyType("STANDARD")
                .enableRunStatusNotification(true)
                .runtimeSettingConfig(entityConfig) // Set the config that contains the CronSetting
                .build();
                
        // Prepare ConnectorConfig
        ConnectorConfig connectorConfig = new ConnectorConfig();
        connectorConfig.setSpecName("specA");
        connectorConfig.setSpecVersion("v1");
        
        // Call the method under test
        RuntimeConfigDto dto = transformer.toDto(entity, connectorConfig);
        
        // Assertions
        assertThat(dto).isNotNull();
        assertThat(dto.getExtractionType()).isEqualTo(Constant.ExtractionType.PERIODIC);
        assertThat(dto.getNotifyType()).isEqualTo(Constant.NotifyType.STANDARD);
        assertThat(dto.getSplitBy()).isEqualTo(1);
        assertThat(dto.getSpecName()).isEqualTo("specA");
        assertThat(dto.getSpecVersion()).isEqualTo("v1");
        assertThat(dto.getCronSettings()).isNotNull();
        assertThat(dto.getCronSettings().getTimeOfDay()).isEqualTo("10:24");
    }

    @Test
    void toEntity_shouldMapDtoToEntity() {
        // Prepare CronSettingsDto
        CronSettingsDto cron = new CronSettingsDto();
        cron.setTimeOfDay("11:00");
        cron.setDayOfWeek("2");
        cron.setDayOfMonth("20");
        cron.setMonthOfYear("7");
        
        // Prepare RuntimeConfigDto
        RuntimeConfigDto dto = new RuntimeConfigDto();
        dto.setIsAdhocRun(false);
        dto.setExtractionType(Constant.ExtractionType.PERIODIC);
        dto.setSplitBy(Constant.SplitBy.DAILY.getValue());
        dto.setStartDate(java.time.LocalDate.now());
        dto.setEndDate(java.time.LocalDate.now());
        dto.setPeriodicStartDate(java.time.LocalDate.now());
        dto.setLagOffset(2);
        dto.setLagTolerance(1);
        dto.setNotifyType(Constant.NotifyType.STANDARD);
        dto.setEnableRunStatusNotification(true);
        dto.setCronSettings(cron);
        
        // Call the method under test
        RuntimeSettings entity = transformer.toEntity(dto);
        
        // Assertions
        assertThat(entity).isNotNull();
        assertThat(entity.getExtractionType()).isEqualTo("periodic");
        assertThat(entity.getSplitBy()).isEqualTo(1);
        assertThat(entity.getRuntimeSettingConfig()).isNotNull();
        CronSettings cronSettings = entity.getRuntimeSettingConfig().getCronSettings();
        assertThat(cronSettings).isNotNull();
        assertThat(cronSettings.getTimeOfDay()).isEqualTo("11:00");
        assertThat(cronSettings.getDayOfWeek()).isEqualTo("2");
        assertThat(cronSettings.getDayOfMonth()).isEqualTo("20");
        assertThat(cronSettings.getMonthOfYear()).isEqualTo("7");
    }
}
