package com.optum.dap.api.controller;

import java.time.LocalDateTime;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.dap.api.config.JwtTokenProvider;
import com.optum.dap.api.dto.RuntimeConfigDto;
import com.optum.dap.api.service.IRuntimeSettingsService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(RuntimeSettingsController.class)
class RuntimeSettingsControllerTest {
    
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    private IRuntimeSettingsService runtimeSettingsService;
    
    @MockBean
    private JwtTokenProvider jwtTokenProvider;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    private RuntimeConfigDto runtimeConfigDto;
    private UUID feedIdentifier;
    private String clientId = "client01";

    @BeforeEach
    void setUp() {
        runtimeConfigDto = new RuntimeConfigDto();
        runtimeConfigDto.setIsAdhocRun(false);
        runtimeConfigDto.setLagOffset(0);
        runtimeConfigDto.setLagTolerance(0);
        feedIdentifier = UUID.randomUUID();
    }

    @Test
    @WithMockUser
    void getRuntimeConfig_shouldReturnOk() throws Exception {
        // Given
        when(runtimeSettingsService.getRuntimeConfig(eq(clientId), eq(feedIdentifier))).thenReturn(runtimeConfigDto);
        
        // When & Then
        mockMvc.perform(get("/api/clients/{clientId}/feeds/{feedId}/runtimeconfig", clientId, feedIdentifier))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON));
                
        // Verify service was called with correct parameters
        verify(runtimeSettingsService).getRuntimeConfig(eq(clientId), eq(feedIdentifier));
    }

    @Test
    @WithMockUser
    void updateRuntimeConfig_shouldReturnOk() throws Exception {
        // Given
        doNothing().when(runtimeSettingsService).updateRuntimeConfig(eq(clientId), eq(feedIdentifier), any(RuntimeConfigDto.class));
        
        // When & Then
        mockMvc.perform(put("/api/clients/{clientId}/feeds/{feedId}/runtimeconfig", clientId, feedIdentifier)
                .with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(runtimeConfigDto)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.message").exists());
                
        // Verify service was called with correct parameters
        verify(runtimeSettingsService).updateRuntimeConfig(eq(clientId), eq(feedIdentifier), any(RuntimeConfigDto.class));
    }
}