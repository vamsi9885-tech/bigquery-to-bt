package com.optum.dap.api.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.Instant;
import java.util.Map;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Pure unit tests for the HeartbeatController.
 * These tests directly invoke the controller methods rather than using REST endpoints.
 *
 * @author DAP Team
 */
@ExtendWith(MockitoExtension.class)
class HeartbeatControllerTest {

    @InjectMocks
    private HeartbeatController heartbeatController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Tests that the heartbeat endpoint returns a response with UP status.
     */
    @Test
    @DisplayName("Should return response with status UP")
    void shouldReturnResponseWithStatusUp() {
        // When
        ResponseEntity<Map<String, Object>> response = heartbeatController.heartbeat();

        // Then
        assertNotNull(response, "Response should not be null");
        assertEquals(HttpStatus.OK, response.getStatusCode(), "HTTP status should be 200 OK");
        assertNotNull(response.getBody(), "Response body should not be null");
        assertEquals("UP", response.getBody().get("status"), "Status should be UP");
    }

    /**
     * Tests that the heartbeat endpoint returns a response with a valid timestamp.
     */
    @Test
    @DisplayName("Should return response with valid timestamp")
    void shouldReturnResponseWithValidTimestamp() {
        // When
        ResponseEntity<Map<String, Object>> response = heartbeatController.heartbeat();

        // Then
        assertNotNull(response, "Response should not be null");
        assertNotNull(response.getBody(), "Response body should not be null");
        Object timestampObj = response.getBody().get("timestamp");
        assertNotNull(timestampObj, "Timestamp should not be null");

        String timestamp = timestampObj.toString();
        // Verify timestamp is in ISO-8601 format (simple check)
        Pattern isoPattern = Pattern.compile(".*T.*Z");
        assertTrue(isoPattern.matcher(timestamp).matches(),
                "Timestamp should be in ISO-8601 format");

        // Verify timestamp is near current time
        Instant now = Instant.now();
        Instant responseTime = Instant.parse(timestamp);
        long diffSeconds = Math.abs(now.getEpochSecond() - responseTime.getEpochSecond());

        // Timestamp should be within 10 seconds of current time
        assertTrue(diffSeconds < 10,
                "Timestamp should be close to current time");
    }

    /**
     * Tests that the heartbeat endpoint returns a response with exactly two fields.
     */
    @Test
    @DisplayName("Should include exactly two fields in response")
    void shouldHaveExactlyTwoFieldsInResponse() {
        // When
        ResponseEntity<Map<String, Object>> response = heartbeatController.heartbeat();

        // Then
        assertNotNull(response, "Response should not be null");
        assertNotNull(response.getBody(), "Response body should not be null");
        assertEquals(2, response.getBody().size(),
                "Response should contain exactly two fields: status and timestamp");
        assertTrue(response.getBody().containsKey("status"),
                "Response should contain status field");
        assertTrue(response.getBody().containsKey("timestamp"),
                "Response should contain timestamp field");
    }
}