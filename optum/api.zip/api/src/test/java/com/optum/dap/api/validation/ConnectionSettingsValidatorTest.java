package com.optum.dap.api.validation;

import com.optum.dap.api.constants.Constant.ConnectionType;
import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.dto.ConnectionSettingsDto;
import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigDto;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ConnectionSettingsValidatorTest {

    private ConnectionSettingsValidator validator;
    private ConstraintValidatorContext context;

    @BeforeEach
    public void setup() {
        validator = new ConnectionSettingsValidator();
        context = Mockito.mock(ConstraintValidatorContext.class);

        ConstraintValidatorContext.ConstraintViolationBuilder builder =
            Mockito.mock(ConstraintValidatorContext.ConstraintViolationBuilder.class);
        ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext nodeBuilder =
            Mockito.mock(ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext.class);

        Mockito.when(context.buildConstraintViolationWithTemplate(Mockito.anyString()))
           .thenReturn(builder);
        Mockito.when(builder.addPropertyNode(Mockito.anyString()))
           .thenReturn(nodeBuilder);
        Mockito.when(nodeBuilder.addConstraintViolation())
           .thenReturn(context);
    }


    @Test
    public void testNullValue() {
        assertTrue(validator.isValid(null, context));
    }

    @Test
    public void testPushFeedTypeWithSettings() {
        FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
        dto.setFeedName("feedA");
        dto.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PUSH);
        dto.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE);
        dto.setIsActive(true);
        dto.setFrequencyId(1);
        dto.setConnectorType("SFTP");
        dto.setConnectorVersion("1.0");

        
        ConnectionSettingsDto settings = new ConnectionSettingsDto();
        settings.setType(ConnectionType.NTFS); // Assuming NTFS is a valid enum
        settings.setConnectionString("sftp://host");

        FeedConfigDto config = new FeedConfigDto();
        config.setConnectionSettings(settings);
        dto.setFeedConfig(config);


        assertFalse(validator.isValid(dto, context));
    }

//     @Test
//     public void testPullWithNtfsValid() {
//         FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
//         dto.setFeedName("feedA");
//         dto.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PULL_WITH_NTFS);
//         dto.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE);
//         dto.setIsActive(true);
//         dto.setFrequencyId(1);
//         dto.setConnectorType("SFTP");
//         dto.setConnectorVersion("1.0");

//         ConnectionSettingsDto settings = new ConnectionSettingsDto();
//         settings.setType(ConnectionType.NTFS);
//         settings.setNtfsFolderPath("C:/data");

//         FeedConfigDto config = new FeedConfigDto();
//         config.setConnectionSettings(settings);
//         dto.setFeedConfig(config);

//         assertTrue(validator.isValid(dto, context));
//     }

//     @Test
//     public void testPullInvalidNtfsType() {
//         FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
//         dto.setFeedType(FeedType.PUSH);
//         dto.setStatus(FeedStatus.ACTIVE);

//         ConnectionSettingsDto settings = new ConnectionSettingsDto();
//         settings.setType(ConnectionType.NTFS); // Invalid for PULL
//         settings.setConnectionString("jdbc:mysql://localhost");

//         FeedConfigDto config = new FeedConfigDto();
//         config.setConnectionSettings(settings);
//         dto.setFeedConfig(config);

//         assertFalse(validator.isValid(dto, context));
//     }
 }
