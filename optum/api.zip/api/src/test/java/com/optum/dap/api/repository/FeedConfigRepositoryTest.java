package com.optum.dap.api.repository;

import com.optum.dap.api.model.Feeds;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Optional;
import java.util.UUID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

/**
 * Unit tests for FeedsRepository.
 */
@ExtendWith(MockitoExtension.class)
class FeedsRepositoryTest {

    @Mock
    private FeedsRepository feedsRepository;
    @Mock
    private Feeds feed;

    @Test
    @DisplayName("Test findByFeedIdentifier returns feed")
    void testFindByFeedIdentifier() {
        UUID feedId = UUID.randomUUID();
        when(feedsRepository.findByFeedIdentifier(feedId)).thenReturn(Optional.of(feed));
        Optional<Feeds> result = feedsRepository.findByFeedIdentifier(feedId);
        assertThat(result).isPresent();
        assertThat(result.get()).isEqualTo(feed);
    }

    @Test
    @DisplayName("Test existsByFeedNameAndClient_ClientId returns true")
    void testExistsByFeedNameAndClient_ClientId() {
        when(feedsRepository.existsByFeedNameAndClient_ClientId("feedA", "client01")).thenReturn(true);
        boolean exists = feedsRepository.existsByFeedNameAndClient_ClientId("feedA", "client01");
        assertThat(exists).isTrue();
    }

    @Test
    @DisplayName("existsByFeedNameAndClient_ClientId returns false when feed does not exist for client")
    void existsByFeedNameAndClient_ClientId_returnsFalse() {
        when(feedsRepository.existsByFeedNameAndClient_ClientId("nonexistent", "client02")).thenReturn(false);
        boolean exists = feedsRepository.existsByFeedNameAndClient_ClientId("nonexistent", "client02");
        assertThat(exists).isFalse();
    }
}
