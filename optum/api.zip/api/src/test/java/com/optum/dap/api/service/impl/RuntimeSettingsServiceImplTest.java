package com.optum.dap.api.service.impl;

import com.optum.dap.api.constants.Constant;
import com.optum.dap.api.dto.RuntimeConfigDto;
import com.optum.dap.api.model.ConnectorConfig;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.model.RuntimeSettings;
import com.optum.dap.api.repository.FeedsRepository;
import com.optum.dap.api.repository.IConnectorConfigRepository;
import com.optum.dap.api.repository.IRuntimeSettingsRepository;
import com.optum.dap.api.transformer.RuntimeConfigTransformer;
import com.optum.dap.api.utils.DeepCopyUtil;
import com.optum.dap.api.service.IAuditService;
import com.optum.dap.api.validation.RuntimeSettingsValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class RuntimeSettingsServiceImplTest {
    @Mock
    private IRuntimeSettingsRepository runtimeSettingsRepository;
    @Mock
    private FeedsRepository feedsRepository;
    @Mock
    private IConnectorConfigRepository connectorConfigRepository;
    @Mock
    private RuntimeConfigTransformer transformer;
    @Mock
    private RuntimeSettingsValidator validator;
    @InjectMocks
    private RuntimeSettingsServiceImpl service;

    @Mock
    private DeepCopyUtil deepCopyUtil;
    @Mock
    private IAuditService auditService;
    

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetRuntimeConfig_NotFound() {
        String clientId = "client1";
        UUID feedIdentifier = UUID.randomUUID();
        when(feedsRepository.findById(any())).thenReturn(Optional.empty());
        assertThrows(RuntimeException.class, () -> service.getRuntimeConfig(clientId, feedIdentifier));
    }

    @Test
    void testUpdateRuntimeConfig_Success() {
        String clientId = "client1";
        UUID feedIdentifier = UUID.randomUUID();
        Feeds feed = new Feeds();
        feed.setFeedIdentifier(feedIdentifier);
        feed.setClient(new com.optum.dap.api.model.Clients());
        feed.getClient().setClientId(clientId);
        feed.setActive(true); // Ensure feed is active for success test
        when(feedsRepository.findById(any())).thenReturn(Optional.of(feed));
        when(runtimeSettingsRepository.findByFeedIdentifier(any())).thenReturn(Optional.empty());
        when(connectorConfigRepository.findByFeed_FeedIdentifier(any())).thenReturn(Optional.of(new ConnectorConfig()));
        RuntimeConfigDto dto = new RuntimeConfigDto();
        dto.setSplitBy(1);
        dto.setStartDate(LocalDate.of(2025, 6, 1));
        dto.setEndDate(LocalDate.of(2025, 6, 2));
        dto.setPeriodicStartDate(LocalDate.of(2025, 6, 3));
        doNothing().when(validator).validate(any(), any());
        doNothing().when(transformer).updateEntityFromDto(any(), any());
        doNothing().when(transformer).updateConnectorConfigFromDto(any(), any());
        when(deepCopyUtil.deepCopy(any(), eq(RuntimeSettings.class))).thenReturn(new RuntimeSettings());
        when(deepCopyUtil.deepCopy(any(), eq(ConnectorConfig.class))).thenReturn(new ConnectorConfig());
        doNothing().when(auditService).logAudit(any(), any(), any(), any(), any(), any());
        service.updateRuntimeConfig(clientId, feedIdentifier, dto);
        verify(runtimeSettingsRepository, times(1)).save(any());
        verify(connectorConfigRepository, times(1)).save(any());
    }
}