package com.optum.dap.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.dap.api.config.JwtTokenProvider;
import com.optum.dap.api.dto.FileDto;
import com.optum.dap.api.service.IFileService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(FilesController.class)
class FilesControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private IFileService fileService;
    @MockBean
    private JwtTokenProvider jwtTokenProvider;
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser
    void testGetFiles() throws Exception {
        // Use a valid UUID string for feed identifier
        String validFeedId = "11111111-1111-1111-1111-111111111111";
        FileDto fileDto = new FileDto();
        fileDto.setFileId("file-1");
        fileDto.setLogicalFileName("test.csv");
        Mockito.when(fileService.getFiles(any(), any())).thenReturn(List.of(fileDto));
        mockMvc.perform(get("/api/clients/client1/feeds/" + validFeedId + "/files"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].fileId").value("file-1"))
                .andExpect(jsonPath("$[0].logicalFileName").value("test.csv"));
        // Lint fix: Do not assert directly on returned list in controller test
    }

    @Test
    @WithMockUser
    void testAddFiles() throws Exception {
        // Use a valid UUID string for feed identifier
        String validFeedId = "11111111-1111-1111-1111-111111111111";
        FileDto fileDto = new FileDto();
        fileDto.setFileId("file-1");
        fileDto.setOrder(1);
        fileDto.setFileNameFormat("test.csv");
        fileDto.setLogicalFileName("test1");
        fileDto.setPartCount(1);
        fileDto.setPartStartSeq(1);
        // Fix: Provide a non-empty parameters list to pass validation
        com.optum.dap.api.dto.ParameterDto param = new com.optum.dap.api.dto.ParameterDto();
        param.setParamName("param1");
        param.setParamValue("value1");
        fileDto.setParameters(java.util.List.of(param));
        fileDto.setFilter("filter");
        fileDto.setIsMandatory(true);

        String json = objectMapper.writeValueAsString(List.of(fileDto));
        // Lint fix: Use doNothing for void method
        Mockito.doNothing().when(fileService).saveFiles(any(), any(), any());
        var mvcResult =  mockMvc.perform(post("/api/clients/client1/feeds/" + validFeedId + "/files")
                .with(csrf())
                .contentType(MediaType.APPLICATION_JSON)
                .content(json));
        
        
                mvcResult.andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Files config for the Feed " + validFeedId + " saved  successfully"));
        // Lint fix: Do not assert directly on returned object in controller test
    }
}
