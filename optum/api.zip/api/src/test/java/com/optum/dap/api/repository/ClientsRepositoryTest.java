package com.optum.dap.api.repository;

import com.optum.dap.api.model.Clients;
import com.optum.dap.api.projection.IClientsProjection;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import java.util.Arrays;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

/**
 * Unit tests for ClientsRepository.
 */
@ExtendWith(MockitoExtension.class)
class ClientsRepositoryTest {

    @Mock
    private ClientsRepository clientsRepository;

    @Mock
    private IClientsProjection clientsProjection;

    @Test
    @DisplayName("Test findAllProjectedBy returns projections")
    void testFindAllProjectedBy() {
        when(clientsRepository.findAllProjectedBy()).thenReturn(Arrays.asList(clientsProjection));
        List<IClientsProjection> result = clientsRepository.findAllProjectedBy();
        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
    }

}
