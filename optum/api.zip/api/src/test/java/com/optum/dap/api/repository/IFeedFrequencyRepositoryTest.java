package com.optum.dap.api.repository;

import com.optum.dap.api.model.FeedFrequency;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

/**
 * Unit tests for IFeedFrequencyRepository.
 */
@ExtendWith(MockitoExtension.class)
class IFeedFrequencyRepositoryTest {

    @Mock
    private IFeedFrequencyRepository feedFrequencyRepository;

    @Mock
    private FeedFrequency feedFrequency;

    @Test
    @DisplayName("Test findAll returns all feed frequencies")
    void testFindAll() {
        when(feedFrequencyRepository.findAll()).thenReturn(Arrays.asList(feedFrequency));
        List<FeedFrequency> result = feedFrequencyRepository.findAll();
        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("Test findById returns feed frequency entity")
    void testFindById() {
        when(feedFrequencyRepository.findById(1)).thenReturn(Optional.of(feedFrequency));
        Optional<FeedFrequency> result = feedFrequencyRepository.findById(1);
        assertThat(result).isPresent();
        assertThat(result.get()).isEqualTo(feedFrequency);
    }
}
