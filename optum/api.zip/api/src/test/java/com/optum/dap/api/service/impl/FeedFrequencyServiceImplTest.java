package com.optum.dap.api.service.impl;

import com.optum.dap.api.dto.FeedFrequencyResponseDto;
import com.optum.dap.api.model.FeedFrequency;
import com.optum.dap.api.repository.IFeedFrequencyRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.Arrays;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

/**
 * Unit tests for FeedFrequencyServiceImpl.
 */
class FeedFrequencyServiceImplTest {

    @Mock
    private IFeedFrequencyRepository feedFrequencyRepository;

    @InjectMocks
    private FeedFrequencyServiceImpl feedFrequencyService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllFeedFrequencies() {
        FeedFrequency entity1 = new FeedFrequency();
        entity1.setFrequencyType("DAILY");
        entity1.setFeedWindowDates(7);
        entity1.setSupportedFeedType("PULL");

        FeedFrequency entity2 = new FeedFrequency();
        entity2.setFrequencyType("WEEKLY");
        entity2.setFeedWindowDates(30);
        entity2.setSupportedFeedType("PUSH");

        when(feedFrequencyRepository.findAll()).thenReturn(Arrays.asList(entity1, entity2));

        List<FeedFrequencyResponseDto> result = feedFrequencyService.getAllFeedFrequencies();
        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getFrequencyType()).isEqualTo("DAILY");
        assertThat(result.get(1).getFrequencyType()).isEqualTo("WEEKLY");
    }
}
