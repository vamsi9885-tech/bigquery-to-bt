package com.optum.dap.api.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.oidc.OidcIdToken;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.web.servlet.view.RedirectView;

import com.optum.dap.api.dto.UserDto;
import com.optum.dap.api.properties.OIDCProperties;
import com.optum.dap.api.service.ISessionService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Pure unit tests for the SessionController.
 * Tests the controller methods directly rather than through HTTP endpoints.
 */
@ExtendWith(MockitoExtension.class)
class SessionControllerTest {

    @Mock
    private ISessionService sessionService;
    
    @Mock
    private OIDCProperties oidcProperties;
    
    @Mock
    private Authentication authentication;
    
    @Mock
    private SecurityContext securityContext;
    
    @Mock
    private DefaultOidcUser oidcUser;
    
    @Mock
    private OidcIdToken idToken;
    
    @Mock
    private HttpServletRequest request;
    
    @Mock
    private HttpSession httpSession;
    
    @InjectMocks
    private SessionController sessionController;

    @Test
    @DisplayName("isSessionActive - should return active status from service")
    void testIsSessionActive() {
        // Arrange
        when(sessionService.isSessionActiveWithTimeout()).thenReturn(true);
        
        // Act
        ResponseEntity<Boolean> response = sessionController.isSessionActive();
        
        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isTrue();
    }
    
    @Test
    @DisplayName("getLoggedInUserDetails - should return user details when authenticated")
    void testGetLoggedInUserDetails_Authenticated() {
        // Arrange
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getPrincipal()).thenReturn(oidcUser);
        
        when(oidcUser.getPreferredUsername()).thenReturn("testuser");
        when(oidcUser.getEmail()).thenReturn("test@example.com");
        when(oidcUser.getClaim("name")).thenReturn("Test User");
        
        SecurityContextHolder.setContext(securityContext);
        
        // Act
        ResponseEntity<UserDto> response = sessionController.getLoggedInUserDetails();
        
        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        UserDto userDto = response.getBody();
        assertThat(userDto).isNotNull();
        assertThat(userDto.getUserId()).isEqualTo("testuser");
        assertThat(userDto.getUserEmail()).isEqualTo("test@example.com");
        assertThat(userDto.getUserName()).isEqualTo("Test User");
    }
    
    @Test
    @DisplayName("getLoggedInUserDetails - should return unauthorized when not authenticated")
    void testGetLoggedInUserDetails_NotAuthenticated() {
        // Arrange
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.isAuthenticated()).thenReturn(false);
        
        SecurityContextHolder.setContext(securityContext);
        
        // Act
        ResponseEntity<UserDto> response = sessionController.getLoggedInUserDetails();
        
        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
        assertThat(response.getBody()).isNull();
    }
    
    @Test
    @DisplayName("getLoggedInUserDetails - should return unauthorized when authentication is null")
    void testGetLoggedInUserDetails_NullAuthentication() {
        // Arrange
        when(securityContext.getAuthentication()).thenReturn(null);
        
        SecurityContextHolder.setContext(securityContext);
        
        // Act
        ResponseEntity<UserDto> response = sessionController.getLoggedInUserDetails();
        
        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
        assertThat(response.getBody()).isNull();
    }
    
    @Test
    @DisplayName("getLoggedInUserDetails - should return unauthorized when user is anonymous")
    void testGetLoggedInUserDetails_AnonymousUser() {
        // Arrange
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getPrincipal()).thenReturn("anonymousUser");
        
        SecurityContextHolder.setContext(securityContext);
        
        // Act
        ResponseEntity<UserDto> response = sessionController.getLoggedInUserDetails();
        
        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
        assertThat(response.getBody()).isNull();
    }
    
    @Test
    @DisplayName("logoutget - should redirect to OIDC logout endpoint")
    void testLogoutGet() {
        // Arrange
        String logoutEndpoint = "https://oidc-provider/logout";
        String tokenValue = "test-id-token";
        
        when(oidcProperties.getLogoutEndpoint()).thenReturn(logoutEndpoint);
        when(authentication.getPrincipal()).thenReturn(oidcUser);
        when(oidcUser.getIdToken()).thenReturn(idToken);
        when(idToken.getTokenValue()).thenReturn(tokenValue);
        when(request.getSession()).thenReturn(httpSession);
        when(request.getSession(false)).thenReturn(httpSession);
        
        // Act
        RedirectView redirectView = sessionController.logoutget(request, authentication);
        
        // Assert
        String expectedUrl = logoutEndpoint + "?id_token=" + tokenValue;
        assertThat(redirectView.getUrl()).isEqualTo(expectedUrl);
        verify(httpSession).invalidate();
    }
    
    @Test
    @DisplayName("logoutget - should handle null authentication")
    void testLogoutGet_NullAuthentication() {
        // Arrange
        String logoutEndpoint = "https://oidc-provider/logout";
        when(oidcProperties.getLogoutEndpoint()).thenReturn(logoutEndpoint);
        when(request.getSession()).thenReturn(httpSession);
        when(request.getSession(false)).thenReturn(httpSession);
        
        // Act
        RedirectView redirectView = sessionController.logoutget(request, null);
        
        // Assert
        assertThat(redirectView.getUrl()).isEqualTo(logoutEndpoint);
        verify(httpSession).invalidate();
    }
}