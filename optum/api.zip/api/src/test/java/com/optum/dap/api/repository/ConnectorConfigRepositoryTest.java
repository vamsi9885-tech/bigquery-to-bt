package com.optum.dap.api.repository;

import com.optum.dap.api.model.ConnectorConfig;
import com.optum.dap.api.model.Feeds;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

/**
 * Unit tests for ConnectorConfigRepository.
 */
@ExtendWith(MockitoExtension.class)
class ConnectorConfigRepositoryTest {

    @Mock
    private ConnectorConfigRepository connectorConfigRepository;
    @Mock
    private ConnectorConfig connectorConfig;
    @Mock
    private Feeds feeds;

    @Test
    @DisplayName("Test findByFeed_FeedIdentifier returns connector config")
    void testFindByFeed_FeedIdentifier() {
        UUID feedId = UUID.randomUUID();
        when(connectorConfigRepository.findByFeed_FeedIdentifier(feedId)).thenReturn(Optional.of(connectorConfig));
        Optional<ConnectorConfig> result = connectorConfigRepository.findByFeed_FeedIdentifier(feedId);
        assertThat(result).isPresent();
        assertThat(result.get()).isEqualTo(connectorConfig);
    }

    @Test
    @DisplayName("Test findByFeed_FeedIdentifier returns empty when not present")
    void testFindByFeed_FeedIdentifier_returnsEmpty() {
        UUID feedId = UUID.randomUUID();
        when(connectorConfigRepository.findByFeed_FeedIdentifier(feedId)).thenReturn(Optional.empty());
        Optional<ConnectorConfig> result = connectorConfigRepository.findByFeed_FeedIdentifier(feedId);
        assertThat(result).isNotPresent();
    }
}
