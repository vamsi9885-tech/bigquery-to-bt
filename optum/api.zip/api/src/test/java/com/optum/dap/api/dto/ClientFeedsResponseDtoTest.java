package com.optum.dap.api.dto;

import com.optum.dap.api.dto.ClientConfigDto;
import com.optum.dap.api.dto.FeedDetailsDto;
import com.optum.dap.api.dto.ClientFeedsResponseDto;
import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.constants.Constant.FeedType;
import org.junit.jupiter.api.Test;
import java.util.Collections;
import static org.junit.jupiter.api.Assertions.*;

public class ClientFeedsResponseDtoTest {

    @Test
    public void testClientFeedsResponseDtoFullCoverage() {
        // Create and populate ClientConfigDto
        ClientConfigDto configDto = new ClientConfigDto();
        configDto.setInternalNotificationEmails("internal@example.com");
        configDto.setExternalNotificationEmails("external@example.com");
        configDto.setPreserveArchives(true);
        configDto.setFeedCompletionNotificationEnabled(true);
        configDto.setPurgeOldFilesDays(30);

        // Create and populate FeedDetailsDto
        FeedDetailsDto feedDetails = new FeedDetailsDto();
        feedDetails.setFeedName("feedA");
        feedDetails.setFeedId("feed123");
        feedDetails.setActive(true);
        feedDetails.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE);
        feedDetails.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PULL);
        feedDetails.setFeedFrequency("Daily");
        feedDetails.setConnectorType("SFTP");
        feedDetails.setConnectorVersion("1.0");

        // Create and populate ClientFeedsResponseDto
        ClientFeedsResponseDto responseDto = new ClientFeedsResponseDto();
        responseDto.setClientId("testclient");
        responseDto.setClientName("testClientName");
        responseDto.setActive(true);
        responseDto.setClientConfig(configDto);
        responseDto.setFeeds(Collections.singletonList(feedDetails));

        // Assertions
        assertEquals("testclient", responseDto.getClientId());
        assertEquals("testClientName", responseDto.getClientName());
        assertTrue(responseDto.isActive());
        assertEquals(configDto, responseDto.getClientConfig());
        assertEquals(1, responseDto.getFeeds().size());

        FeedDetailsDto retrievedFeed = responseDto.getFeeds().get(0);
        assertEquals("feedA", retrievedFeed.getFeedName());
        assertEquals("feed123", retrievedFeed.getFeedId());
        assertTrue(retrievedFeed.isActive());
        assertEquals(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE, retrievedFeed.getStatus());
        assertEquals(com.optum.dap.api.constants.Constant.FeedType.PULL, retrievedFeed.getFeedType());
        assertEquals("Daily", retrievedFeed.getFeedFrequency());
        assertEquals("SFTP", retrievedFeed.getConnectorType());
        assertEquals("1.0", retrievedFeed.getConnectorVersion());
    }
}
