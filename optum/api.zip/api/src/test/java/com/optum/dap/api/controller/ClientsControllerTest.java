package com.optum.dap.api.controller;

import com.optum.dap.api.dto.ClientsDetailsDto;
import com.optum.dap.api.dto.ClientsResponseDto;
import com.optum.dap.api.dto.ClientRequestDto;
import com.optum.dap.api.service.IClientsService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import com.optum.dap.api.exception.RecordNotFoundException;
import com.optum.dap.api.exception.RecordAlreadyExistException;

/**
 * Unit tests for ClientsController.
 */
class ClientsControllerTest {

    @Mock
    private IClientsService clientsService;

    @InjectMocks
    private ClientsController clientsController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("GET /api/clients - should return list of clients")
    void testGetClients() {
        List<ClientsDetailsDto> mockList = Arrays.asList(new ClientsDetailsDto());
        when(clientsService.getAllClients()).thenReturn(mockList);
        ResponseEntity<List<ClientsDetailsDto>> response = clientsController.getClients();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isEqualTo(mockList);
    }

    @Test
    @DisplayName("GET /api/clients/{clientId} - should return client details")
    void testGetClientById_Success() {
        ClientsResponseDto dto = new ClientsResponseDto();
        when(clientsService.getClientDetailsById("client1")).thenReturn(dto);
        ResponseEntity<ClientsResponseDto> response = clientsController.getClientById("client1");
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isEqualTo(dto);
    }

    @Test
    @DisplayName("GET /api/clients/{clientId} - should return 404 when client not found")
    void testGetClientById_NotFound() {
        when(clientsService.getClientDetailsById("unknown")).thenThrow(new RecordNotFoundException("unknown"));
        assertThatThrownBy(() -> clientsController.getClientById("unknown"))  
        .isInstanceOf(RecordNotFoundException.class)  
        .hasMessageContaining("unknown"); 
    }

    @Test
    @DisplayName("GET /api/clients/{clientId} - should return 500 on internal error")
    void testGetClientById_InternalError() {
        when(clientsService.getClientDetailsById("client1")).thenThrow(new RuntimeException("Database error"));
        assertThatThrownBy(() -> clientsController.getClientById("client1"))  
        .isInstanceOf(RuntimeException.class)  
        .hasMessageContaining("Database error"); 
    }

   
    @Test
    @DisplayName("PUT /api/clients/{clientId} - update client success")
    void testUpdateClient_Success() {
        ClientRequestDto dto = new ClientRequestDto();
        dto.setClientName("TestClient");
        dto.setClientId("1");
        ResponseEntity<?> response = clientsController.updateClient("1", dto);

        
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(((java.util.Map<?, ?>) response.getBody()).get("message")).isEqualTo("Client TestClient updated successfully");
    }

    @Test
    @DisplayName("PUT /api/clients/{clientId} - not found")
    void testUpdateClient_NotFound() {
        ClientRequestDto dto = new ClientRequestDto();
        doThrow(new RecordNotFoundException("Not found")).when(clientsService).updateClient(eq("1"), any());
   
        assertThatThrownBy(() -> clientsController.updateClient("1", dto))  
        .isInstanceOf(RecordNotFoundException.class)  
        .hasMessageContaining("Not found"); 
      
    }

}
