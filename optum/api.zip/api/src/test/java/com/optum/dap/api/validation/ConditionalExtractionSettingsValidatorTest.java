package com.optum.dap.api.validation;

import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.constants.Constant.RowDelimiter;
import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.dto.ExtractionSettingsDto;
import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigDto;
import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ConditionalExtractionSettingsValidatorTest {

    private ConditionalExtractionSettingsValidator validator;
    private ConstraintValidatorContext context;

    @BeforeEach
    public void setup() {
        validator = new ConditionalExtractionSettingsValidator();
        context = Mockito.mock(ConstraintValidatorContext.class);

        ConstraintValidatorContext.ConstraintViolationBuilder builder =
            Mockito.mock(ConstraintValidatorContext.ConstraintViolationBuilder.class);
        ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext nodeBuilder =
            Mockito.mock(ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext.class);

        Mockito.when(context.buildConstraintViolationWithTemplate(Mockito.anyString()))
           .thenReturn(builder);
        Mockito.when(builder.addPropertyNode(Mockito.anyString()))
           .thenReturn(nodeBuilder);
        Mockito.when(nodeBuilder.addConstraintViolation())
           .thenReturn(context);
    }

    @Test
    public void testNullValue() {
        assertTrue(validator.isValid(null, context));
    }

    @Test
    public void testPendingStatusSkipsValidation() {
        FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
        dto.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.PENDING);
        dto.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PUSH);
        dto.setFeedConfig(null); // Should be ignored

        assertTrue(validator.isValid(dto, context));
    }

    @Test
    public void testNullExtractionSettingsFails() {
        FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
        dto.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE);
        dto.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PUSH);
        dto.setFeedConfig(new FeedConfigDto()); // No extraction settings

        assertFalse(validator.isValid(dto, context));
    }

    @Test
    public void testValidExtractionSettingsForPull() {
        ExtractionSettingsDto settings = new ExtractionSettingsDto();
        settings.setRowDelimiter(RowDelimiter.LF);
        settings.setColumnDelimiter(",");
        settings.setQuote(true);
        settings.setRollingDate(20250718);
        settings.setFileNameFormat("data_yyyyMMdd.csv");

        FeedConfigDto config = new FeedConfigDto();
        config.setExtractionSettings(settings);

        FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
        dto.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE);
        dto.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PULL);
        dto.setFeedConfig(config);

        assertTrue(validator.isValid(dto, context));
    }

    @Test
    public void testMissingFieldsForPullFails() {
        ExtractionSettingsDto settings = new ExtractionSettingsDto();
        settings.setRowDelimiter(null); // Invalid
        settings.setColumnDelimiter(""); // Invalid
        settings.setQuote(null); // Invalid
        settings.setRollingDate(null); // Invalid for PULL
        settings.setFileNameFormat(" "); // Invalid for PULL

        FeedConfigDto config = new FeedConfigDto();
        config.setExtractionSettings(settings);

        FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
        dto.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE);
        dto.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PULL);
        dto.setFeedConfig(config);

        boolean result = validator.isValid(dto, context);
        assertFalse(result, "Expected validation to fail due to missing fields for PULL feed type");
    }
}
