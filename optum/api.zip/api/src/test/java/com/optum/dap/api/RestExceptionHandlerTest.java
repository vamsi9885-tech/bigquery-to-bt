package com.optum.dap.api;

import com.optum.dap.api.exception.RecordNotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Path;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.MethodArgumentNotValidException;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for the {@link RestExceptionHandler} class.
 * Tests various exception handling scenarios in the API.
 */
@ExtendWith(MockitoExtension.class)
class RestExceptionHandlerTest {

    @InjectMocks
    private RestExceptionHandler exceptionHandler;

    @Mock
    private MethodArgumentNotValidException methodArgumentNotValidException;

    @Mock
    private BindingResult bindingResult;

    @Mock
    private ConstraintViolationException constraintViolationException;

    @Mock
    private HttpServletRequest request;

    @Mock
    private ConstraintViolation<Object> constraintViolation;

    @Mock
    private Path path;


    @Test
    @DisplayName("Should handle ConstraintViolationException correctly")
    void shouldHandleConstraintViolationException() {
        // Given
        Set<ConstraintViolation<?>> violations = new HashSet<>();
        violations.add(constraintViolation);
        
        when(constraintViolationException.getConstraintViolations()).thenReturn(violations);
        when(constraintViolation.getPropertyPath()).thenReturn(path);
        when(path.toString()).thenReturn("user.email");
        when(constraintViolation.getMessage()).thenReturn("must not be blank");

        // When
        ResponseEntity<ApiError> response = exceptionHandler.handle(constraintViolationException);

        // Then
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        ApiError apiError = response.getBody();
        assertNotNull(apiError);
        assertEquals(400, apiError.status());
        assertEquals(1, apiError.errors().size());
        assertEquals("user.email: must not be blank", apiError.errors().get(0));

        // Verify interactions
        verify(constraintViolationException).getConstraintViolations();
    }

    @Test
    @DisplayName("Should handle RecordNotFoundException correctly")
    void shouldHandleRecordNotFoundException() {
        // Given
        RecordNotFoundException exception = new RecordNotFoundException("Client with ID 123 not found");

        // When
        ResponseEntity<ApiError> response = exceptionHandler.handleNotFound(exception, request);

        // Then
        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        ApiError apiError = response.getBody();
        assertNotNull(apiError);
        assertEquals(404, apiError.status());
        assertEquals(1, apiError.errors().size());
        assertEquals("Client with ID 123 not found", apiError.errors().get(0));
    }

    @Test
    @DisplayName("Should handle generic exceptions correctly")
    void shouldHandleGenericException() {
        // Given
        Exception exception = new RuntimeException("Unexpected error occurred");

        // When
        ResponseEntity<ApiError> response = exceptionHandler.handleGeneric(exception, request);

        // Then
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        ApiError apiError = response.getBody();
        assertNotNull(apiError);
        assertEquals(500, apiError.status());
        assertEquals(1, apiError.errors().size());
        assertEquals("Internal server error", apiError.errors().get(0));
    }
}