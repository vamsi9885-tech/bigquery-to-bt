// package com.optum.dap.api.config;

// import com.auth0.jwt.JWT;
// import com.auth0.jwt.interfaces.Claim;
// import com.auth0.jwt.interfaces.DecodedJWT;
// import jakarta.servlet.http.HttpServletRequest;
// import jakarta.servlet.http.HttpServletResponse;
// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.mockito.MockedStatic;
// import org.springframework.security.core.Authentication;
// import org.springframework.security.oauth2.core.user.OAuth2User;
// import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
// import org.springframework.security.oauth2.core.oidc.OidcIdToken;
// import org.springframework.security.oauth2.core.oidc.user.OidcUser;

// import java.lang.reflect.Field;
// import java.time.Instant;
// import java.util.List;
// import java.util.Map;

// import static org.mockito.Mockito.*;

// public class CustomOAuth2SuccessHandlerTest {

//     private CustomOAuth2SuccessHandler handler;
//     private HttpServletRequest request;
//     private HttpServletResponse response;

//     @BeforeEach
//     public void setup() throws Exception {
//         handler = new CustomOAuth2SuccessHandler();
//         setPrivateField("skipAuthorization", false);
//         setPrivateField("requiredAdGroup", "test-group");
//         setPrivateField("accessDeniedUrl", "/access-denied");
//         setPrivateField("homePageURL", "/home");

//         request = mock(HttpServletRequest.class);
//         response = mock(HttpServletResponse.class);
//     }

//     private void setPrivateField(String fieldName, Object value) throws Exception {
//         Field field = handler.getClass().getDeclaredField(fieldName);
//         field.setAccessible(true);
//         field.set(handler, value);
//     }

//     @Test
//     public void testSkipAuthorization() throws Exception {
//         setPrivateField("skipAuthorization", true);

//         Authentication auth = mock(Authentication.class);
//         handler.onAuthenticationSuccess(request, response, auth);

//         verify(response).sendRedirect("/home");
//     }

//     @Test
//     public void testInvalidAuthenticationType() throws Exception {
//         Authentication auth = mock(Authentication.class);
//         handler.onAuthenticationSuccess(request, response, auth);

//         verify(response).sendRedirect("/access-denied");
//     }

//     @Test
//     public void testNullOidcUser() throws Exception {
//         OAuth2AuthenticationToken token = mock(OAuth2AuthenticationToken.class);
//         OAuth2User nonOidcUser = mock(OAuth2User.class); // Not an instance of OidcUser
//         when(token.getPrincipal()).thenReturn(nonOidcUser);


//         handler.onAuthenticationSuccess(request, response, token);

//         verify(response).sendRedirect("/access-denied");
//     }

//     @Test
//     public void testMissingAdGroupInToken() throws Exception {
//         OAuth2AuthenticationToken token = mock(OAuth2AuthenticationToken.class);
//         OidcUser oidcUser = mock(OidcUser.class);
//         OidcIdToken idToken = new OidcIdToken("fake-token", Instant.now(), Instant.now().plusSeconds(60), Map.of());

//         when(token.getPrincipal()).thenReturn(oidcUser);
//         when(oidcUser.getIdToken()).thenReturn(idToken);

//         DecodedJWT jwt = mock(DecodedJWT.class);
//         Claim claim = mock(Claim.class);
//         when(claim.asList(String.class)).thenReturn(List.of("other-group"));
//         when(jwt.getClaim("ad_groups")).thenReturn(claim);

//         try (MockedStatic<JWT> jwtStatic = mockStatic(JWT.class)) {
//             jwtStatic.when(() -> JWT.decode("fake-token")).thenReturn(jwt);
//             handler.onAuthenticationSuccess(request, response, token);
//         }

//         verify(response).sendRedirect("/access-denied");
//     }

//     @Test
//     public void testValidAdGroupInToken() throws Exception {
//         OAuth2AuthenticationToken token = mock(OAuth2AuthenticationToken.class);
//         OidcUser oidcUser = mock(OidcUser.class);
//         OidcIdToken idToken = new OidcIdToken("valid-token", Instant.now(), Instant.now().plusSeconds(60), Map.of());

//         when(token.getPrincipal()).thenReturn(oidcUser);
//         when(oidcUser.getIdToken()).thenReturn(idToken);

//         DecodedJWT jwt = mock(DecodedJWT.class);
//         Claim claim = mock(Claim.class);
//         when(claim.asList(String.class)).thenReturn(List.of("test-group"));
//         when(jwt.getClaim("ad_groups")).thenReturn(claim);

//         try (MockedStatic<JWT> jwtStatic = mockStatic(JWT.class)) {
//             jwtStatic.when(() -> JWT.decode("valid-token")).thenReturn(jwt);
//             handler.onAuthenticationSuccess(request, response, token);
//         }

//         verify(response).sendRedirect("/home");
//     }
// }
