package com.optum.dap.api.controller;
import com.optum.dap.api.dto.ClientRequestDto;
import com.optum.dap.api.service.IClientsService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;

import com.optum.dap.api.exception.RecordAlreadyExistException;

public class ClientsAuthControllerTest {
    
    @Mock
    private IClientsService clientsService;

    @InjectMocks
    private ClientsAuthController clientsAuthController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
     @Test
    @DisplayName("POST /api/clients - create client success")
    void testCreateClient_Success() {
        // Arrange
        ClientRequestDto dto = new ClientRequestDto();
        dto.setClientId("client123");
        dto.setClientName("New Test Client");
        dto.setActive(true);
        
        // Act
        ResponseEntity<?> response = clientsAuthController.createClient(dto);
        
        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(((java.util.Map<?, ?>) response.getBody()).get("message")).isEqualTo("Client client123 added successfully");
    }
    
    @Test
    @DisplayName("POST /api/clients - conflict when client already exists")
    void testCreateClient_Conflict() {
        // Arrange
        ClientRequestDto dto = new ClientRequestDto();
        dto.setClientId("existingClient");
        dto.setClientName("Existing Client");
        
        doThrow(new RecordAlreadyExistException("Client with ID existingClient already exists"))
            .when(clientsService).createClient(any());
            
        // Act  
        assertThatThrownBy(() -> clientsAuthController.createClient(dto))  
        .isInstanceOf(RecordAlreadyExistException.class)  
        .hasMessageContaining("Client with ID existingClient already exists"); 
    }
    
    @Test
    @DisplayName("POST /api/clients - internal error")
    void testCreateClient_InternalError() {
        // Arrange
        ClientRequestDto dto = new ClientRequestDto();
        dto.setClientId("client123");
        
        doThrow(new RuntimeException("Database connection error"))
            .when(clientsService).createClient(any());
            
        // Act
        assertThatThrownBy(() -> clientsAuthController.createClient(dto))  
        .isInstanceOf(RuntimeException.class)  
        .hasMessageContaining("Database connection error"); 
    }
    

}
