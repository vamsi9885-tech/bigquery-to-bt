package com.optum.dap.api.transformer;

import com.optum.dap.api.dto.ClientConfigDto;
import com.optum.dap.api.dto.ClientsResponseDto;
import com.optum.dap.api.dto.ClientFeedDto;
import com.optum.dap.api.model.ClientConfig;
import com.optum.dap.api.model.Clients;
import com.optum.dap.api.model.Feeds;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Collections;
import java.util.UUID;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for ClientDetailsTransformer.
 */
class ClientDetailsTransformerTest {

    private final ClientDetailsTransformer transformer = new ClientDetailsTransformer();

    @Test
    @DisplayName("Should transform Clients entity to ClientsResponseDto")
    void testToClientsResponseDto() {
        ClientConfig config = new ClientConfig();
        config.setInternalNotificationEmails("int@optum.com");
        config.setExternalNotificationEmails("ext@optum.com");
        config.setPreserveArchives(true);
        config.setPurgeOldFilesDays(30);
        config.setFeedCompletionNotificationEnabled(true);

        Feeds feed = new Feeds();
        feed.setFeedName("Feed1");
        feed.setFeedIdentifier(UUID.randomUUID());
        feed.setActive(true);

        Clients client = new Clients();
        client.setClientId("1");
        client.setClientName("Test Client");
        client.setActive(true);
        client.setClientConfig(config);
        client.setFeeds(List.of(feed));

        ClientsResponseDto dto = transformer.toClientsResponseDto(client);
        assertThat(dto).isNotNull();
        assertThat(dto.getClientId()).isEqualTo("1");
        assertThat(dto.getClientName()).isEqualTo("Test Client");
        assertThat(dto.isActive()).isTrue();
        assertThat(dto.getClientConfig()).isNotNull();
        assertThat(dto.getClientConfig().getInternalNotificationEmails()).isEqualTo("int@optum.com");
        assertThat(dto.getFeeds()).hasSize(1);
        assertThat(dto.getFeeds().get(0).getFeedName()).isEqualTo("Feed1");
    }

    @Test
    @DisplayName("Should return null when input client is null")
    void testToClientsResponseDto_Null() {
        assertThat(transformer.toClientsResponseDto(null)).isNull();
    }

    @Test
    @DisplayName("Should handle null config and feeds")
    void testToClientsResponseDto_NullConfigAndFeeds() {
        Clients client = new Clients();
        client.setClientId("2");
        client.setClientName("No Config Client");
        client.setActive(false);
        client.setClientConfig(null);
        client.setFeeds(null);
        ClientsResponseDto dto = transformer.toClientsResponseDto(client);
        assertThat(dto).isNotNull();
        assertThat(dto.getClientConfig()).isNull();
        assertThat(dto.getFeeds()).isEmpty();
    }

    @Test
    @DisplayName("Should handle null feed in feeds list")
    void testToClientFeedDto_NullFeed() {
        Clients client = new Clients();
        client.setClientId("3");
        client.setClientName("Null Feed Client");
        client.setActive(true);
        client.setClientConfig(null);
        client.setFeeds(Collections.emptyList());
        ClientsResponseDto dto = transformer.toClientsResponseDto(client);
        assertThat(dto).isNotNull();
        assertThat(dto.getFeeds()).isEmpty();
    }
}
