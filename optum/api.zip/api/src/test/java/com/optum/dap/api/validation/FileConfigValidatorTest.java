package com.optum.dap.api.validation;

import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.dto.FileDto;
import com.optum.dap.api.exception.BadRequestException;
import com.optum.dap.api.exception.RecordAlreadyExistException;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.repository.IFileRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.UUID;

import static com.optum.dap.api.constants.Constant.FeedType.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class FileConfigValidatorTest {

    private IFileRepository fileRepository;
    private FileConfigValidator validator;

    @BeforeEach
    public void setup() {
        fileRepository = mock(IFileRepository.class);
        validator = new FileConfigValidator(fileRepository);
    }

    @Test
    public void testValidateCreateRequest_validPullFile() {
        Feeds feed = createFeed(PULL);
        FileDto file = createFile("file1", "format1");

        when(fileRepository.existsByFeedIdentifierAndLogicalFileName(feed.getFeedIdentifier(), file.getLogicalFileName()))
                .thenReturn(false);

        assertDoesNotThrow(() -> validator.validateCreateRequest(List.of(file), feed));
    }

    @Test
    public void testValidateCreateRequest_duplicateFile() {
        Feeds feed = createFeed(PULL);
        FileDto file = createFile("file1", "format1");

        when(fileRepository.existsByFeedIdentifierAndLogicalFileName(feed.getFeedIdentifier(), file.getLogicalFileName()))
                .thenReturn(true);

        assertThrows(RecordAlreadyExistException.class, () -> validator.validateCreateRequest(List.of(file), feed));
    }

    @Test
    public void testValidateCreateRequest_missingFileIdForPull() {
        Feeds feed = createFeed(PULL);
        FileDto file = createFile(null, "format1");

        assertThrows(BadRequestException.class, () -> validator.validateCreateRequest(List.of(file), feed));
    }

    @Test
    public void testValidateCreateRequest_missingFileNameFormatForPull() {
        Feeds feed = createFeed(PULL);
        FileDto file = createFile("file1", null);

        assertThrows(BadRequestException.class, () -> validator.validateCreateRequest(List.of(file), feed));
    }

    @Test
    public void testValidateCreateRequest_pushFeed_skipsValidation() {
        Feeds feed = createFeed(PUSH);
        FileDto file = createFile(null, null); // Should be allowed

        assertDoesNotThrow(() -> validator.validateCreateRequest(List.of(file), feed));
    }

    @Test
    public void testValidateUpdateRequest_validPullFile() {
        Feeds feed = createFeed(PULL);
        FileDto file = createFile("file1", "format1");

        assertDoesNotThrow(() -> validator.validateUpdateRequest(file, feed));
    }

    // --- Helper Methods ---

    private Feeds createFeed(FeedType type) {
        Feeds feed = new Feeds();
        feed.setFeedType(type);
        feed.setFeedIdentifier(UUID.fromString("991ddccf-f171-4f1a-b473-14f549ed9106"));
        return feed;
    }

    private FileDto createFile(String fileId, String fileNameFormat) {
        FileDto dto = new FileDto();
        dto.setFileId(fileId);
        dto.setFileNameFormat(fileNameFormat);
        dto.setLogicalFileName("logical1");
        return dto;
    }
}
