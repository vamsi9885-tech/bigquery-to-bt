package com.optum.dap.api.controller;

import com.optum.dap.api.config.JwtTokenProvider;
import com.optum.dap.api.dto.FeedFrequencyResponseDto;
import com.optum.dap.api.service.IFeedFrequencyService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Unit tests for FeedFrequencyController.
 */
@WebMvcTest(FeedFrequencyController.class)
class FeedFrequencyControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private IFeedFrequencyService feedFrequencyService;
    @MockBean
    private JwtTokenProvider jwtTokenProvider;

    @Test
    @WithMockUser
    void testGetFeedFrequencies() throws Exception {
        // Arrange
        FeedFrequencyResponseDto frequency1 = new FeedFrequencyResponseDto();
        frequency1.setFrequencyType("DAILY");
        frequency1.setFeedWindowDates(7);
        frequency1.setSupportedFeedType("PULL");

        FeedFrequencyResponseDto frequency2 = new FeedFrequencyResponseDto();
        frequency2.setFrequencyType("WEEKLY");
        frequency2.setFeedWindowDates(30);
        frequency2.setSupportedFeedType("PUSH");

        List<FeedFrequencyResponseDto> mockFrequencies = Arrays.asList(frequency1, frequency2);
        Mockito.when(feedFrequencyService.getAllFeedFrequencies()).thenReturn(mockFrequencies);

        // Act
        mockMvc.perform(get("/api/feedfrequency")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].frequencyType").value("DAILY"))
                .andExpect(jsonPath("$[1].frequencyType").value("WEEKLY"));
    }
}