package com.optum.dap.api.validation;

import com.optum.dap.api.constants.Constant.ConnectionType;
import com.optum.dap.api.constants.Constant.FileTransferType;
import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.dto.*;
import com.optum.dap.api.exception.BadRequestException;
import com.optum.dap.api.exception.RecordAlreadyExistException;
import com.optum.dap.api.model.Clients;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.repository.FeedsRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.List;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class FeedConfigValidatorTest {

    private FeedsRepository feedsRepository;
    private FeedConfigValidator validator;

    @BeforeEach
    public void setup() {
        feedsRepository = mock(FeedsRepository.class);
        validator = new FeedConfigValidator(feedsRepository);
    }

    @Test
    public void testValidateFeedName_valid() {
        when(feedsRepository.existsByFeedNameAndClient_ClientId("feedA", "testclient")).thenReturn(false);
        assertDoesNotThrow(() -> validator.validateFeedName("feedA", "testclient"));
    }


    @Test
    public void testValidateFeedName_duplicate() {
        when(feedsRepository.existsByFeedNameAndClient_ClientId("feedA", "testclient")).thenReturn(true);
        assertThrows(RecordAlreadyExistException.class, () -> validator.validateFeedName("feedA", "testclient"));
    }

    @Test
    public void testValidateUpdateRequest_inactiveToInactive() {
        FeedConfigUpdateRequestDto dto = new FeedConfigUpdateRequestDto();
        dto.setIsActive(false);
        Feeds entity = new Feeds();
        entity.setActive(false);
        assertThrows(BadRequestException.class, () -> validator.validateUpdateRequest(dto, entity));
    }

    @Test
    public void testValidateFeedConfigByType_push_invalidExtraction() {
        FeedConfigCreateRequestDto dto = createValidCreateDto(FeedType.PUSH);
        dto.getFeedConfig().getExtractionSettings().setRollingDate(20250719);
        assertThrows(BadRequestException.class, () -> validator.validateCreateRequest(dto, "testclient"));
    }

    @Test
    public void testValidateFeedConfigByType_pullWithNtfs_missingFields() {
        FeedConfigCreateRequestDto dto = createValidCreateDto(FeedType.PULL_WITH_NTFS);
        dto.getFeedConfig().setConnectionSettings(null);
        assertThrows(BadRequestException.class, () -> validator.validateCreateRequest(dto, "testclient"));
    }


    // --- Helper Methods ---

    private FeedConfigCreateRequestDto createValidCreateDto(FeedType type) {
        FeedConfigCreateRequestDto dto = new FeedConfigCreateRequestDto();
        dto.setFeedName("feedA");
        dto.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PULL);
        dto.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE);
        dto.setIsActive(true);
        dto.setFrequencyId(1);
        dto.setConnectorType("SFTP");
        dto.setConnectorVersion("1.0");
        
        FeedConfigDto config = new FeedConfigDto();
        
        ExtractionSettingsDto extraction = new ExtractionSettingsDto();
        
        extraction.setRollingDate(20250722); // Example valid value

        ConnectionSettingsDto connection = new ConnectionSettingsDto();
        connection.setType(ConnectionType.NTFS); // Assuming SFTP is a valid enum
        connection.setConnectionString("sftp://example.com/data");
        connection.setNtfsFolderPath("/ntfs/path");

        // File transfer settings
        FileTransferSettingsDetailDto transferDetails = new FileTransferSettingsDetailDto();
        transferDetails.setHostName("sftp.example.com");

        transferDetails.setUserName("user");
        transferDetails.setKnownHostFile("/known_hosts");
        transferDetails.setLandingDirectory("/data");
        transferDetails.setEnable(true);

        FileTransferSettingsDto fileTransfer = new FileTransferSettingsDto();
        fileTransfer.setType(FileTransferType.ECG_SFTP); // Assuming SFTP is a valid enum
        fileTransfer.setSettings(transferDetails);

        config.setExtractionSettings(extraction);
        config.setConnectionSettings(connection);
        config.setFileTransferSettings(fileTransfer);
        dto.setFeedConfig(config);

        return dto;
    }

    private FeedConfigUpdateRequestDto createValidUpdateDto(String name, FeedStatus status) {
        FeedConfigUpdateRequestDto dto = new FeedConfigUpdateRequestDto();
        dto.setFeedName("feedA");
        dto.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE);
        dto.setIsActive(true);
        dto.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PULL);
        dto.setFrequencyId(1);
        dto.setConnectorType("SFTP");
        dto.setConnectorVersion("1.0");
        FeedConfigDto config = new FeedConfigDto();
        
        ExtractionSettingsDto extraction = new ExtractionSettingsDto();

        config.setExtractionSettings(extraction);
        config.setConnectionSettings(null);
        config.setFileTransferSettings(null);
        dto.setFeedConfig(config);
        return dto;
    }

    private Feeds createFeedEntity(String name, FeedStatus status, String clientId, String id) {
        Feeds feed = new Feeds();
        feed.setFeedName("feedB");
        feed.setFeedType(com.optum.dap.api.constants.Constant.FeedType.PUSH);
        feed.setActive(false);
        feed.setStatus(com.optum.dap.api.constants.Constant.FeedStatus.ACTIVE);
        feed.setFrequencyId(2); // Use frequencyId instead for test
        feed.setFeedIdentifier(UUID.fromString("bbbbbbbb-cccc-dddd-eeee-ffffffffffff"));

        Clients client = new Clients();
        client.setClientId(clientId);
        feed.setClient(client);
        
        feed.setCreatedBy(null);
        feed.setCreatedDate(null);

        return feed;
    }
}
