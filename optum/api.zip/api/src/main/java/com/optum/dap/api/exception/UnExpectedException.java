package com.optum.dap.api.exception;

public class UnExpectedException extends RuntimeException {
    
    public UnExpectedException(String message) {
        super(message);
    }

    public UnExpectedException(String message, Throwable cause) {
        super(message, cause);
        cause.printStackTrace();
    }
}
