package com.optum.dap.api.transformer;

import jakarta.persistence.Converter;
import com.optum.dap.api.model.RuntimeSettingConfig;

@Converter(autoApply = false)
public class RunTimeConfigJsonConverter extends GenericJsonbConverter<RuntimeSettingConfig> {
    public RunTimeConfigJsonConverter() {
        super(RuntimeSettingConfig.class);
    }
}