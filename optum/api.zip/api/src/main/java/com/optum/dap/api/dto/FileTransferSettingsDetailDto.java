package com.optum.dap.api.dto;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;

/**
 * DTO for file transfer settings details.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FileTransferSettingsDetailDto {
    private String hostName;

    // Username validation is now conditional
    private String userName;

    private String knownHostFile;

    private String landingDirectory;

    @NotNull(message = "Enable flag must not be null")
    private Boolean enable = false;

}