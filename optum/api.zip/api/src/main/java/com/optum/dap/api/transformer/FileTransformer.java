package com.optum.dap.api.transformer;

import java.io.File;

import com.optum.dap.api.dto.FileDto;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.model.Files;

import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.UUID;

import com.optum.dap.api.model.FileConfig;

/**
 * Transformer for FileConfig DTOs and Entity.
 * Handles mapping between DTOs and Files, including JSONB serialization.
 */
@Component
public class FileTransformer {

    /**
     * Converts Files to FileDto.
     * @param entity Files
     * @return FileDto
     */
    public FileDto toDto(Files entity) {
        if (entity == null) return null;
        FileDto dto = new FileDto();
        dto.setLogicalFileName(entity.getLogicalFileName());
        FileConfig fileConfig = entity.getFileConfig();
        dto.setFileId(fileConfig.getFileId());
        dto.setOrder(fileConfig.getOrder());
        dto.setFileNameFormat(fileConfig.getFileNameFormat());
        dto.setPartCount(fileConfig.getPartCount());
        dto.setPartStartSeq(fileConfig.getPartStartSeq());
        dto.setParameters(CommonTransformer.mapParametersToParameterDtos(fileConfig.getParameters()));
        dto.setFilter(fileConfig.getFilter());
        dto.setIsMandatory(fileConfig.getIsMandatory());

         // sets both transient and json fields
        return dto;
    }

    /**
     * Converts FileDto to Files.
     * @param dto FileDto
     * @param feedIdentifier UUID of the feed
     * @param user user performing the operation
     * @return Files
     */
    public Files toEntity(FileDto dto, UUID feedIdentifier, String user) {
        if (dto == null) return null;
        Files entity = new Files();
        entity.setFeedIdentifier(feedIdentifier);
        entity.setLogicalFileName(dto.getLogicalFileName());
        entity.setFileConfig(toFileConfig(dto , new FileConfig())); // sets both transient and json fields
        entity.setActive(dto.getIsMandatory() != null ? dto.getIsMandatory() : true);
        entity.setCreatedBy(user);
        entity.setCreatedDate(LocalDateTime.now());
        entity.setModifiedBy(user);
        entity.setModifiedDate(LocalDateTime.now());
        return entity;
    }

     /**
     * Converts FileDto to Files.
     * @param dto FileDto
     * @param feedIdentifier UUID of the feed
     * @param user user performing the operation
     * @return Files
     */
    public Files updateToEntity(Files file,FileDto dto, UUID feedIdentifier, String user) {
        if (dto == null || file == null) return null;
        file.setFileConfig(toFileConfig(dto, file.getFileConfig())); // sets both transient and json fields
        file.setActive(dto.getIsMandatory() != null ? dto.getIsMandatory() : true);
        file.setModifiedBy(user);
        file.setModifiedDate(LocalDateTime.now());
        return file; // changed from entity to file
    }
    /**
     * Converts FileDto to Files with Feeds reference.
     * @param dto FileDto
     * @param feed Feeds
     *     * @param user user performing the operation
     * @return Files
     */
    public Files toEntity(FileDto dto, Feeds feed, String user) {
        if (dto == null || feed == null) return null;
        Files entity = toEntity(dto, feed.getFeedIdentifier(), user);
        entity.setFeed(feed);
        return entity;
    }

    public FileConfig toFileConfig(FileDto dto,FileConfig fileConfig ) {
        if (dto == null) return null;
        fileConfig.setFileId(dto.getFileId());
        fileConfig.setOrder(dto.getOrder());
        fileConfig.setFileNameFormat(dto.getFileNameFormat());
        fileConfig.setPartCount(dto.getPartCount());
        fileConfig.setPartStartSeq(dto.getPartStartSeq());
        fileConfig.setParameters(CommonTransformer.convertDtoListToEntityList(dto.getParameters()));
        fileConfig.setFilter(dto.getFilter());
        fileConfig.setIsMandatory(dto.getIsMandatory());
        return fileConfig;
    }

}