package com.optum.dap.api.service.impl;

import com.optum.dap.api.constants.Constant.AuditType;
import com.optum.dap.api.dto.RuntimeConfigDto;
import com.optum.dap.api.exception.RecordNotFoundException;
import com.optum.dap.api.model.ConnectorConfig;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.model.RuntimeSettings;
import com.optum.dap.api.repository.IConnectorConfigRepository;
import com.optum.dap.api.repository.FeedsRepository;
import com.optum.dap.api.repository.IRuntimeSettingsRepository;
import com.optum.dap.api.service.IAuditService;
import com.optum.dap.api.service.IRuntimeSettingsService;
import com.optum.dap.api.transformer.RuntimeConfigTransformer;
import com.optum.dap.api.validation.RuntimeSettingsValidator;

import lombok.extern.slf4j.Slf4j;

import com.optum.dap.api.exception.BadRequestException;
import com.optum.dap.api.utils.Utils;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.optum.dap.api.model.AuditLog;
import com.optum.dap.api.utils.DeepCopyUtil;

/**
 * Service implementation for runtime settings.
 * Handles business logic for runtime config CRUD and connector config updates.
 */
@Slf4j
@Service
public class RuntimeSettingsServiceImpl implements IRuntimeSettingsService {
    @Autowired
    private IRuntimeSettingsRepository runtimeSettingsRepository;
    @Autowired
    private FeedsRepository feedsRepository;
    @Autowired
    private IConnectorConfigRepository connectorConfigRepository;
    @Autowired
    private RuntimeConfigTransformer transformer;
    @Autowired
    private RuntimeSettingsValidator validator;

    @Autowired
    private DeepCopyUtil deepCopyUtil;

    @Autowired
    private IAuditService auditService;

    /**
     * Retrieves the runtime config for a feed, including spec fields from connector config.
     * @param clientId client identifier
     * @param feedIdentifier feed identifier
     * @return RuntimeConfigDto
     */
    @Override
    public RuntimeConfigDto getRuntimeConfig(String clientId, UUID feedIdentifier) {
        try {
            Feeds feed = getFeedOrThrow(feedIdentifier, clientId);
            RuntimeSettings settings = runtimeSettingsRepository.findByFeedIdentifier(feed.getFeedIdentifier())
                    .orElseThrow(() -> new RecordNotFoundException("Runtime settings not found for feed: " + feedIdentifier));
            ConnectorConfig connectorConfig = connectorConfigRepository.findByFeed_FeedIdentifier(feed.getFeedIdentifier())
                    .orElseThrow(() -> new RecordNotFoundException("Connector config not found for feed: " + feedIdentifier));
            return transformer.toDto(settings, connectorConfig);
        } catch (RecordNotFoundException ex) {
         log.warn("Runtime config not found for clientId={}, feedIdentifier={}: {}",
                    Utils.sanitizeString(clientId),
                    feedIdentifier != null ? feedIdentifier.toString() : null,
                    Utils.sanitizeContent(ex.getMessage()));
            throw ex;   
        }
        catch (Exception ex) {
            log.error("Error retrieving runtime config for clientId={}, feedIdentifier={}: {}",
                    Utils.sanitizeString(clientId),
                    feedIdentifier != null ? feedIdentifier.toString() : null,
                    Utils.sanitizeContent(ex.getMessage()), ex);
            throw ex;
        }
    }

    /**
     * Updates or creates the runtime config for a feed, and updates connector config spec fields.
     * @param clientId client identifier
     * @param feedIdentifier feed identifier
     * @param dto RuntimeConfigDto
     */
    @Override
    @Transactional
    public void updateRuntimeConfig(String clientId, UUID feedIdentifier, RuntimeConfigDto dto) {
        String sanitizedClientId = Utils.sanitizeString(clientId);
        try {
           
            Feeds feed = getFeedOrThrow(feedIdentifier, clientId);
            if (!feed.isActive()) {
                log.error("Cannot save as : Feed {} is not active.", Utils.sanitizeString(feedIdentifier.toString()));
                throw new BadRequestException("Cannot save as : Feed " + feedIdentifier + " is not active.");
            }

            validator.validate(dto, feed);
            log.info("Successfully validated the requested runtime settings for feed: {} clientId: {}", feedIdentifier, sanitizedClientId);
            // Checking for connector config existence before making any changes
            ConnectorConfig connectorConfig = connectorConfigRepository.findByFeed_FeedIdentifier(feed.getFeedIdentifier())
                    .orElseThrow(() -> new RecordNotFoundException("Connector config not found for feed: " + feedIdentifier));
            RuntimeSettings settings = runtimeSettingsRepository.findByFeedIdentifier(feed.getFeedIdentifier())
                    .orElse(RuntimeSettings.builder()
                            .runTimeConfigId(UUID.randomUUID())
                            .feedIdentifier(feed.getFeedIdentifier())
                            .build());
            RuntimeSettings oldSettings = deepCopyUtil.deepCopy(settings, RuntimeSettings.class);
            ConnectorConfig oldconnectorConfig  = deepCopyUtil.deepCopy(connectorConfig, ConnectorConfig.class);
            log.info("Updating runtime config for clientId={}, feedIdentifier={}", 
            sanitizedClientId, 
                    feedIdentifier != null ? feedIdentifier.toString() : null);
            transformer.updateEntityFromDto(dto, settings);
            transformer.updateConnectorConfigFromDto(dto, connectorConfig);

            //Save both after all checks and updates
            runtimeSettingsRepository.save(settings);
            connectorConfigRepository.save(connectorConfig);

             auditService.logAudit(AuditType.RUNTIMESETTINGS_UPDATE, "RunTimeSettings", settings, oldSettings, clientId, feedIdentifier);
            auditService.logAudit(AuditType.CONNECTORCONFIG_UPDATE, "Connector_config", connectorConfig, oldconnectorConfig, clientId, feedIdentifier);
            
             log.info("Successfully updated runtime config for clientId={}, feedIdentifier={}", 
               sanitizedClientId, 
                    feedIdentifier != null ? feedIdentifier.toString() : null);
        } catch (Exception ex) {
            log.error("Error updating runtime config for clientId={}, feedIdentifier={}: {}",
                    sanitizedClientId,
                    feedIdentifier != null ? feedIdentifier.toString() : null,
                    Utils.sanitizeContent(ex.getMessage()), ex);
            throw ex;
        }
    }

    /**
     * Helper to fetch and validate feed existence and ownership.
     * @param feedIdentifier feed identifier
     * @param clientId client identifier
     * @return Feeds entity
     * @throws RecordNotFoundException if feed does not exist or does not belong to client
     */
    private Feeds getFeedOrThrow(UUID feedIdentifier, String clientId) {
        try {
            Feeds feed = feedsRepository.findById(feedIdentifier)
                    .orElseThrow(() -> new RecordNotFoundException("Feed not found: " + feedIdentifier));
            if (feed.getClient() == null || !feed.getClient().getClientId().equals(clientId)) {
                log.warn("Feed {} does not belong to client {}", Utils.sanitizeString(feedIdentifier.toString()), Utils.sanitizeString(clientId));
                throw new RecordNotFoundException("Feed does not belong to the specified client");
            }
            return feed;
        } catch (Exception ex) {
            log.error("Error fetching feed for clientId={}, feedIdentifier={}: {}",
                    Utils.sanitizeString(clientId),
                    feedIdentifier != null ? feedIdentifier.toString() : null,
                    Utils.sanitizeContent(ex.getMessage()), ex);
            throw ex;
        }
    }
}