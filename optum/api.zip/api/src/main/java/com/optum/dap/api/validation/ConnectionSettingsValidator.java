package com.optum.dap.api.validation;

import com.optum.dap.api.constants.Constant.ConnectionType;
import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.dto.ConnectionSettingsDto;
import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigUpdateRequestDto;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * Validator implementation for ConditionalConnectionSettingsValidation.
 * Validates connection settings based on feed type.
 */
public class ConnectionSettingsValidator implements ConstraintValidator<ConditionalConnectionSettingsValidation, Object> {

    @Override
    public void initialize(ConditionalConnectionSettingsValidation constraintAnnotation) {
        // No initialization needed
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        if (value == null) return true;

        FeedType feedType;
        FeedStatus status;
        ConnectionSettingsDto connectionSettings;

        if (value instanceof FeedConfigCreateRequestDto dto) {
            if (dto.getFeedConfig() == null) return true;
            feedType = dto.getFeedType();
            status = dto.getStatus();
            connectionSettings = dto.getFeedConfig().getConnectionSettings();
        } else if (value instanceof FeedConfigUpdateRequestDto dto) {
            if (dto.getFeedConfig() == null) return true;
            feedType = dto.getFeedType();
            status = dto.getStatus();
            connectionSettings = dto.getFeedConfig().getConnectionSettings();
        } else {
            return fail(context, "invalid object");
        }

        if (feedType == null) return fail(context, "Feed Type cannot be null");
        if (feedType == FeedType.PUSH) return validatePush(connectionSettings, context);
        if (status == FeedStatus.PENDING) return true;
        if (connectionSettings.getType() == null) return fail(context, "Connection Type cannot be null");

        return switch (feedType) {
            case PULL_WITH_NTFS -> validatePullWithNtfs(connectionSettings, context);
            case PULL -> validatePull(connectionSettings, context);
            default -> true;
        };  
    }

    private boolean validatePush(ConnectionSettingsDto settings, ConstraintValidatorContext context) {
        if (settings != null) return fail(context, "Connection settings must be null for PUSH feed type");
        return true;
    }

    private boolean validatePullWithNtfs(ConnectionSettingsDto settings, ConstraintValidatorContext context) {
        if (settings == null) return fail(context, "Connection settings cannot be null for PULL_WITH_NTFS feed type");
        if (settings.getType() != ConnectionType.NTFS) return fail(context, "Connection type must be NTFS for PULL_WITH_NTFS feed type");
        if (isNullOrBlank(settings.getNtfsFolderPath())) return fail(context, "NTFS folder path must not be blank for PULL_WITH_NTFS feed type");
        return true;
    }

    private boolean validatePull(ConnectionSettingsDto settings, ConstraintValidatorContext context) {
        if (settings == null) return fail(context, "Connection settings cannot be null for PULL feed type");
        if (settings.getType() == ConnectionType.NTFS) return fail(context, "Connection type must not be NTFS for PULL feed type");
        if (!isNullOrBlank(settings.getNtfsFolderPath())) return fail(context, "NTFS folder path must be null for PULL feed type");
        if (isNullOrBlank(settings.getConnectionString())) return fail(context, "Connection string must not be blank for PULL feed type");
        return true;
    }

    private boolean fail(ConstraintValidatorContext context, String message) {
        addConstraintViolation(context, message);
        return false;
    }

    private void addConstraintViolation(ConstraintValidatorContext context, String message) {
        context.buildConstraintViolationWithTemplate(message)
               .addPropertyNode("feedConfig.connectionSettings")
               .addConstraintViolation();
    }

    private boolean isNullOrBlank(String str) {
        return str == null || str.trim().isEmpty();
    }
}
