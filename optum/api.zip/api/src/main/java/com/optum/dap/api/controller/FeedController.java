package com.optum.dap.api.controller;

import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigUpdateRequestDto;
import com.optum.dap.api.dto.FeedResponseDto;
import com.optum.dap.api.service.IFeedService;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.Map;

import com.optum.dap.api.utils.Utils;

import java.util.UUID;

import com.optum.dap.api.exception.BadRequestException;

/**
 * REST controller for feed config APIs.
 * Follows RESTful conventions and Spring Boot best practices.
 */
@Slf4j
@RestController
@RequestMapping("/api/clients/{clientId}/feeds")
public class FeedController {

    @Autowired
    private IFeedService feedService;

    /**
     * POST endpoint to create a new feed config.
     * The clientId is taken from the path, not the request body.
     */
    @PostMapping
    public ResponseEntity<?> createFeedConfig(
            @PathVariable String clientId,
            @RequestBody @Valid FeedConfigCreateRequestDto requestDto) {
        log.info("Creating feed config for clientId: {}", Utils.sanitizeString(clientId));
        FeedResponseDto response = feedService.createFeedConfig(clientId, requestDto);
        Map<String, Object> result = new HashMap<>();
        result.put("message", "Feed " + response.getFeedName() + " created successfully");
        result.put("data", response);
        return ResponseEntity.ok(result);
    }

    /**
     * PUT endpoint to update an existing feed config.
     * The feedIdentifier must be provided as a path variable.
     */
    @PutMapping("/{feedIdentifier}")
    public ResponseEntity<?> updateFeedConfig(
            @PathVariable String clientId,
            @PathVariable String feedIdentifier,
            @RequestBody @Valid FeedConfigUpdateRequestDto requestDto) {
        log.info("Updating feed config for clientId: {}, feedIdentifier: {}", Utils.sanitizeString(clientId), Utils.sanitizeString(feedIdentifier));
        String errorMessage = null;
        if (Utils.isNullOrEmpty(feedIdentifier)) {
            errorMessage = "Feed identifier must not be null or empty";
        }
        else if (Utils.isNullOrEmpty(clientId)) {
            errorMessage = "Client ID must not be null or empty";
        }
        else if(requestDto.getFeedIdentifier() != null && !requestDto.getFeedIdentifier().equals(feedIdentifier)) {
            errorMessage = "Feed identifier in request body does not match path variable";
        }
        else if(feedIdentifier != null && !Utils.isValidUUID(feedIdentifier)) {
            errorMessage = "Feed identifier must be a valid UUID";

        }

        if( errorMessage != null) {
            log.error(errorMessage);
            throw new BadRequestException(errorMessage);
        }
        FeedResponseDto response = feedService.updateFeedConfig(clientId, feedIdentifier, requestDto);
        Map<String, Object> result = new HashMap<>();
        result.put("message", "Feed " + response.getFeedName() + " updated successfully");
        result.put("data", response);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{feedIdentifier}")
    public ResponseEntity<?> GetFeedConfig(
            @PathVariable String clientId,
            @PathVariable String feedIdentifier) {
        log.info("Fetching feed config for clientId: {}, feedIdentifier: {}", Utils.sanitizeString(clientId), Utils.sanitizeString(feedIdentifier));
        
        if (Utils.isNullOrEmpty(clientId)) {
            throw new BadRequestException("Client ID must not be null or empty");
        }
        
        if (Utils.isNullOrEmpty(feedIdentifier) || !Utils.isValidUUID(feedIdentifier)) {
            throw new BadRequestException("Feed identifier must not be null or empty and must be a valid UUID");
        }

        FeedResponseDto response = feedService.getFeedConfig(clientId, feedIdentifier);
        if (response == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(response);
    }
}