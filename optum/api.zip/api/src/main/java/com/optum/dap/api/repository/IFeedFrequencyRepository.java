package com.optum.dap.api.repository;

import com.optum.dap.api.model.FeedFrequency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository for FeedFrequency.
 */
@Repository
public interface IFeedFrequencyRepository extends JpaRepository<FeedFrequency, Integer> {
}