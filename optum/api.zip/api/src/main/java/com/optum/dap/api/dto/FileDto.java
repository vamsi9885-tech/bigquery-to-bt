package com.optum.dap.api.dto;

import lombok.Data;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * DTO for file configuration for a feed.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FileDto {
    private String fileId;

    @Min(value = 0, message = "order must be zero or positive")
    private Integer order;

    @NotBlank(message = "fileNameFormat must not be blank")
    @NotNull(message = "fileNameFormat must not be null")
    @Size(max = 255, message = "fileNameFormat must be less than 255 characters long")
    private String fileNameFormat;

    @NotBlank(message = "logicalFileName must not be blank")
    @Size(max = 255, message = "logicalFileName must be less than 255 characters long")
    @Pattern(regexp = "^[a-zA-Z0-9_-]+$", message = "Input must contain letters and numbers.")
    private String logicalFileName;

    @NotNull(message = "partCount must not be null")
    @Min(value = 1, message = "partCount must be at least 1")
    private Integer partCount = 1;

    @NotNull(message = "partStartSeq must not be null")
    @Min(value = 1, message = "partStartSeq must be at least 1")
    private Integer partStartSeq = 1;

    @Valid
    private List<@Valid ParameterDto> parameters;

    private String filter;

    @NotNull(message = "isMandatory must not be null")
    private Boolean isMandatory = true;
}