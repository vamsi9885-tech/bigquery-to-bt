package com.optum.dap.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.dap.api.constants.Constant.ConnectionType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConnectionSettings {

    private ConnectionType type;
    @JsonProperty("connection_string")
    private String connectionString;

    @JsonProperty("ntfs_folder_path")
    private String ntfsFolderPath;
}
