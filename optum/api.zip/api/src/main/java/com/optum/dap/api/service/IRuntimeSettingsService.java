package com.optum.dap.api.service;
import java.util.UUID;
import com.optum.dap.api.dto.RuntimeConfigDto;

/**
 * Service interface for runtime settings.
 */
public interface IRuntimeSettingsService {
    RuntimeConfigDto getRuntimeConfig(String clientId, UUID feedIdentifier);
    void updateRuntimeConfig(String clientId, UUID feedIdentifier, RuntimeConfigDto dto);
}
