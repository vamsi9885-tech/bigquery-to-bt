package com.optum.dap.api.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.regex.Pattern;
import java.util.Arrays;

public class SemicolonSeparatedEmailsValidator implements ConstraintValidator<SemicolonSeparatedEmails, String> {
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"
    );

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null || value.isBlank()) return true; // Use @NotBlank for required

        return Arrays.stream(value.split("\\s*;\\s*"))  
                     .allMatch(e -> EMAIL_PATTERN.matcher(e).matches());
    }
}