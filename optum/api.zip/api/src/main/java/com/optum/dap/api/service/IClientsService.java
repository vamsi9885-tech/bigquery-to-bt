package com.optum.dap.api.service;

import com.optum.dap.api.dto.ClientsDetailsDto;
import com.optum.dap.api.dto.ClientsResponseDto;
import com.optum.dap.api.dto.ClientRequestDto;
import com.optum.dap.api.dto.ClientFeedsResponseDto;

import java.util.List;

/**
 * Service interface for managing client details.
 *
 * This interface defines methods to interact with client data.
 */
public interface IClientsService {
    /**
     * Fetch all client details.
     *
     * @return List of ClientsDetailsDto.
     */
    List<ClientsDetailsDto> getAllClients();

    /**
     * Fetch client details by clientId.
     *
     * @param clientId the client identifier
     * @return ClientsResponseDto
     */
    ClientsResponseDto getClientDetailsById(String clientId);
    /**
     * Create a new client.
     * @param requestDto the client details
     */
    void createClient(ClientRequestDto requestDto);

    /**
     * Update an existing client.
     * @param clientId the client identifier
     * @param requestDto the client details
     */
    void updateClient(String clientId, ClientRequestDto requestDto);

    /**
     * Fetch all feeds for a client.
     *
     * @param clientId the client identifier
     * @return ClientFeedsResponseDto containing client details and all feeds
     */
    ClientFeedsResponseDto getAllFeedsByClientId(String clientId);

}