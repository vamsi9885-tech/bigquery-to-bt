package com.optum.dap.api.dto;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.constants.Constant.FeedType;

import lombok.Getter;
import lombok.Setter;

/**
 * DTO representing a feed for a client.
 */
@Getter
@Setter
public class ClientFeedDto {
    private String feedName;
    private String feedId;
    @JsonProperty("isActive")
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    private boolean isActive;
    private FeedStatus status;
    private FeedType feedType;
    private String feedFrequency;
}