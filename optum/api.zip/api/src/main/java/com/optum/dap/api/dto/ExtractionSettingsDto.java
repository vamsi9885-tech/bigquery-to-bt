package com.optum.dap.api.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.optum.dap.api.constants.Constant.RowDelimiter;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter; // Added for default value
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExtractionSettingsDto {
    @Min(value = 0, message = "Rolling date must be zero or positive")
    private Integer rollingDate;

    private String fileNameFormat;

    @NotNull(message = "Row delimiter must not be null")
    private RowDelimiter rowDelimiter;


    private String columnDelimiter;

    @NotNull(message = "Quote must not be null")
    private Boolean quote;

    private String storageBasePath;

    private String filter;
    
    @Valid
    private List<ParameterDto> parameters = null;

    @Valid
    private List<String> dataCleansing = new ArrayList<>();
}