package com.optum.dap.api.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Data
@NoArgsConstructor
@Entity
@Table(name = "connector_config")
public class ConnectorConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "connector_id")
    private UUID connectorId;

    @Column(name = "connector_type", nullable = false)
    private String connectorType;

    @Column(name = "emr_version", nullable = false)
    private String emrVersion;

    @Column(name = "spec_name")
    private String specName;

    @Column(name = "spec_version")
    private String specVersion;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "feed_identifier", referencedColumnName = "feed_identifier")
    @JsonBackReference
    private Feeds feed;
}