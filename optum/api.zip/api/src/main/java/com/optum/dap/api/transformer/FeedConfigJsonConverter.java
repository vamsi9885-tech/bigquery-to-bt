package com.optum.dap.api.transformer;

import jakarta.persistence.Converter;
import com.optum.dap.api.model.FeedConfig;

@Converter(autoApply = false)
public class FeedConfigJsonConverter extends GenericJsonbConverter<FeedConfig> {
    public FeedConfigJsonConverter() {
        super(FeedConfig.class);
    }
}