package com.optum.dap.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull; 
import lombok.Data; 

/**
 * DTO for feedConfig field in FeedConfigCreateRequestDto and FeedConfigUpdateRequestDto.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FeedConfigDto {
    @Valid
    @NotNull(message = "Extraction settings must not be null")
    private ExtractionSettingsDto extractionSettings;

    @Valid
    private ConnectionSettingsDto connectionSettings;

    @Valid
    private FileTransferSettingsDto fileTransferSettings;
}