package com.optum.dap.api.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

import com.optum.dap.api.constants.Constant;

import com.optum.dap.api.utils.Utils;

/**
 * Filter to log requests and responses.
 * This filter should execute earlier than other filters in the chain to ensure
 * request body logging occurs before controller execution.
 */
@Slf4j
@Component
@Order(Constant.REQUEST_LOGGING_FILTER) // Ensure this filter runs at the correct order
public class RequestLoggingFilter extends OncePerRequestFilter {

    private static final String REQUEST_ID_ATTRIBUTE = "requestId";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        // Generate a unique ID for this request for correlation in logs
        String requestId = UUID.randomUUID().toString();
        request.setAttribute(REQUEST_ID_ATTRIBUTE, requestId);
        
        // Wrap request and response to allow reading the body multiple times
        ContentCachingRequestWrapper requestWrapper = new ContentCachingRequestWrapper(request);
        ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);
        
        // Log basic request information before processing
        logRequestBasicInfo(requestWrapper, requestId);
        
        try {
            // Continue with filter chain to execute controllers
            filterChain.doFilter(requestWrapper, responseWrapper);
        } finally {
            // Log request and response details after controller processing
            // By now the request body has been read and cached
            logRequestBodyIfPresent(requestWrapper, requestId);
            logResponseDetails(requestWrapper, responseWrapper, requestId);
            
            // This is crucial - it copies the cached response back to the original response
            responseWrapper.copyBodyToResponse();
        }
    }
    
    /**
     * Logs basic request details excluding body
     */
    private void logRequestBasicInfo(ContentCachingRequestWrapper request, String requestId) {
        String method = request.getMethod();
        String uri = request.getRequestURI();
        String queryString = request.getQueryString();
        // Log basic request information
        log.info("[{}] Incoming Request: Method: {} URL: {} QueryString: {}",
                requestId,
                method,
                uri,
                queryString != null ? "?" + queryString : ""
                );
    }
    
    /**
     * Logs request body if present after it has been consumed
     */
    private void logRequestBodyIfPresent(ContentCachingRequestWrapper request, String requestId) {
        String method = request.getMethod();
        
        // For POST/PUT/PATCH requests, log the body content
        if (isBodyEligibleForLogging(method)) {
            byte[] content = request.getContentAsByteArray();
            if (content.length > 0) {
                try {
                    String contentAsString = new String(content, StandardCharsets.UTF_8);
                    String sanitizedContent = Utils.sanitizeContent(contentAsString);
                    log.info("[{}] Request Body: {}", requestId, sanitizedContent);
                } catch (Exception e) {
                    log.warn("[{}] Failed to process request body: {}", requestId, e.getMessage());
                }
            }
        }
    }
    
    /**
     * Logs response details after controller processing
     */
    private void logResponseDetails(ContentCachingRequestWrapper request, ContentCachingResponseWrapper response, String requestId) {
        // Log the response status and body
        int status = response.getStatus();
        String method = request.getMethod();
        String uri = request.getRequestURI();

        log.info("[{}] Request Completed : Method: {} URI: {} Response Status: {} ({})",
                requestId, method, uri, status, getStatusText(status));

        // Optionally log response body for debugging at DEBUG level
        if (log.isDebugEnabled()) {
            byte[] content = response.getContentAsByteArray();
            if (content.length > 0) {
                String contentAsString = new String(content, StandardCharsets.UTF_8);
                // Truncate very large responses for the log
                String truncatedContent = contentAsString.length() > 1000 ? 
                        contentAsString.substring(0, 1000) + "... [truncated]" : contentAsString;
                log.debug("[{}] Response Body: {}", requestId, truncatedContent);
            }
        }
    }
    
    /**
     * Check if this request method typically has a body that should be logged
     */
    private boolean isBodyEligibleForLogging(String method) {
        return "POST".equalsIgnoreCase(method) || 
               "PUT".equalsIgnoreCase(method) || 
               "PATCH".equalsIgnoreCase(method);
    }
    
    /**
     * Maps HTTP status code to a text description
     */
    private String getStatusText(int statusCode) {
        if (statusCode >= 200 && statusCode < 300) {
            return "OK";
        } else if (statusCode >= 300 && statusCode < 400) {
            return "Redirect";
        } else if (statusCode >= 400 && statusCode < 500) {
            return "Client Error";
        } else if (statusCode >= 500) {
            return "Server Error";
        }
        return "Unknown";
    }
}