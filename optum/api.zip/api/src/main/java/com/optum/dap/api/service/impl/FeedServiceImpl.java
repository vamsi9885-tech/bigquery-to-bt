package com.optum.dap.api.service.impl;

import com.optum.dap.api.constants.Constant.AuditType;
import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigUpdateRequestDto;
import com.optum.dap.api.dto.FeedResponseDto;
import com.optum.dap.api.exception.BadRequestException;
import com.optum.dap.api.exception.RecordNotFoundException;
import com.optum.dap.api.exception.UnExpectedException;
import com.optum.dap.api.exception.RecordAlreadyExistException;
import com.optum.dap.api.model.Clients;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.repository.ClientsRepository;
import com.optum.dap.api.repository.FeedsRepository;
import com.optum.dap.api.transformer.FeedConfigTransformer;
import com.optum.dap.api.service.IAuditService;
import com.optum.dap.api.service.IFeedService;
import com.optum.dap.api.utils.Utils;
import com.optum.dap.api.validation.FeedConfigValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.optum.dap.api.utils.DeepCopyUtil;

import java.util.UUID;

/**
 * Service implementation for managing FeedConfig.
 * Handles business logic for feed creation and update.
 */
@Slf4j
@Service
public class FeedServiceImpl implements IFeedService {

    @Autowired
    private FeedsRepository feedsRepository;

    @Autowired
    private IAuditService auditService;

    @Autowired
    private ClientsRepository clientsRepository;

    @Autowired
    private FeedConfigTransformer feedConfigTransformer;

    @Autowired
    private FeedConfigValidator feedConfigValidator;

    @Autowired
    private DeepCopyUtil deepCopyUtil;
    /**
     * Creates a new FeedConfig for a client.
     * Validates input, checks for duplicates, and persists the entity.
     *
     * @param clientId the client identifier
     * @param dto      the feed config creation request DTO
     * @return FeedResponseDto with created feed details
     */
    @Override
    @Transactional
    public FeedResponseDto createFeedConfig(String clientId, FeedConfigCreateRequestDto dto) {
       String sanitizedClientId = Utils.sanitizeString(clientId);

        log.info("Creating FeedConfig for client {} with feed name {}", sanitizedClientId, Utils.sanitizeString(dto.getFeedName()));
        try {
            if (dto == null) {
                log.error("FeedConfig creation request is null for client {}", sanitizedClientId);
                throw new BadRequestException("FeedConfig creation request cannot be null");
            }
            String sanitizedFeedName = Utils.sanitizeString(dto.getFeedName());
            // Validate client existence
            Clients client = getClientOrThrow(clientId);

            // Centralized validation (includes duplicate check and business rules)
            feedConfigValidator.validateCreateRequest(dto, clientId);
            log.info("successfully validated feed config creation request for client {} and feed name {}", sanitizedClientId, sanitizedFeedName);
            Feeds entity = feedConfigTransformer.toEntity(dto, client);
    
            Feeds saved = feedsRepository.save(entity);
            log.info("Successfully created FeedConfig for client {} with feed name {}. updated in DB", sanitizedClientId, sanitizedFeedName);
            auditService.logAudit(AuditType.FEED_CREATE, "Feeds", entity, null, clientId, entity.getFeedIdentifier());
            initializeConnectorFields(saved);
            return feedConfigTransformer.toResponseDto(saved);
        } catch (RecordNotFoundException | RecordAlreadyExistException e) {
            log.error("Client not found or feed already exists for client {}: {}", sanitizedClientId, e.getMessage());
            throw e;
        } catch (BadRequestException e) {
            log.error("Bad request for client {}: {}", sanitizedClientId, e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error creating FeedConfig for client {}: {}", sanitizedClientId, e.getMessage());
            throw new UnExpectedException("Failed to create FeedConfig: " + e.getMessage());
        }

    }

    /**
     * Updates an existing FeedConfig for a client.
     * Validates input and business rules before updating.
     *
     * @param clientId      the client identifier
     * @param feedIdentifier the feed identifier
     * @param dto           the feed config update request DTO
     * @return FeedResponseDto with updated feed details
     */
    @Override
    @Transactional
    public FeedResponseDto updateFeedConfig(String clientId, String feedIdentifier, FeedConfigUpdateRequestDto dto) {
        String sanitizedClientId = Utils.sanitizeString(clientId);
        String sanitizedFeedIdentifier = Utils.sanitizeString(feedIdentifier);
        try{
            Clients client = getClientOrThrow(clientId);
            Feeds entity = getFeedOrThrow(feedIdentifier, clientId);
            Feeds oldValue = deepCopyUtil.deepCopy(entity, Feeds.class);
            // Centralized update validation
            feedConfigValidator.validateUpdateRequest(dto, entity);
            log.info("successfully validated feed config update request for client {} and feed identifier {}", sanitizedClientId, sanitizedFeedIdentifier);
            feedConfigTransformer.updateEntityFromDto(dto, entity, client);
            Feeds saved = feedsRepository.save(entity);
            
            log.info("Successfully updated FeedConfig for client {} with feed identifier {}. updated in DB", sanitizedClientId, sanitizedFeedIdentifier);
            auditService.logAudit(AuditType.FEED_UPDATE, "Feeds", entity, oldValue, clientId, UUID.fromString(feedIdentifier));
            
            initializeConnectorFields(saved);
            return feedConfigTransformer.toResponseDto(saved);
        } 
        catch (RecordNotFoundException | RecordAlreadyExistException e) {
            log.error("FeedConfig not found or already exists for client {} and feedIdentifier {}: {}", sanitizedClientId, sanitizedFeedIdentifier, e.getMessage());
            throw e;
        } catch (BadRequestException e) {
            log.error("Bad request for client {}: {}", sanitizedClientId, e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error updating FeedConfig for client {} and feedIdentifier {}: {}", sanitizedClientId, sanitizedFeedIdentifier, e.getMessage());
            throw new UnExpectedException("Failed to update FeedConfig: " + e.getMessage());
        }
    }

    /**
     * Helper to fetch and validate client existence.
     *
     * @param clientId the client identifier
     * @return Clients entity
     * @throws RecordNotFoundException if client does not exist
     */
    private Clients getClientOrThrow(String clientId) {
        String sanitizedClientId = Utils.sanitizeString(clientId);
        return clientsRepository.findById(sanitizedClientId)
                .orElseThrow(() -> new RecordNotFoundException("Client not found: " + sanitizedClientId));
    }

    /**
     * Helper to fetch and validate feed existence and ownership.
     *
     * @param feedIdentifier the feed identifier
     * @param clientId       the client identifier
     * @return Feeds
     * @throws RecordNotFoundException if feed does not exist or does not belong to client
     */
    private Feeds getFeedOrThrow(String feedIdentifier, String clientId) {
        Feeds entity = feedsRepository.findById(UUID.fromString(feedIdentifier))
                .orElseThrow(() -> new RecordNotFoundException("FeedConfig not found: " + feedIdentifier));
        if (entity.getClient() == null || !Utils.sanitizeString(clientId).equals(entity.getClient().getClientId())) {
            String sanitizedFeedIdentifier = Utils.sanitizeString(feedIdentifier);
            log.error("Feed {} does not belong to client {}", sanitizedFeedIdentifier, Utils.sanitizeString(clientId));
            throw new RecordNotFoundException("Feed does not belong to the specified client");
        }
        return entity;
    }

    /**
     * Initializes lazy fields before mapping to DTO.
     *
     * @param feed Feeds
     */
    private void initializeConnectorFields(Feeds feed) {
        if (feed.getConnectorConfig() != null) {
            feed.getConnectorConfig().getConnectorType();
            feed.getConnectorConfig().getEmrVersion();
        }
    }

    public FeedResponseDto getFeedConfig(String clientId, String feedIdentifier){
        
        String sanitizedClientId = Utils.sanitizeString(clientId);
        String sanitizedFeedIdentifier = Utils.sanitizeString(feedIdentifier);
        try{
        Clients client = getClientOrThrow(clientId);
        log.info("Retrieving FeedConfig for client {} with feed identifier {}", sanitizedClientId, sanitizedFeedIdentifier);
        Feeds entity = getFeedOrThrow(feedIdentifier, clientId);
        initializeConnectorFields(entity);
        log.info("Successfully retrieved FeedConfig for client {} with feed identifier {}", sanitizedClientId, sanitizedFeedIdentifier);
        return feedConfigTransformer.toResponseDto(entity);
        }
        catch (RecordNotFoundException e) {
            log.error("FeedConfig not found for client {} and feedIdentifier {}: {}", sanitizedClientId, sanitizedFeedIdentifier, e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error retrieving FeedConfig for client {} and feedIdentifier {}: {}", sanitizedClientId, sanitizedFeedIdentifier, e.getMessage());
            throw new UnExpectedException("Failed to retrieve FeedConfig: " + e.getMessage());
        }
    }
}