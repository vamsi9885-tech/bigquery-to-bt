package com.optum.dap.api.transformer;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.optum.dap.api.dto.ParameterDto;
import com.optum.dap.api.model.Parameters;

public class CommonTransformer {
    
      /**
     * Helper method to convert a list of ParameterDto objects to a list of Parameters entities
     *
     * @param dtoList List of ParameterDto objects
     * @return List of Parameters entities
     */
    public static  List<Parameters> convertDtoListToEntityList(List<ParameterDto> dtoList) {
        if (dtoList == null) {
            return Collections.emptyList();
        }
        
        return dtoList.stream()
            .map(dto -> {
                Parameters entity = new Parameters();
                entity.setParamName(dto.getParamName());
                entity.setParamValue(dto.getParamValue());
                return entity;
            })
            .collect(Collectors.toList());
    }


        /**
     * Maps a list of Parameters entities to a list of ParameterDto objects
     * @param parameters List of Parameters entities
     * @return List of ParameterDto objects
     */
    public static List<ParameterDto> mapParametersToParameterDtos(List<Parameters> parameters) {
        if (parameters == null) {
            return Collections.emptyList();
        }
        return parameters.stream()
                .map(entity -> {
                    ParameterDto dto = new ParameterDto();
                    dto.setParamName(entity.getParamName());
                    dto.setParamValue(entity.getParamValue());
                    return dto;
                })
                .collect(Collectors.toList());
    }
}
