package com.optum.dap.api.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

/**
 * Configuration properties for OIDC settings.
 */
@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "oidc")
public class OIDCProperties {

    /**
     * The issuer URI for the OIDC provider.
     */
    private String issuerUri;

    /**
     * The client ID for the OIDC application.
     */
    private String clientId;

    /**
     * The client secret for the OIDC application.
     */
    private String clientSecret;

    /**
     * The logout endpoint for the OIDC application.
     */
    private String logoutEndpoint;

    /**
     * The user info endpoint for the OIDC provider.
     */

    private String userInfoEndpoint;
    /**
     * The token endpoint for the OIDC provider.
     */

    private String tokenEndpoint;

    /**
     * The authorization endpoint for the OIDC provider.
     */
    private String authorizationEndpoint;

    /**
     * The JWK Set URI for the OIDC provider.
     */
    private String jwkSetUri;



}