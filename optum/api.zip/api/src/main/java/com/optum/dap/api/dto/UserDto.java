package com.optum.dap.api.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
/**
 * Data Transfer Object (DTO) for User entity.
 * This class is used to transfer user data between layers.
 */
public class UserDto {
    private String userId;
    private String userName;
    private String userEmail;
    
}
