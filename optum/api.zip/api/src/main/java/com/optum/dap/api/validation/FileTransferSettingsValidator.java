package com.optum.dap.api.validation;

import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigUpdateRequestDto;
import com.optum.dap.api.dto.FileTransferSettingsDto;
import com.optum.dap.api.dto.FileTransferSettingsDetailDto;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * Validator implementation for ConditionalFileTransferSettingsValidation.
 * Validates file transfer settings based on feed type.
 */
public class FileTransferSettingsValidator implements ConstraintValidator<ConditionalFileTransferSettingsValidation, Object> {


    @Override
    public void initialize(ConditionalFileTransferSettingsValidation constraintAnnotation) {
        // No initialization needed
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        if (value == null) return true;

        FeedType feedType;
        FeedStatus status;
        FileTransferSettingsDto fileTransferSettings;

        if (value instanceof FeedConfigCreateRequestDto dto) {
            feedType = dto.getFeedType();
            status = dto.getStatus();
            if (dto.getFeedConfig() == null) return true;
            fileTransferSettings = dto.getFeedConfig().getFileTransferSettings();
        } else if (value instanceof FeedConfigUpdateRequestDto dto) {
            feedType = dto.getFeedType();
            status = dto.getStatus();
            if (dto.getFeedConfig() == null) return true;
            fileTransferSettings = dto.getFeedConfig().getFileTransferSettings();
        } else {
            return fail(context, "Data Request type not supported for validation");
        }

        if (feedType == null) return fail(context, "Feed type must not be null");
        if (status == FeedStatus.PENDING) return true;

        if (feedType == FeedType.PUSH) {
            return validatePushFeed(fileTransferSettings, context);
        }

        return validatePullFeed(feedType, fileTransferSettings, context);
    }

    private boolean validatePushFeed(FileTransferSettingsDto settings, ConstraintValidatorContext context) {
        if (settings != null) {
            return fail(context, "File transfer settings should not be provided for PUSH feed type");
        }
        return true;
    }

    private boolean validatePullFeed(FeedType feedType, FileTransferSettingsDto settings, ConstraintValidatorContext context) {
        if (settings == null) return fail(context, "File transfer settings cannot be null for feed type:" + feedType);
        if (settings.getType() == null) return fail(context, "File transfer type cannot be null for feed type:" + feedType);
        if (settings.getSettings() == null) return fail(context, "File transfer settings details cannot be null for feed type:" + feedType);

        return validateSettingsDetail(settings.getSettings(), context);
    }

    private boolean validateSettingsDetail(FileTransferSettingsDetailDto detail, ConstraintValidatorContext context) {
        if (detail.getEnable() == null) return fail(context, "Enable flag must not be null");

        if (Boolean.TRUE.equals(detail.getEnable())) {
            if (isNullOrBlank(detail.getUserName())) return fail(context, "User name must not be blank when file transfer is enabled");
            if (isNullOrBlank(detail.getLandingDirectory())) return fail(context, "Landing directory must not be blank when file transfer is enabled");
            if (isNullOrBlank(detail.getHostName())) return fail(context, "Host name must not be blank when file transfer is enabled");
            if (isNullOrBlank(detail.getKnownHostFile())) return fail(context, "Known host file must not be blank when file transfer is enabled");
        }

        return true;
    }

    private boolean fail(ConstraintValidatorContext context, String message) {
        addConstraintViolation(context, message);
        return false;
    }

    private void addConstraintViolation(ConstraintValidatorContext context, String message) {
        context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate(message)
            .addPropertyNode("feedConfig.FileTransferSettings")
            .addConstraintViolation();
    }

    private boolean isNullOrBlank(String str) {
        return str == null || str.trim().isEmpty();
    }
}