package com.optum.dap.api.transformer;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import com.optum.dap.api.model.ClientConfig;

@Converter(autoApply = false)
public class ClientConfigJsonConverter extends GenericJsonbConverter<ClientConfig> {
    public ClientConfigJsonConverter() {
        super(ClientConfig.class);
    }
}