package com.optum.dap.api.service.impl;

import com.optum.dap.api.dto.FeedFrequencyResponseDto;
import com.optum.dap.api.model.FeedFrequency;
import com.optum.dap.api.repository.IFeedFrequencyRepository;
import com.optum.dap.api.service.IFeedFrequencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service implementation for FeedFrequency.
 */
@Service
public class FeedFrequencyServiceImpl implements IFeedFrequencyService {

    @Autowired
    private IFeedFrequencyRepository feedFrequencyRepository;

    @Override
    public List<FeedFrequencyResponseDto> getAllFeedFrequencies() {
        return feedFrequencyRepository.findAll().stream().map(entity -> {
            FeedFrequencyResponseDto dto = new FeedFrequencyResponseDto();
            dto.setFrequencyType(entity.getFrequencyType());
            dto.setFeedWindowDates(entity.getFeedWindowDates());
            dto.setSupportedFeedType(entity.getSupportedFeedType());
            dto.setFrequencyId(entity.getFrequencyId());
        
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public FeedFrequency resolveById(Integer frequencyId) {
        return feedFrequencyRepository.findById(frequencyId)
            .orElseThrow(() -> new IllegalArgumentException("Invalid frequency id: " + frequencyId));
    }
}