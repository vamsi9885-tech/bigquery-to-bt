package com.optum.dap.api.exception;

public class RecordAlreadyExistException extends RuntimeException {  
    public RecordAlreadyExistException(String message) {  
        super("Record already exists: " + message);  
    }  
}
