package com.optum.dap.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.micrometer.common.lang.NonNull;
import jakarta.validation.constraints.Pattern;
import lombok.Setter;
import lombok.Getter;

/**
 * DTO for cron settings in runtime config.
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CronSettingsDto {
    /**
     * Time of day in HH:MM format (24-hour, 00:00 to 23:59).
     */
    @Pattern(regexp = "^([01]\\d|2[0-3]):([0-5]\\d)$", message = "timeOfDay must be in HH:MM 24-hour format (00:00 to 23:59)")
    private String timeOfDay;

    @NonNull
    @Pattern(regexp = "^(\\*|[0-6])$", message = "dayOfWeek must be a number between 1 (Monday) and 7 (Sunday) or '*'")
    private String dayOfWeek;

    @NonNull
    @Pattern(regexp = "^(\\*|0?[1-9]|[12]\\d|3[01])(,(\\*|0?[1-9]|[12]\\d|3[01]))*$", message = "dayOfMonth must be a number between 1 and 31 or '*'")
    private String dayOfMonth;

    @NonNull
    @Pattern(regexp = "^(\\*|1[0-2]|0?[1-9])(,(\\*|1[0-2]|0?[1-9]))*$", message = "monthOfYear must be a number between 1 and 12 or '*'")
    private String monthOfYear;
}