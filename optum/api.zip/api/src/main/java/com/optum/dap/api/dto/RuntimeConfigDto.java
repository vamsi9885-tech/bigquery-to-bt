package com.optum.dap.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.optum.dap.api.constants.Constant.ExtractionType;
import com.optum.dap.api.constants.Constant.NotifyType;
import com.optum.dap.api.constants.Constant.SplitBy;
import lombok.Data;
import java.time.LocalDate;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

/**
 * DTO for runtime configuration for a feed.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RuntimeConfigDto {
    private Boolean isAdhocRun;
    private ExtractionType extractionType;
    private Integer splitBy;
    private String splitByType;
    private LocalDate startDate;
    private LocalDate endDate;
    private LocalDate periodicStartDate;
    @NotNull(message = "lagOffset must not be null")
    private Integer lagOffset;
    @NotNull(message = "lagTolerance must not be null")
    private Integer lagTolerance;
    private NotifyType notifyType;
    private String specVersion;
    private String specName;
    private Boolean enableRunStatusNotification = true;
    @Valid
    private CronSettingsDto cronSettings;
}
