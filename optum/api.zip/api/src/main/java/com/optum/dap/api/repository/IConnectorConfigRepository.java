package com.optum.dap.api.repository;

import com.optum.dap.api.model.ConnectorConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

/**
 * Repository for connector config.
 */
public interface IConnectorConfigRepository extends JpaRepository<ConnectorConfig, UUID> {
    Optional<ConnectorConfig> findByFeed_FeedIdentifier(UUID feedIdentifier);
}
