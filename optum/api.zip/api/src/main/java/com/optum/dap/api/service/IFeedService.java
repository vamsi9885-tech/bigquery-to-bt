package com.optum.dap.api.service;

import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigUpdateRequestDto;
import com.optum.dap.api.dto.FeedResponseDto;

/**
 * Service interface for managing FeedConfig.
 */
public interface IFeedService {
    FeedResponseDto createFeedConfig(String clientId, FeedConfigCreateRequestDto dto);
    FeedResponseDto getFeedConfig(String clientId, String feedIdentifier);
    FeedResponseDto updateFeedConfig(String clientId, String feedIdentifier, FeedConfigUpdateRequestDto dto);
}