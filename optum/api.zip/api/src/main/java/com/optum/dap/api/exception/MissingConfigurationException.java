package com.optum.dap.api.exception;

public class MissingConfigurationException extends RuntimeException {
    public MissingConfigurationException(String message) {  
        super("Missing Configuration: " + message);  
    }  
}