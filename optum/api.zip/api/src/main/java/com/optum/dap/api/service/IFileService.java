package com.optum.dap.api.service;

import com.optum.dap.api.dto.FileDto;
import java.util.List;

/**
 * Service interface for managing file configurations for feeds.
 * <p>
 * Follows Spring Data JPA and clean code best practices.
 * All business logic should be implemented in the service layer.
 * Interface name follows the convention of prefixing with 'I'.
 * </p>
 */
public interface IFileService {
    /**
     * Retrieves all file configurations for a given client and feed.
     *
     * @param clientId       the client identifier
     * @param feedIdentifier the feed identifier
     * @return list of file configuration DTOs
     */
    List<FileDto> getFiles(String clientId, String feedIdentifier);

    /**
     * Saves a list of file configurations for a given client and feed.
     *
     * @param clientId       the client identifier
     * @param feedIdentifier the feed identifier
     * @param files          list of file configuration DTOs to save
     */
    void saveFiles(String clientId, String feedIdentifier, List<FileDto> files);

    /**
     * Updates a file configuration for a given client, feed, and logical file name.
     *
     * @param clientId         the client identifier
     * @param feedIdentifier   the feed identifier
     * @param logicalFileName  the logical file name to update
     * @param file             the updated file configuration DTO
     */
    void updateFile(String clientId, String feedIdentifier, String logicalFileName, FileDto file);

    /**
     * Deletes a file configuration for a given client, feed, and logical file name.
     *
     * @param clientId         the client identifier
     * @param feedIdentifier   the feed identifier
     * @param logicalFileName  the logical file name to delete
     */
    void deleteFile(String clientId, String feedIdentifier, String logicalFileName);
}