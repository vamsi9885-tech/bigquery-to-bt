package com.optum.dap.api.filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;

import java.io.IOException;

import org.springframework.stereotype.Component;

import com.optum.dap.api.utils.Utils;
import com.optum.dap.api.constants.Constant;;


@Component
@Order(Constant.USERNAME_HEADER_FILTER) // Ensure this filter runs at the correct order
public class UsernameHeaderFilter implements Filter {
    private static final String MDC_USERNAME_KEY = "loggedInUsername";
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String username = Utils.getLoggedInUsername();
        MDC.put(MDC_USERNAME_KEY, username);
        // Set username in response header
        httpResponse.setHeader("X-Logged-In-Username", username);

        try {
            chain.doFilter(request, response);
        } finally {
            MDC.remove(MDC_USERNAME_KEY);
        }
    }
}

