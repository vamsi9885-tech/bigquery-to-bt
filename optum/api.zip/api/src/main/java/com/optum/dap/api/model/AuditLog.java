package com.optum.dap.api.model;

import java.time.LocalDateTime;
import java.util.UUID;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.EnumType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import com.optum.dap.api.constants.Constant.AuditType;


@Entity
@Data
@Table(name="audit_log")
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "audit_id", updatable = false, nullable = false)
    private UUID auditId;

    @Column(name = "audit_type")
    @Enumerated(EnumType.STRING) 
    private AuditType auditType;
    

    @Column(name="action_by")
    private String actionBy;

    @Column(name="action_on")
    private LocalDateTime actionOn;

    @Column(name = "entity_name")
    private String entityName;

    @Column(name = "client_id")
    private String clientId;

    @Column(name = "feed_identifier")
    private UUID feedIdentifier;

    @Column(name = "old_value", columnDefinition ="jsonb")
    @JdbcTypeCode(SqlTypes.JSON) 
    private String oldValue; // JSON string (delta only or full)

    @Column(name = "new_value", columnDefinition ="jsonb")
    @JdbcTypeCode(SqlTypes.JSON) 
    private String newValue;

}
