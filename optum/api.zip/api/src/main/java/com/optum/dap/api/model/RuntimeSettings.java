package com.optum.dap.api.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.optum.dap.api.transformer.RunTimeConfigJsonConverter;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Entity for runtime settings.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "run_time_settings")
public class RuntimeSettings {
    @Id
    @Column(name = "run_time_config_id", nullable = false)
    private UUID runTimeConfigId;

    @Column(name = "feed_identifier", nullable = false)
    private UUID feedIdentifier;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "feed_identifier", referencedColumnName = "feed_identifier", insertable = false, updatable = false)
    @JsonBackReference
    private Feeds feed;


    @Column(name = "is_adhoc_run", nullable = false)
    private boolean isAdhocRun;

    @Column(name = "extraction_type")
    private String extractionType;

    @Column(name = "split_by")
    private Integer splitBy;

    @Column(name = "adhoc_start_date")
    private LocalDate adhocStartDate;

    @Column(name = "adhoc_end_date")
    private LocalDate adhocEndDate;

    @Column(name = "periodic_start_date")
    private LocalDateTime periodicStartDate;

    @Column(name = "lag_offset")
    private Integer lagOffset;

    @Column(name = "lag_tolerance")
    private Integer lagTolerance;

    @Column(name = "enable_run_status_notification")
    private Boolean enableRunStatusNotification;

    @Column(name = "run_time_setting_config", columnDefinition = "jsonb")
    @JdbcTypeCode(SqlTypes.JSON)
    @Convert(converter = RunTimeConfigJsonConverter.class) // Ensure proper JSON conversion
    private RuntimeSettingConfig runtimeSettingConfig;

    @Column(name = "notify_type")
    private String notifyType;


    @Column(name = "modified_by", nullable = false)
    private String modifiedBy;

    @Column(name = "modified_date", nullable = false)
    private LocalDateTime modifiedDate;
}