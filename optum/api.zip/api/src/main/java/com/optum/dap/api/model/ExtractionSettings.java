package com.optum.dap.api.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.dap.api.constants.Constant.RowDelimiter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExtractionSettings {
    @JsonProperty("rolling_date")
    private Integer rollingDate;

    @JsonProperty("file_name_format")
    private String fileNameFormat;

    @JsonProperty("row_delimiter")
    private RowDelimiter rowDelimiter;

    @JsonProperty("column_delimiter")
    private String columnDelimiter;

    @JsonProperty("quote")
    private Boolean quote;

    @JsonProperty("storage_base_path")
    private String storageBasePath;
    
    @JsonProperty("filter")
    private String filter;

    @JsonProperty("parameters")
    @Builder.Default
    private List<Parameters> parameters = null;
    
    @JsonProperty("data_cleansing")
    @Builder.Default
    private List<String> dataCleansing = null;
}