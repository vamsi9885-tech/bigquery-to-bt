package com.optum.dap.api.service;

/**
 * Service interface for session-related operations.
 */
public interface ISessionService {
    /**
     * Checks if the current user session is active
     * @return true if the session is active, false otherwise
     */
    boolean isSessionActive();
    
    /**
     * Checks if the current user session is active and not timed out
     * @return true if the session is active and not timed out, false otherwise
     */
    boolean isSessionActiveWithTimeout();
}