package com.optum.dap.api.controller;

import com.optum.dap.api.dto.FileDto;
import com.optum.dap.api.service.IFileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST controller for file config APIs for feeds.
 * Follows RESTful conventions and Spring Boot best practices.
 */
@Slf4j
@RestController
@RequestMapping("/api/clients/{clientId}/feeds/{feedIdentifier}/files")
public class FilesController {
    @Autowired
    private IFileService fileService;
    
    /**
     * Constant for the message key in response maps
     */
    private static final String MESSAGE_KEY = "message";

    /**
     * GET endpoint to retrieve all file configs for a feed.
     */
    @GetMapping
    public ResponseEntity<List<FileDto>> getFiles(
            @PathVariable String clientId,
            @PathVariable String feedIdentifier) {
        List<FileDto> files = fileService.getFiles(clientId, feedIdentifier);
        return ResponseEntity.ok(files);
    }

    /**
     * POST endpoint to save file configs for a feed.
     */
    @PostMapping
    public ResponseEntity<?> saveFiles(
            @PathVariable String clientId,
            @PathVariable String feedIdentifier,
            @RequestBody @Valid List<FileDto> files) {
        fileService.saveFiles(clientId, feedIdentifier, files);
        Map<String, Object> result = new HashMap<>();
        result.put(MESSAGE_KEY, "Files config for the Feed " + feedIdentifier + " saved  successfully");
        return ResponseEntity.ok(result);
    }

    /**
     * PUT endpoint to update a file config for a feed.
     */
    @PutMapping("/{logicalFileName}")
    public ResponseEntity<?> updateFile(
            @PathVariable String clientId,
            @PathVariable String feedIdentifier,
            @PathVariable String logicalFileName,
            @RequestBody @Valid FileDto file) {
        fileService.updateFile(clientId, feedIdentifier, logicalFileName, file);
        Map<String, Object> result = new HashMap<>();
        result.put(MESSAGE_KEY, "File " + logicalFileName + " config for the Feed " + feedIdentifier + " saved  successfully");
        return ResponseEntity.ok(result);
    }

    /**
     * DELETE endpoint to remove a file config for a feed.
     */
    @DeleteMapping("/{logicalFileName}")
    public ResponseEntity<?> deleteFile(
            @PathVariable String clientId,
            @PathVariable String feedIdentifier,
            @PathVariable String logicalFileName) {
        fileService.deleteFile(clientId, feedIdentifier, logicalFileName);
        Map<String, Object> result = new HashMap<>();
        result.put(MESSAGE_KEY, "File " + logicalFileName + " config for the Feed " + feedIdentifier + " deleted  successfully");
        return ResponseEntity.ok(result);
    }
}
