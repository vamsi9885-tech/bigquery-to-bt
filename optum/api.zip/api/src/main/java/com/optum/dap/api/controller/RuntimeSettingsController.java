package com.optum.dap.api.controller;

import com.optum.dap.api.dto.RuntimeConfigDto;
import com.optum.dap.api.service.IRuntimeSettingsService;
import lombok.extern.slf4j.Slf4j;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

/**
 * REST controller for runtime settings.
 */
@Slf4j
@RestController
@RequestMapping("/api/clients/{clientId}/feeds/{feedIdentifier}/runtimeconfig")
public class RuntimeSettingsController {
    @Autowired
    private IRuntimeSettingsService runtimeSettingsService;

    /**
     * GET endpoint for runtime config.
     */
    @GetMapping
    public ResponseEntity<RuntimeConfigDto> getRuntimeConfig(
            @PathVariable String clientId,
            @PathVariable UUID feedIdentifier) {
        RuntimeConfigDto dto = runtimeSettingsService.getRuntimeConfig(clientId, feedIdentifier);
        return ResponseEntity.ok(dto);
    }

    /**
     * PUT endpoint for runtime config.
     */
    @PutMapping
    public ResponseEntity<?> updateRuntimeConfig(
            @PathVariable String clientId,
            @PathVariable UUID feedIdentifier,
            @RequestBody @Valid RuntimeConfigDto dto) {
        runtimeSettingsService.updateRuntimeConfig(clientId, feedIdentifier, dto);
        return ResponseEntity.ok(
                java.util.Map.of("message", "Runtime settings for Feed " + feedIdentifier + " saved successfully")
        );
    }
}
