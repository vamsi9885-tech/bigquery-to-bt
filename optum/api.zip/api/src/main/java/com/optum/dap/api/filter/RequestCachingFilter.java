package com.optum.dap.api.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;

import java.io.IOException;

import com.optum.dap.api.constants.Constant;;

/**
 * Filter to wrap HttpServletRequest with ContentCachingRequestWrapper.
 * This allows the request body to be read multiple times.
 */
@Component
@Order(Constant.REQUEST_CACHING_FILTER) // Ensure this filter runs at the correct order
public class RequestCachingFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        // Wrap the request with ContentCachingRequestWrapper only if it's not already wrapped
        if (!(request instanceof ContentCachingRequestWrapper)) {
            ContentCachingRequestWrapper wrappedRequest = new ContentCachingRequestWrapper(request);
            filterChain.doFilter(wrappedRequest, response);
        } else {
            filterChain.doFilter(request, response);
        }
    }
}