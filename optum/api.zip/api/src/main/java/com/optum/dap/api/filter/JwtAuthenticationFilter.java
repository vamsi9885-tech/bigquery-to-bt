package com.optum.dap.api.filter;

import java.io.IOException;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.optum.dap.api.config.JwtTokenProvider;
import com.optum.dap.api.constants.Constant;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Order(Constant.JWT_AUTHENTICATION_FILTER) 
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    @Value("${m2moidc.clientWriteClaimName}")
    private String clientWriteClaimName;

    @Value("${m2moidc.clientWriteClaimValue}")
    private String clientWriteClaimValue;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain) throws IOException, ServletException {
        String header = req.getHeader("Authorization");
        String authToken;
        String[] VALID_AUTH_HEADER_PREFIXES = {"Bearer ", "bearer "};

        // Check if the header contains authorization information
        if (header != null && Arrays.stream(VALID_AUTH_HEADER_PREFIXES).anyMatch(header::startsWith)) {
            try {
                authToken = header.substring(7);
                if (SecurityContextHolder.getContext().getAuthentication() == null && jwtTokenProvider.getClaimFromToken(authToken, clientWriteClaimName).equals(clientWriteClaimValue)) {
                        String clientId = jwtTokenProvider.getClaimFromToken(authToken, "clientId");
                        clientId = clientId != null ? clientId : "SYSTEM";
                        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(clientId, null, Arrays.asList(new SimpleGrantedAuthority("ROLE_CLIENT_WRITE")));
                        SecurityContextHolder.getContext().setAuthentication(authentication);
                    
                }
                chain.doFilter(req, res);
            } catch (Exception e) {
                throw new ServletException("Invalid Token", e);
            }
        } else {
            chain.doFilter(req, res);
        }
    }
    
}
