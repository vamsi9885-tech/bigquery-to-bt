package com.optum.dap.api.service.impl;
import com.optum.dap.api.model.AuditLog;
import com.optum.dap.api.repository.AuditLogRepository;
import com.optum.dap.api.service.IAuditService;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;

import com.optum.dap.api.utils.JsonDeltaUtil;
import com.optum.dap.api.utils.Utils;

import lombok.extern.slf4j.Slf4j;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import com.optum.dap.api.constants.Constant.AuditType;
import java.util.Map;
import java.util.Iterator;



@Slf4j
@Service
public class AuditServiceImpl implements IAuditService {
    @Autowired
    private AuditLogRepository auditLogRepository;
    private ObjectMapper objectMapper;
    AuditServiceImpl() {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }
    @Override
    public void logAudit(AuditType action, String entityName, Object newValue, Object oldValue, String clientId, UUID feedIdentifier) {
       
        try {
            log.info("Logging audit for action: {}, entity: {}, clientId: {}, feedIdentifier: {}", 
                      action, Utils.sanitizeString(entityName), Utils.sanitizeString(clientId), feedIdentifier);
        
            JsonNode[] deltas=JsonDeltaUtil.getDelta(objectMapper.valueToTree(oldValue), objectMapper.valueToTree(newValue));
            
            boolean skipLogAudit = false;
            if (deltas != null && deltas.length >= 2 && deltas[0].isObject() && deltas[1].isObject()) {
                // Count fields in both delta objects
                int oldDeltaFieldCount = deltas[0].size();
                int newDeltaFieldCount = deltas[1].size();
                
                // Check if the only field is modifiedDate in both objects
                boolean oldHasModifiedDate = deltas[0].has("modifiedDate");
                boolean newHasModifiedDate = deltas[1].has("modifiedDate");
                
                // Skip audit if either no fields changed or only modifiedDate changed in both objects
                skipLogAudit = (oldDeltaFieldCount == 0 && newDeltaFieldCount == 0) || 
                               (oldDeltaFieldCount == 1 && newDeltaFieldCount == 1 && 
                                oldHasModifiedDate && newHasModifiedDate);
            }

            if (skipLogAudit) {
                log.info("No changes or only modified date was changed. Skipping detailed audit logging.");
                return;
            } else {
                auditLogRepository.save(createAuditLog(action, entityName, deltas, clientId, feedIdentifier));
            }
            
        } catch (Exception e) {
            log.error("Error logging audit for action: {}, entity: {}, clientId: {}, feedIdentifier: {}. Error: {}", 
                      action, Utils.sanitizeString(entityName), Utils.sanitizeString(clientId), feedIdentifier, e.getMessage());
        } 

    }
    
    private AuditLog createAuditLog(AuditType action, String entityName, JsonNode[] deltas, String clientId, UUID feedIdentifier) throws Exception {
        AuditLog auditLog = new AuditLog();

        auditLog.setEntityName(entityName);
        auditLog.setAuditType(action);
        auditLog.setClientId(clientId);
        auditLog.setFeedIdentifier(feedIdentifier);
        auditLog.setActionOn(LocalDateTime.now());
        auditLog.setActionBy(Utils.getLoggedInUsername());
        auditLog.setOldValue(objectMapper.writeValueAsString(deltas[0]));
        auditLog.setNewValue(objectMapper.writeValueAsString(deltas[1]));
        return auditLog;
    }
}
