package com.optum.dap.api.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FileTransferSettingsDetail {
    
    @JsonProperty("host_name")
    private String hostName;

    @JsonProperty("user_name")
    private String userName;

    @JsonProperty("known_host_file")
    private String knownHostFile;

    @JsonProperty("landing_directory")
    private String landingDirectory;

    @JsonProperty("enable")
    private Boolean enable;
}
