package com.optum.dap.api.model;

import lombok.*;
import java.io.Serializable;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FilesId implements Serializable {
    private UUID feedIdentifier;
    private String logicalFileName;
}