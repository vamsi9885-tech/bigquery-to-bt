package com.optum.dap.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Parameters {
    @JsonProperty("param_name")
    private String paramName;

    @JsonProperty("param_value")
    private String paramValue;
}
