package com.optum.dap.api.transformer;
import com.optum.dap.api.constants.Constant;
import com.optum.dap.api.dto.*;
import com.optum.dap.api.model.ClientConfig;
import com.optum.dap.api.model.Clients;
import com.optum.dap.api.projection.IClientsProjection;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.model.ConnectorConfig;
import com.optum.dap.api.model.FeedFrequency;
import com.optum.dap.api.model.RuntimeSettings;
import com.optum.dap.api.model.Files;
import com.optum.dap.api.service.IFeedFrequencyService;
import com.optum.dap.api.service.IRuntimeSettingsService;
import com.optum.dap.api.service.IFileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Comparator;
import java.util.stream.Collectors;
import com.optum.dap.api.utils.Utils;
import com.optum.dap.api.exception.BadRequestException;

import com.optum.dap.api.exception.MissingConfigurationException;

/**
 * Transformer for converting Clients entity to ClientDetailsResponseDto.
 */
@Slf4j
@Component
public class ClientDetailsTransformer {

    @Autowired
    private IFeedFrequencyService feedFrequencyResolver;

    @Autowired
    private IRuntimeSettingsService runtimeSettingsService;

    @Autowired
    private IFileService fileService;

    @Autowired
    private RuntimeConfigTransformer runtimeConfigTransformer; // Inject RuntimeConfigTransformer

    @Autowired
    private FileTransformer fileTransformer;

    @Autowired
    private FeedConfigTransformer feedConfigTransformer;
    

    /**
     * Transforms a list of client projections into a list of ClientsDetailsDto.
     *
     * @param clients the list of client projections
     * @return list of ClientsDetailsDto
     */
    public List<ClientsDetailsDto> toClientsDetailsDtoList(List<IClientsProjection> clients) {
        return clients.isEmpty() ? List.of() : 
            clients.stream()
                .map(client -> {
                    ClientsDetailsDto dto = new ClientsDetailsDto();
                    dto.setClientId(client.getClientId());
                    dto.setClientName(client.getClientName());
                    dto.setActive(client.getIsActive());
                    return dto;
                })
                .sorted(Comparator.comparing(ClientsDetailsDto::getClientName, String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toList());

    }

    /**
     * Transforms a client entity into ClientDetailsResponseDto.
     *
     * @param client the client entity
     * @return ClientDetailsResponseDto
     */
    public ClientsResponseDto toClientsResponseDto(Clients client) {
        if (client == null) return null;

        ClientsResponseDto dto = new ClientsResponseDto();
        dto.setClientId(client.getClientId());
        dto.setClientName(client.getClientName());
        dto.setActive(client.isActive());
        dto.setClientConfig(toClientConfigDto(client.getClientConfig()));
        dto.setFeeds(toClientFeedDtoList(client.getFeeds()));
        return dto;
    }

    /**
     * Transforms client entity and feeds list into ClientDetailsResponseDto.
     *
     * @param client the client entity
     * @param feeds  the list of feeds
     * @return ClientDetailsResponseDto containing client details and all feeds
     */
    public ClientFeedsResponseDto toClientFeedsResponseDto(Clients client, List<Feeds> feeds)  throws Exception {
        if (client == null) return null;

        ClientFeedsResponseDto dto = new ClientFeedsResponseDto();
        dto.setClientId(client.getClientId());
        dto.setClientName(client.getClientName());
        dto.setActive(client.isActive());
        dto.setClientConfig(toClientConfigDto(client.getClientConfig()));

        List<FeedDetailsDto> feedDtos = feeds.stream()
                .filter(feed -> Constant.FeedStatus.ACTIVE.getValue().equalsIgnoreCase(feed.getStatus().getValue()))
                .map(feed -> {
                    FeedDetailsDto feedDto = new FeedDetailsDto();
                    feedDto.setFeedName(feed.getFeedName());
                    feedDto.setFeedId(feed.getFeedIdentifier() != null ? feed.getFeedIdentifier().toString() : null);
                    feedDto.setActive(feed.isActive());
                    feedDto.setFeedType(feed.getFeedType());
                    feedDto.setFeedFrequency(feedFrequencyResolver.resolveById(feed.getFrequencyId()).getFrequencyType());
                    feedDto.setStatus(feed.getStatus());
                    feedDto.setConnectorType(feed.getConnectorConfig() != null ? feed.getConnectorConfig().getConnectorType() : null);
                    feedDto.setConnectorVersion(feed.getConnectorConfig() != null ? feed.getConnectorConfig().getEmrVersion() : null);
                    // Use FeedConfigTransformer to transform FeedConfig to FeedConfigDto
                    feedDto.setFeedConfig(feedConfigTransformer.toFeedConfigDto(feed.getFeedConfig()));

                    // Fetch runtime settings directly from the feed
                    RuntimeSettings runtimeSettings = feed.getRuntimeSettings();
                    ConnectorConfig connectorConfig = feed.getConnectorConfig();
                    if(runtimeSettings == null) {
                        throw  new MissingConfigurationException("Runtime settings not found for feed: " + feed.getFeedName());
                    }
                    feedDto.setImplementationSettings(runtimeConfigTransformer.toDto(runtimeSettings, connectorConfig));

                    // Fetch file settings directly from the feed
                    List<FileDto> files = feed.getFiles() != null
                            ? feed.getFiles().stream().map(fileTransformer::toDto).collect(Collectors.toList())
                            : List.of();
                    feedDto.setFiles(files);

                    return feedDto;
                })
                .sorted(Comparator.comparing(FeedDetailsDto::getFeedName)) // Sort by feed name
                .collect(Collectors.toList());

        dto.setFeeds(feedDtos);
        return dto;
    }

    private ClientConfigDto toClientConfigDto(com.optum.dap.api.model.ClientConfig config) {
        if (config == null) return null;
        ClientConfigDto dto = new ClientConfigDto();
        dto.setInternalNotificationEmails(config.getInternalNotificationEmails());
        dto.setExternalNotificationEmails(config.getExternalNotificationEmails());
        dto.setPreserveArchives(config.isPreserveArchives());
        dto.setFeedCompletionNotificationEnabled(config.isFeedCompletionNotificationEnabled());
        dto.setPurgeOldFilesDays(config.getPurgeOldFilesDays());
        return dto;
    }

    private List<ClientFeedDto> toClientFeedDtoList(List<Feeds> feeds) {
        if (feeds == null) return List.of();
        return feeds.stream()
                .map(this::toClientFeedDto)
                .sorted(Comparator.comparing(ClientFeedDto::getFeedName, String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toList());
    }

    private ClientFeedDto toClientFeedDto(Feeds feed) {
        if (feed == null) return null;
        ClientFeedDto dto = new ClientFeedDto();
        dto.setFeedName(feed.getFeedName());
        dto.setFeedId(feed.getFeedIdentifier() != null ? feed.getFeedIdentifier().toString() : null);
        dto.setActive(feed.isActive());
        dto.setFeedType(feed.getFeedType());
        // Fetch frequencyType using frequencyId
        String frequencyType = null;
        if (feed.getFrequencyId() != null) {
            FeedFrequency freqEntity = feedFrequencyResolver.resolveById(feed.getFrequencyId());
            frequencyType = freqEntity.getFrequencyType();
        }
        dto.setFeedFrequency(frequencyType);
        dto.setStatus(feed.getStatus());
        return dto;
    }

    public Clients toClientsEntity(ClientRequestDto requestDto) {
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        String currentUser = Utils.getLoggedInUsername();
        Clients client = new Clients();
        client.setClientId(requestDto.getClientId());
        client.setClientName(requestDto.getClientName());
        client.setActive(requestDto.isActive());
        client.setClientConfig(toClientConfig(requestDto.getClientConfig()));
        client.setCreatedBy(currentUser);
        client.setModifiedBy(currentUser);
        client.setCreatedDate(now);
        client.setModifiedDate(now);
        return client;
    }
    public ClientConfig toClientConfig(ClientConfigDto dto) {
        if (dto == null) {
            return null;
        }
        ClientConfig config = new ClientConfig();
        config.setInternalNotificationEmails(dto.getInternalNotificationEmails());
        config.setExternalNotificationEmails(dto.getExternalNotificationEmails());
        config.setPreserveArchives(dto.getPreserveArchives());
        config.setPurgeOldFilesDays(dto.getPurgeOldFilesDays());
        config.setFeedCompletionNotificationEnabled(dto.getFeedCompletionNotificationEnabled());
        return config;
    }
    
    
}