package com.optum.dap.api.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

/**
 * Annotation for validating file transfer settings based on feed type.
 * This validation ensures that:
 * - For PULL and PULL_WITH_NTFS feeds, file transfer settings must not be null and must contain valid settings
 * - For PUSH feeds, file transfer settings are not required
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = FileTransferSettingsValidator.class)
public @interface ConditionalFileTransferSettingsValidation {
    String message() default "Invalid file transfer settings for feed type";
    
    Class<?>[] groups() default {};
    
    Class<? extends Payload>[] payload() default {};
}
