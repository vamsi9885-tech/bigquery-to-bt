package com.optum.dap.api.validation;

import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigUpdateRequestDto;
import com.optum.dap.api.dto.ExtractionSettingsDto;
import com.optum.dap.api.dto.FeedConfigDto;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * Validator implementation for conditionally validating extraction settings
 * based on feed status. For feeds with PENDING status, validation constraints
 * are relaxed.
 */
public class ConditionalExtractionSettingsValidator implements 
        ConstraintValidator<ConditionalExtractionSettingsValidation, Object> {

    @Override
    public void initialize(ConditionalExtractionSettingsValidation constraintAnnotation) {
        // No initialization needed
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        context.disableDefaultConstraintViolation();

        if (value == null) return true;

        FeedStatus status;
        FeedType feedType;
        ExtractionSettingsDto extractionSettings;

        if (value instanceof FeedConfigCreateRequestDto dto) {
            status = dto.getStatus();
            feedType = dto.getFeedType();
            extractionSettings = getExtractionSettings(dto.getFeedConfig());
        } else if (value instanceof FeedConfigUpdateRequestDto dto) {
            status = dto.getStatus();
            feedType = dto.getFeedType();
            extractionSettings = getExtractionSettings(dto.getFeedConfig());
        } else {
            return true;
        }

        if (status == FeedStatus.PENDING) return true;

        if (extractionSettings == null) {
            addViolation(context, "Extraction settings must not be null", null);
            return false;
        }

        boolean isValid = true;
        isValid &= validateNotNull(context, extractionSettings.getRowDelimiter(), "Row delimiter must not be null", "feedConfig.extractionSettings.rowDelimiter");
        isValid &= validateNotBlank(context, extractionSettings.getColumnDelimiter(), "Column delimiter must not be blank", "feedConfig.extractionSettings.columnDelimiter");
        isValid &= validateNotNull(context, extractionSettings.getQuote(), "Quote must not be null", "feedConfig.extractionSettings.quote");

        if (feedType == FeedType.PULL) {
            isValid &= validateNotNull(context, extractionSettings.getRollingDate(), "Rolling date must not be null for PULL feed type", "feedConfig.extractionSettings.rollingDate");
            isValid &= validateNotBlank(context, extractionSettings.getFileNameFormat(), "File name format must not be blank for PULL feed type", "feedConfig.extractionSettings.fileNameFormat");
        }

        return isValid;
    }

    private ExtractionSettingsDto getExtractionSettings(FeedConfigDto config) {
        return config != null ? config.getExtractionSettings() : null;
    }

    private boolean validateNotNull(ConstraintValidatorContext context, Object value, String message, String propertyPath) {
        if (value == null) {
            addViolation(context, message, propertyPath);
            return false;
        }
        return true;
    }

    private boolean validateNotBlank(ConstraintValidatorContext context, String value, String message, String propertyPath) {
        if (value == null || value.isBlank()) {
            addViolation(context, message, propertyPath);
            return false;
        }
        return true;
    }

    private void addViolation(ConstraintValidatorContext context, String message, String propertyPath) {
        if (propertyPath != null) {
            context.buildConstraintViolationWithTemplate(message)
                   .addPropertyNode(propertyPath)
                    .addConstraintViolation();
        } else {
            context.buildConstraintViolationWithTemplate(message)
                   .addConstraintViolation();
        }
    }
}
