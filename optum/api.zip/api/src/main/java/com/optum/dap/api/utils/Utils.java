package com.optum.dap.api.utils;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;

import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.UUID;

@Slf4j
public class Utils {
    /**
     * Utility method to sanitize a string by removing all non-alphanumeric characters
     * except for underscores and hyphens.
     *
     * @param str the input string to sanitize
     * @return the sanitized string
     */
    private Utils() {
        throw new IllegalStateException("Utils class");
      }
    public static String sanitizeString(String str) {
        if (str == null) {
            return null;
        }
        return str.replaceAll("[^a-zA-Z0-9_-]", "");
    }
    public static boolean isNullOrEmpty(String str) {
        return str == null || str.isEmpty();
    }
    public static boolean isValidUUID(String str) {
        try {
            UUID.fromString(str);
        } catch (IllegalArgumentException e) {
            return false; // Not a valid UUID
        }
        return true; 
    }
    public static String sanitizeContent(String content) {
        if (content == null || content.isEmpty()) {
            return content;
        }

        // Mask sensitive fields in JSON
        return content.replaceAll("(?i)\"(password|creditCard|ssn|token|key|secret)\"\\s*:\\s*\"[^\"]*\"", 
                                "\"$1\":\"****\"");
    }

    public static String getLoggedInUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = "anonymous user";

        try {
            if (authentication != null && authentication.isAuthenticated()) {
                Object principal = authentication.getPrincipal();

                if (principal instanceof DefaultOidcUser) {
                    DefaultOidcUser userDetails = (DefaultOidcUser) principal;
                    username = userDetails.getPreferredUsername();
                } else if (principal instanceof String) {
                    // Handle case where principal is a String (e.g., username)
                    username = (String) principal;
                } else {
                    log.warn("Unexpected principal type: {}", principal != null ? principal.getClass().getName() : null);
                }
            }
        } catch (Exception e) {
            log.error("Error getting logged in username: ", e);
            return username; // Return default username in case of error
        }

        return username;
    }

}
