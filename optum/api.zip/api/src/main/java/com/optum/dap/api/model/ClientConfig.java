package com.optum.dap.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * POJO representing the client_config JSON structure stored in Clients table.
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientConfig {
    @JsonProperty("internal_notification_emails")
    private String internalNotificationEmails;
    
    @JsonProperty("external_notification_emails")
    private String externalNotificationEmails;

    @JsonProperty("preserve_archives")
    private boolean preserveArchives;

    @JsonProperty("feed_completion_notification_enabled")
    private boolean feedCompletionNotificationEnabled;

    @JsonProperty("purge_old_files_by_days")
    private int purgeOldFilesDays;
}
