package com.optum.dap.api.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Builder;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Convert;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.CascadeType;
import jakarta.persistence.FetchType;

import com.optum.dap.api.transformer.ClientConfigJsonConverter;
import java.util.List;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonManagedReference;

/**
 * Entity representing a client.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name="clients")
public class Clients {
    @Id
    @Column(name = "client_id")
    private String clientId;
    
    @Column(name = "client_name")
    private String clientName;

    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "client_config", columnDefinition ="jsonb")
    @JdbcTypeCode(SqlTypes.JSON)
    @Convert(converter = ClientConfigJsonConverter.class)
    private ClientConfig clientConfig;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @JsonManagedReference
    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Feeds> feeds;
}