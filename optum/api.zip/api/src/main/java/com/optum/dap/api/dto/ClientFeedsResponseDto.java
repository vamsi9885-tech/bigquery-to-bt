package com.optum.dap.api.dto;

import jakarta.validation.Valid;
import lombok.Data;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DTO for client feeds response including config and feeds.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientFeedsResponseDto {
    private String clientId;
    private String clientName;
    private boolean isActive;
    @Valid
    private ClientConfigDto clientConfig;
    private List<FeedDetailsDto> feeds;

    @JsonProperty("isActive")
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }
}