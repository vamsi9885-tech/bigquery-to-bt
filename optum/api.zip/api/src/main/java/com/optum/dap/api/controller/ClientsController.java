package com.optum.dap.api.controller;

import com.optum.dap.api.dto.ClientsDetailsDto;
import com.optum.dap.api.dto.ClientsResponseDto;
import com.optum.dap.api.dto.ClientRequestDto;
import com.optum.dap.api.service.IClientsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import com.optum.dap.api.utils.Utils;

import java.util.List;


/**
 * REST controller to handle client-related endpoints.
 */
@Slf4j
@RestController
@RequestMapping("/api/clients")
public class ClientsController {

    @Autowired
    private IClientsService clientsService;

    /**
     * GET endpoint to retrieve all client details.
     *
     * @return list of ClientsDetailsDto.
     */
    @GetMapping
    public ResponseEntity<List<ClientsDetailsDto>> getClients() {

        List<ClientsDetailsDto> clients = clientsService.getAllClients();
        return ResponseEntity.ok(clients);
    }

    /**
     * GET endpoint to retrieve client details by clientId.
     *
     * @param clientId the client identifier
     * @return client details with config and feeds
     */
    @GetMapping("/{clientId}")
    public ResponseEntity<ClientsResponseDto> getClientById(@PathVariable String clientId) {
            String sanitizedClientId = Utils.sanitizeString(clientId);
            log.info("Fetching client details for clientId: {}", sanitizedClientId);
            ClientsResponseDto client = clientsService.getClientDetailsById(sanitizedClientId);
            log.info("Client details fetched successfully for clientId: {}", sanitizedClientId);
            return ResponseEntity.ok(client);
    }

    /**
     * PUT endpoint to update an existing client.
     */
    @PutMapping("/{clientId}")
    public ResponseEntity<?> updateClient(
            @PathVariable String clientId,
            @RequestBody @Valid ClientRequestDto requestDto) {
            String sanitizedClientId = Utils.sanitizeString(clientId);
            log.info("Update Client {} Request Received", sanitizedClientId);
            clientsService.updateClient(clientId, requestDto);
            log.info("Client {} updated successfully", sanitizedClientId);
            return ResponseEntity.ok(
                java.util.Collections.singletonMap(
                    "message", "Client " + requestDto.getClientName() + " updated successfully"
                )
            );
        
    }
}