package com.optum.dap.api.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JsonDeltaUtil {
    private JsonDeltaUtil() {
        throw new IllegalStateException("JsonDeltaUtil class");
      }
    /**
     * Returns a two-element array:
     *   [0] = delta of fields in OLD value,
     *   [1] = delta of fields in NEW value,
     * Special cases:
     *   - If oldNode is null: returns [{}, newNode]
     *   - If newNode is null: returns [oldNode, {}]
     */
    public static JsonNode[] getDelta(JsonNode oldNode, JsonNode newNode) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());

        if (oldNode == null || oldNode.isNull()) {
            return new JsonNode[] { mapper.createObjectNode(), 
                                    newNode == null ? mapper.createObjectNode() : newNode };
        }
        if (newNode == null || newNode.isNull()) {
            return new JsonNode[] { oldNode,
                                    mapper.createObjectNode() };
        }

        ObjectNode deltaOld = mapper.createObjectNode();
        ObjectNode deltaNew = mapper.createObjectNode();

        compareNodes(oldNode, newNode, deltaOld, deltaNew);

        return new JsonNode[] {deltaOld, deltaNew};
    }

    
    /**
     * Recursive comparison of two json nodes to populate the deltas.
     */
    private static void compareNodes(JsonNode oldJson, JsonNode newJson,
                                     ObjectNode deltaOld, ObjectNode deltaNew) {

        // Check removed or changed fields from oldJson's perspective
        processExistingFields(oldJson, newJson, deltaOld, deltaNew);

        // Check added fields from the perspective of the NEW json node.
        processNewFields(oldJson, newJson, deltaNew);
    }
    
    /**
     * Process fields that exist in the old JSON to find changed or removed fields.
     */
    private static void processExistingFields(JsonNode oldJson, JsonNode newJson,
                                           ObjectNode deltaOld, ObjectNode deltaNew) {
        oldJson.fieldNames().forEachRemaining(field -> {
            JsonNode oVal = oldJson.get(field);
            JsonNode nVal = newJson.get(field);

            if (nVal == null) { // field deleted in update
                deltaOld.set(field, oVal);
                return;
            }

            if (!oVal.equals(nVal)) {
                processChangedField(field, oVal, nVal, deltaOld, deltaNew);
            }
        });
    }
    
    /**
     * Process fields that are new in the updated JSON.
     */
    private static void processNewFields(JsonNode oldJson, JsonNode newJson, ObjectNode deltaNew) {
        newJson.fieldNames().forEachRemaining(field -> {
            if (!oldJson.has(field)) { // field newly added in update
                JsonNode nVal = newJson.get(field);
                deltaNew.set(field, nVal);
            }
        });
    }
    
    /**
     * Process a field that has changed between old and new JSON.
     */
    private static void processChangedField(String field, JsonNode oVal, JsonNode nVal, 
                                         ObjectNode deltaOld, ObjectNode deltaNew) {
        if (oVal.isObject() && nVal.isObject()) {
            ObjectMapper m = new ObjectMapper();
            ObjectNode childDeltaOld = m.createObjectNode();
            ObjectNode childDeltaNew = m.createObjectNode();
            compareNodes(oVal, nVal, childDeltaOld, childDeltaNew);
            if (!childDeltaOld.isEmpty()) deltaOld.set(field, childDeltaOld);
            if (!childDeltaNew.isEmpty()) deltaNew.set(field, childDeltaNew);
        } else {
            deltaOld.set(field, oVal);
            deltaNew.set(field, nVal);
        }
    }
}
