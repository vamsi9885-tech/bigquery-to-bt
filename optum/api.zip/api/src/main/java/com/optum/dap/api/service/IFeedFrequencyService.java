package com.optum.dap.api.service;

import com.optum.dap.api.dto.FeedFrequencyResponseDto;
import com.optum.dap.api.model.FeedFrequency;
import java.util.List;

/**
 * Service interface for FeedFrequency.
 */
public interface IFeedFrequencyService {
    List<FeedFrequencyResponseDto> getAllFeedFrequencies();

    /**
     * Resolve FeedFrequency by its ID.
     * @param frequencyId the frequency ID
     * @return FeedFrequency
     */
    FeedFrequency resolveById(Integer frequencyId);
}