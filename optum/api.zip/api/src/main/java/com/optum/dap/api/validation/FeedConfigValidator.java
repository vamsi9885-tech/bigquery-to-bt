package com.optum.dap.api.validation;

import java.io.File;

import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.constants.Constant.ConnectionType;
import com.optum.dap.api.dto.FeedConfigDto;
import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigUpdateRequestDto;
import com.optum.dap.api.exception.BadRequestException;
import com.optum.dap.api.exception.RecordAlreadyExistException;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.repository.FeedsRepository;
import com.optum.dap.api.utils.Utils;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Component;

import com.optum.dap.api.dto.ExtractionSettingsDto;
import com.optum.dap.api.dto.ConnectionSettingsDto;

import com.optum.dap.api.dto.FileTransferSettingsDto;


/**
 * Validator for FeedConfig DTOs.
 * Centralizes all validation logic for feed creation and update.
 */
@Component
@RequiredArgsConstructor
public class FeedConfigValidator {

    private final FeedsRepository feedsRepository;

    /**
     * Validates all business rules for feed creation.
     * @param dto FeedConfigCreateRequestDto
     * @param clientId String
     */
    public void validateCreateRequest(FeedConfigCreateRequestDto dto, String clientId) {
        validateFeedName(dto.getFeedName(), clientId);
        validateFeedConfigByType(dto.getFeedType(), dto.getStatus(), dto.getFeedConfig());
        // Add more validations as needed
    }

    /**
     * Validates all business rules for feed update.
     * @param dto FeedConfigUpdateRequestDto
     * @param entity Feeds being updated
     */
    public void validateUpdateRequest(FeedConfigUpdateRequestDto dto, Feeds entity) {
        boolean dbActive = entity.isActive();
        boolean reqActive = dto.getIsActive();
        if (!dbActive && !reqActive) {
            throw new BadRequestException("Inactive state error: inactive feeds cannot be updated");
        }

        validateFeedConfigByType(dto.getFeedType(), dto.getStatus(), dto.getFeedConfig());
    
        // Only allow feed name change if status is PENDING
        boolean isFeedNameChanged = !entity.getFeedName().equals(dto.getFeedName());
        if (isFeedNameChanged) {
            if (entity.getStatus() == FeedStatus.PENDING) {
                // If changing feed name, validate new name and uniqueness
               
                feedsRepository.findByFeedNameAndClient_ClientId(dto.getFeedName(), entity.getClient().getClientId())
                        .ifPresent(existingFeeds -> {
                            existingFeeds.forEach(existingFeed -> {
                            if (!existingFeed.getFeedIdentifier().equals(entity.getFeedIdentifier())) {
                                throw new RecordAlreadyExistException(
                                        String.format("Feed with name '%s' already exists for client '%s'", dto.getFeedName(), entity.getClient().getClientId())
                                );
                            }
                        });
                    });
                validateFeedName(dto.getFeedName(), entity.getClient().getClientId());
            } else if (entity.getStatus() == FeedStatus.ACTIVE) {
                throw new BadRequestException("Feed name cannot be changed when feed is Submitted");
            }
        }
    }

    /**
     * Validates feed name for allowed characters and uniqueness.
     */
    public void validateFeedName(String feedName, String clientId) {
        String sanitizedFeedName = Utils.sanitizeString(feedName);
        if (!sanitizedFeedName.matches("[a-zA-Z0-9_\\- ]*")) {
            throw new BadRequestException("Feed name contains invalid characters");
        }
        if (feedsRepository.existsByFeedNameAndClient_ClientId(feedName, clientId)) {
            throw new RecordAlreadyExistException(
                    String.format("Feed with name '%s' already exists for client '%s'", feedName, clientId)
            );
        }
    }

    /**
     * Validates FeedConfigDto and ExtractionSettingsDto based on FeedType.
     * Centralizes all validation logic for PUSH, PULL_WITH_NTFS, and PULL.
     * @param feedType FeedType
     * @param feedConfig FeedConfigDto
     */
    private void validateFeedConfigByType(FeedType feedType, FeedStatus feedStatus, FeedConfigDto feedConfig) {
        if (feedStatus == FeedStatus.PENDING) {
            // Skip validation for PENDING status
            return;
        }
        validateNotNull(feedConfig, "Feed configuration cannot be null");
        
        ExtractionSettingsDto extraction = feedConfig.getExtractionSettings();
        ConnectionSettingsDto connection = feedConfig.getConnectionSettings();
        FileTransferSettingsDto fileTransfer = feedConfig.getFileTransferSettings();
        
        switch (feedType) {
            case PUSH:
                validateCondition(connection == null && fileTransfer == null, 
                    "FileTransferSettings and Connection Settings is not required for feed type PUSH");
                
                if (extraction != null) {
                    validateCondition(extraction.getRollingDate() == null && extraction.getFileNameFormat() == null,
                        "rollingDate and FileName Format must be null for PUSH feed type");
                }
                break;
                
            case PULL_WITH_NTFS:
                validateRequiredFields(extraction, connection, fileTransfer);
                
                validateCondition(extraction.getRollingDate() == null && extraction.getFileNameFormat() == null,
                    "rollingDate and FileName Format must be null for PULL_WITH_NTFS feed type");
                validateCondition(!isNullOrBlank(extraction.getStorageBasePath()),
                    "storageBasePath is required for PULL_WITH_NTFS feed type");
                validateCondition(connection.getType() == ConnectionType.NTFS,
                    "Connection type must be NTFS for PULL_WITH_NTFS feed type");
                validateCondition(!isNullOrBlank(connection.getNtfsFolderPath()),
                    "ntfsFolderPath is required for PULL_WITH_NTFS feed type");
                break;
                
            case PULL:
                validateRequiredFields(extraction, connection, fileTransfer);
                
                validateCondition(extraction.getRollingDate() != null,
                    "rollingDate is required for PULL feed type");
                validateCondition(!isNullOrBlank(extraction.getFileNameFormat()),
                    "fileNameFormat is required for PULL feed type");
                validateCondition(!isNullOrBlank(extraction.getStorageBasePath()),
                    "storageBasePath is required for PULL feed type");
                validateCondition(connection.getType() != ConnectionType.NTFS,
                    "Connection type must not be NTFS for PULL feed type");
                validateCondition(isNullOrBlank(connection.getNtfsFolderPath()),
                    "ntfsFolderPath is not required for PULL feed type");
                break;
                
            default:
                throw new BadRequestException("Unsupported feed type: " + feedType);
        }
    }

    private void validateRequiredFields(ExtractionSettingsDto extraction, ConnectionSettingsDto connection, 
                                       FileTransferSettingsDto fileTransfer) {
        validateNotNull(extraction, "extractionSettings is required");
        validateNotNull(connection, "connectionSettings is required");
        validateNotNull(fileTransfer, "fileTransferSettings is required");
    }

    private void validateNotNull(Object object, String message) {
        if (object == null) {
            throw new BadRequestException(message);
        }
    }

    private void validateCondition(boolean condition, String message) {
        if (!condition) {
            throw new BadRequestException(message);
        }
    }

    private boolean isNullOrBlank(String str) {
        return str == null || str.isBlank();
    }
}