package com.optum.dap.api.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Custom validation annotation that conditionally validates fields in ExtractionSettings
 * based on the FeedStatus. If the status is PENDING, validation constraints are relaxed.
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ConditionalExtractionSettingsValidator.class)
public @interface ConditionalExtractionSettingsValidation {
    String message() default "Invalid extraction settings";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
