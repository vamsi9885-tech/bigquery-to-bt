package com.optum.dap.api.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import com.optum.dap.api.properties.OIDCProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.oauth2.client.CommonOAuth2Provider;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.InMemoryOAuth2AuthorizedClientService;

@Configuration
public class OAuth2BeanConfig {

    @Autowired
    private OIDCProperties oidcProperties;

    @Bean
    public ClientRegistrationRepository clientRegistrationRepository() {
        return new InMemoryClientRegistrationRepository(this.sentinelRegistration());
    }

    private ClientRegistration sentinelRegistration() {
        return CommonOAuth2Provider.OKTA.getBuilder("sentinel")
                .clientId(oidcProperties.getClientId())
                .clientSecret(oidcProperties.getClientSecret())
                .authorizationUri(oidcProperties.getAuthorizationEndpoint())
                .issuerUri(oidcProperties.getIssuerUri())
                .tokenUri(oidcProperties.getTokenEndpoint())
                .userInfoUri(oidcProperties.getUserInfoEndpoint())
                .scope("openid", "profile", "email")
                .jwkSetUri(oidcProperties.getJwkSetUri())
                .redirectUri("{baseUrl}/api/login/oauth2/code/{registrationId}")
                .build();
    }

    @Bean
    public OAuth2AuthorizedClientService authorizedClientService() {
        return new InMemoryOAuth2AuthorizedClientService(clientRegistrationRepository());
    }
}