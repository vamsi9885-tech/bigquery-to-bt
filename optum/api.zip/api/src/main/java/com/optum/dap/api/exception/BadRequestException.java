package com.optum.dap.api.exception;

public class BadRequestException extends RuntimeException {
    public BadRequestException(String message) {  
        super("Bad Request: " + message);  
    }  
}
