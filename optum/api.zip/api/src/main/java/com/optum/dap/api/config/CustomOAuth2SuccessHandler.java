package com.optum.dap.api.config;

import java.io.IOException;
import java.util.Collection;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.security.oauth2.core.OAuth2AuthenticatedPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;

import lombok.extern.slf4j.Slf4j;

/**
 * Custom OAuth2 success handler that validates the ad_groups claim
 * in the JWT access token after successful authentication.
 */
@Slf4j
@Component
public class CustomOAuth2SuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {

    @Value("${auth.accessDeniedUrl:/api/access-denied}")
    private String accessDeniedUrl;
    
    @Value("${auth.required.ad.group}")
    private String requiredAdGroup;
    
    @Value("${auth.skip.authorization:false}")
    private boolean skipAuthorization;
    
    @Value("${HomePageURL:/}")
    private String homePageURL;


    @Override
    public void onAuthenticationSuccess(
            HttpServletRequest request, 
            HttpServletResponse response,
            Authentication authentication) throws IOException, ServletException {
        log.info("OAuth2 authentication success. Validating AD groups claim...");

        if (shouldSkipAuthorization()) {
            log.warn("Authorization check is skipped due to configuration flag. Proceeding without AD group validation.");
            redirectTo(response, homePageURL);
            return;
        }
        
        if (!(authentication instanceof OAuth2AuthenticationToken)) {
            log.warn("Authentication is not instance of OAuth2AuthenticationToken. Redirecting to access-denied.");
            redirectTo(response, accessDeniedUrl);
            return;
        }

        OidcUser oidcUser = extractOidcUser((OAuth2AuthenticationToken) authentication);
        if (oidcUser == null) {
            log.warn("Principal is not instance of OidcUser. Redirecting to access-denied.");
            redirectTo(response, accessDeniedUrl);
            return;
        }

        if (!isUserInRequiredAdGroup(oidcUser)) {
            log.warn("Required AD group '{}' not found in token. Redirecting to access-denied.", requiredAdGroup);
            redirectTo(response, accessDeniedUrl);
            return;
        }

        log.info("AD group validation successful. Proceeding with authentication.");
        redirectTo(response, homePageURL);
    }

    private boolean shouldSkipAuthorization() {
        return skipAuthorization || requiredAdGroup == null || requiredAdGroup.isEmpty();
    }
    
    private void redirectTo(HttpServletResponse response, String url) throws IOException {
        response.sendRedirect(url);
    }
    
    private OidcUser extractOidcUser(OAuth2AuthenticationToken authToken) {
        Object principal = authToken.getPrincipal();
        return (principal instanceof OidcUser) ? (OidcUser) principal : null;
    }
    
    private boolean isUserInRequiredAdGroup(OidcUser oidcUser) {
        try {
            String accessToken = oidcUser.getIdToken().getTokenValue();
            DecodedJWT jwt = JWT.decode(accessToken);
            Collection<String> adGroups = jwt.getClaim("ad_groups").asList(String.class);
            return adGroups != null && adGroups.contains(requiredAdGroup);
        } catch (Exception e) {
            log.warn("Error validating AD groups claim: {}", e.getMessage());
            return false;
        }
    }
  
}
