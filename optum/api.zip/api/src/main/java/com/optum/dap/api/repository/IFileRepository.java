package com.optum.dap.api.repository;

import com.optum.dap.api.model.Files;
import com.optum.dap.api.model.FilesId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Repository interface for Files using composite key.
 */
@Repository
public interface IFileRepository extends JpaRepository<Files, FilesId> {
    List<Files> findByFeedIdentifier(UUID feedIdentifier);
    Optional<Files> findByFeedIdentifierAndLogicalFileName(UUID feedIdentifier, String logicalFileName);
    boolean existsByFeedIdentifierAndLogicalFileName(UUID feedIdentifier, String logicalFileName);
    void deleteByFeedIdentifierAndLogicalFileName(UUID feedIdentifier, String logicalFileName);
}
