package com.optum.dap.api.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.constants.Constant.FeedStatus;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import lombok.*;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.util.List;

import java.time.LocalDateTime;
import java.util.UUID;

import com.optum.dap.api.transformer.FeedConfigJsonConverter;

/**
 * Entity representing feed configuration for a client.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "feeds")
public class Feeds {

    @Id
    @Column(name = "feed_identifier")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID feedIdentifier;

    @Column(name = "feed_name")
    private String feedName;

    @Column(name = "feed_type")
    @Enumerated(EnumType.STRING)
    private FeedType feedType;

    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "feed_status")
    @Enumerated(EnumType.STRING)
    private FeedStatus status;

    /**
     * Store only the frequencyId as a foreign key reference.
     * Fetch FeedFrequency details via service/repository when needed.
     */
    @Column(name = "frequency_id")
    private Integer frequencyId;

    @Column(name = "feed_config", columnDefinition = "jsonb")
    @JdbcTypeCode(SqlTypes.JSON)
    @Convert(converter = FeedConfigJsonConverter.class)
    private FeedConfig feedConfig;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "client_id")
    @JsonBackReference
    private Clients client;
    

    @JsonManagedReference
    @OneToOne(mappedBy = "feed", cascade = CascadeType.ALL, orphanRemoval = true)
    private ConnectorConfig connectorConfig;

   // Helper method to keep both sides in sync:
   public void setConnectorConfig(ConnectorConfig config) {
        this.connectorConfig = config;
        if (config != null) {
            config.setFeed(this);
        }
   }

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;
    
    @JsonManagedReference
    @OneToOne(mappedBy = "feed", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private RuntimeSettings runtimeSettings; // One-to-one mapping with RuntimeSettings

    @OneToMany(mappedBy = "feed", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Files> files;
}
