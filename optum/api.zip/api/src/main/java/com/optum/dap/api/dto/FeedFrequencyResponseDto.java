package com.optum.dap.api.dto;

import lombok.Data;

/**
 * DTO for feed frequency API response.
 */
@Data
public class FeedFrequencyResponseDto {
    private Integer frequencyId;
    private String frequencyType;
    private Integer feedWindowDates;
    private String supportedFeedType;
}