package com.optum.dap.api;

import java.time.Instant;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.NoHandlerFoundException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.fasterxml.jackson.databind.exc.MismatchedInputException;


import com.optum.dap.api.exception.*;

@RestControllerAdvice
@Slf4j
public class RestExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiError> handle(MethodArgumentNotValidException ex) {
        List<String> details = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(this::format)
                .toList();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ApiError(Instant.now(), 400, details));
    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ApiError> handleBadRequest(BadRequestException ex,
            HttpServletRequest req) {
        log.error("Bad request: {}", ex.getMessage());
        ApiError body = ApiError.of(HttpStatus.BAD_REQUEST, ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiError> handle(ConstraintViolationException ex) {
        List<String> details = ex.getConstraintViolations()
                .stream()
                .map(cv -> cv.getPropertyPath() + ": " + cv.getMessage())
                .toList();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ApiError(Instant.now(), 400, details));
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<ApiError> handleNoHandlerFound(NoHandlerFoundException ex, 
            HttpServletRequest req) {
        log.error("API not found: {} {}", ex.getHttpMethod(), ex.getRequestURL());
        String message = "No handler found for " + ex.getHttpMethod() + " " + ex.getRequestURL();
        ApiError body = ApiError.of(HttpStatus.NOT_FOUND, message);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ApiError> methodNotFound(HttpRequestMethodNotSupportedException ex, 
            HttpServletRequest req) {
        log.error("API method not allowed: {} {}", ex.getMethod(), req.getRequestURI());
        String message = "Method not allowed for " + req.getRequestURI();
        ApiError body = ApiError.of(HttpStatus.METHOD_NOT_ALLOWED, message);
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(body);
    }
    @ExceptionHandler(RecordNotFoundException.class)
    public ResponseEntity<ApiError> handleNotFound(RecordNotFoundException ex,
            HttpServletRequest req) {
        log.error("Client not found: {}", ex.getMessage());
        ApiError body = ApiError.of(HttpStatus.NOT_FOUND, ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    @ExceptionHandler(MissingConfigurationException.class)
    public ResponseEntity<ApiError> handleMissingConfiguration(MissingConfigurationException ex,
            HttpServletRequest req) {
        log.error("Missing configuration: {}", ex.getMessage());
        ApiError body = ApiError.of(HttpStatus.FAILED_DEPENDENCY, ex.getMessage());
        return ResponseEntity.status(HttpStatus.FAILED_DEPENDENCY).body(body);
    }
    @ExceptionHandler(UnExpectedException.class)
    public ResponseEntity<ApiError> handleUnExpected(UnExpectedException ex,
            HttpServletRequest req) {
        log.error("Unexpected error: {}", ex.getMessage());
        ApiError body = ApiError.of(HttpStatus.INTERNAL_SERVER_ERROR,
                List.of("Internal server error"));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiError> handleGeneric(Exception ex,
            HttpServletRequest req) {
        log.error("Unexpected error", ex);
        ApiError body = ApiError.of(HttpStatus.INTERNAL_SERVER_ERROR,
                List.of("Internal server error"));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }

    @ExceptionHandler(RecordAlreadyExistException.class)
    public ResponseEntity<ApiError> handleAlreadyExists(RecordAlreadyExistException ex,
            HttpServletRequest req) {
        log.error("Given Record is Already Exist. {}", ex.getMessage());
        ApiError body = ApiError.of(HttpStatus.CONFLICT, ex.getMessage());
        return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
    }

    @ExceptionHandler({JsonParseException.class, JsonMappingException.class, InvalidFormatException.class})
    public ResponseEntity<ApiError> handleJsonParseError(Exception ex, HttpServletRequest req) {
        log.error("JSON parsing error: {}", ex.getMessage());
        
        String message = "Invalid JSON format";
        if (ex instanceof InvalidFormatException invalidFormatEx) {
            message = String.format("Invalid value '%s' . Expected type %s", 
                invalidFormatEx.getValue(),
                invalidFormatEx.getTargetType().getSimpleName());
        } else if (ex instanceof MismatchedInputException mismatchedEx) {
            message = String.format("Invalid data format for field '%s'", 
                mismatchedEx.getPath().isEmpty() ? "unknown" : mismatchedEx.getPath().get(0).getFieldName());
        }
        
        ApiError body = ApiError.of(HttpStatus.BAD_REQUEST, "JSON parse error: " + message);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }
    
    // Keep the existing HttpMessageNotReadableException handler but modify it to filter out JsonParse exceptions
    // which are now handled by the more specific handler above
    @ExceptionHandler({HttpMessageNotReadableException.class, IllegalArgumentException.class})
    public ResponseEntity<ApiError> handleEnumConversion(Exception ex, HttpServletRequest req) {
        // Check if this is a JSON parsing error, which should be handled by handleJsonParseError
        if (ex instanceof HttpMessageNotReadableException && 
           (ex.getCause() instanceof JsonParseException || 
            ex.getCause() instanceof JsonMappingException)) {
            return handleJsonParseError((Exception) ex.getCause(), req);
        }
        
        String message = ex.getMessage();
        log.error("Invalid request: {}", message);
        ApiError body = ApiError.of(HttpStatus.BAD_REQUEST, "Invalid request: " + message);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }
    
    @ExceptionHandler(HandlerMethodValidationException.class)
    public ResponseEntity<ApiError> handleHandlerMethodValidationException(HandlerMethodValidationException ex) {
        List<String> details = ex.getAllValidationResults().stream()
            .flatMap(r -> r.getResolvableErrors().stream())
            .map(err -> err.getCodes()[0] + ": " + err.getDefaultMessage())
            .toList();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ApiError(java.time.Instant.now(), 400, details));
    }

    private String format(FieldError fe) {
        return fe.getField() + ": " + fe.getDefaultMessage();
    }

}
