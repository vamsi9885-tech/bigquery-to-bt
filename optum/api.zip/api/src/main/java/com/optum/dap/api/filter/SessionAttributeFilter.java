package com.optum.dap.api.filter;

import java.io.IOException;
import java.time.Instant;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.optum.dap.api.constants.Constant;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

/**
 * Filter to update session last accessed time for all requests except specific excluded endpoints.
 * This filter has priority 6 in the filter chain.
 */
@Slf4j
@Component
@Order(Constant.SESSION_ATTRIBUTE_FILTER)
public class SessionAttributeFilter extends OncePerRequestFilter {

    private static final String SESSION_LAST_ACCESSED_TIME = "sessionLastAccessedTime";
    private static final String[] EXCLUDED_URLS = {
        "/api/session/is-active",
        "/api/heartbeat"
    };

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {
        
        String requestURI = request.getRequestURI();
        
        // Check if the current request should be excluded from session time update
        boolean shouldUpdateSession = !isExcludedUrl(requestURI);
        
        if (shouldUpdateSession) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                // Set current time as session last accessed time
                session.setAttribute(SESSION_LAST_ACCESSED_TIME, Instant.now().toString());
                log.debug("Updated session last accessed time for URI: {}", requestURI);
            }
        }
        
        // Continue with filter chain
        filterChain.doFilter(request, response);
    }
    
    /**
     * Check if the requested URL is in the excluded list
     * 
     * @param requestURI the URI of the current request
     * @return true if the URL should be excluded, false otherwise
     */
    private boolean isExcludedUrl(String requestURI) {
        for (String excludedUrl : EXCLUDED_URLS) {
            if (requestURI.endsWith(excludedUrl)) {
                return true;
            }
        }
        return false;
    }
}