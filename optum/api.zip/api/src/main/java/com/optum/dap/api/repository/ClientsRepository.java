package com.optum.dap.api.repository;

import com.optum.dap.api.model.Clients;
import com.optum.dap.api.projection.IClientsProjection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * Repository interface for Client entity.
 */
@Repository
public interface ClientsRepository extends JpaRepository<Clients, String> {
    /**
     * Custom query to fetch all clients.
     *
     * @return List of clients projections.
     */

    List<IClientsProjection> findAllProjectedBy();


}
