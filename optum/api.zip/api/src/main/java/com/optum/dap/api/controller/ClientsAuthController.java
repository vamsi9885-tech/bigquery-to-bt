package com.optum.dap.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.optum.dap.api.dto.ClientRequestDto;
import com.optum.dap.api.service.IClientsService;
import com.optum.dap.api.utils.Utils;
import com.optum.dap.api.dto.ClientFeedsResponseDto;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/clients/auth")
public class ClientsAuthController {
    
    @Autowired
    private IClientsService clientsService;
    
    @GetMapping("/authenticate")
    public ResponseEntity<String> authenticateClient() {
        // This endpoint is used to authenticate the client.
        // The actual authentication logic should be implemented here.
        // For now, we can just return a success message or status.
        log.info("Client authenticated successfully.");
        return ResponseEntity.ok("Client authenticated successfully.");
    }
     /**
     * POST endpoint to create a new client.
     * 
     * @param requestDto client details to create
     * @return response with success message or error
     */
    @PostMapping("/createClient")
    public ResponseEntity<?> createClient(
            @RequestBody @Valid ClientRequestDto requestDto) {
            String sanitizedClientId = Utils.sanitizeString(requestDto.getClientId());
            log.info("Create Client {} Request Received", sanitizedClientId);
            clientsService.createClient(requestDto);
            log.info("Client {} created successfully", sanitizedClientId);
            return ResponseEntity.ok(
                java.util.Collections.singletonMap(
                    "message", "Client " + sanitizedClientId + " added successfully"
                )
            );
    }
    /**
     * GET endpoint to retrieve all feeds for a client.
     *
     * @param clientId the client identifier
     * @return client details with all feeds
     */
    @GetMapping("/{clientId}/feeds")
    public ResponseEntity<ClientFeedsResponseDto> getAllFeedsByClientId(@PathVariable String clientId) {
        String sanitizedClientId = Utils.sanitizeString(clientId);
        log.info("Fetching all feeds for clientId: {}", sanitizedClientId);
        ClientFeedsResponseDto response = clientsService.getAllFeedsByClientId(clientId);
        log.info("Feeds fetched successfully for clientId: {}", sanitizedClientId);
        return ResponseEntity.ok(response);
    }
}
