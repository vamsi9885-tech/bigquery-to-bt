package com.optum.dap.api.repository;

import com.optum.dap.api.model.Feeds;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.optum.dap.api.constants.Constant;

import java.util.List;
import java.util.UUID;
import java.util.Optional;

/**
 * Repository for Feeds.
 */
@Repository
public interface FeedsRepository extends JpaRepository<Feeds, UUID> {
    Optional<Feeds> findByFeedIdentifier(UUID feedIdentifier);
    Optional<List<Feeds>> findByFeedNameAndClient_ClientId(String feedName, String clientId);
    boolean existsByFeedNameAndClient_ClientId(String feedName, String clientId);
    /**
     * Finds active feeds by client ID.
     *
     * @param clientId the client identifier
     * @return list of active feeds
     */
    List<Feeds> findByClient_ClientIdAndStatus(String clientId, Constant.FeedStatus status);
}