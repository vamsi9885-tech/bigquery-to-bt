package com.optum.dap.api.repository;

import com.optum.dap.api.model.ConnectorConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;
import java.util.Optional;

@Repository
public interface ConnectorConfigRepository extends JpaRepository<ConnectorConfig, UUID> {
    Optional<ConnectorConfig> findByFeed_FeedIdentifier(UUID feedIdentifier);
}