package com.optum.dap.api.dto;

import com.optum.dap.api.constants.Constant.FeedType;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.dap.api.constants.Constant.FeedStatus;
import lombok.Data;
import java.util.List;

/**
 * DTO representing detailed information about a feed.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FeedDetailsDto {
    private String feedName;
    private String feedId;
    private boolean isActive;
    private FeedStatus status;
    private FeedType feedType;
    private String feedFrequency;
    private String connectorType;
    private String connectorVersion;
    private FeedConfigDto feedConfig;
    private RuntimeConfigDto implementationSettings;
    private List<FileDto> files;
    
    @JsonProperty("isActive")
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }
}