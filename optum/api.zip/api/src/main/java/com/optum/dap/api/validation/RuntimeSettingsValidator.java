package com.optum.dap.api.validation;

import com.optum.dap.api.constants.Constant;
import com.optum.dap.api.dto.RuntimeConfigDto;
import com.optum.dap.api.exception.BadRequestException;
import com.optum.dap.api.model.Feeds;

import org.springframework.stereotype.Component;

import com.optum.dap.api.model.FeedFrequency;
import com.optum.dap.api.repository.IFeedFrequencyRepository;

import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;

import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;

/**
 * Validator for runtime settings.
 */
@Component
@Slf4j
public class RuntimeSettingsValidator {
    @Autowired
    private IFeedFrequencyRepository feedFrequencyRepository;

    /**
     * Validates runtime settings configuration
     * @param dto RuntimeConfigDto to validate
     * @param feed Feed entity to validate against
     * @throws BadRequestException if validation fails
     */
    public void validate(RuntimeConfigDto dto, Feeds feed) {
        // Extract the validations into separate methods to reduce cognitive complexity
        validateCronSettingsForFeedType(dto, feed);
        validateDateRanges(dto);
        validateSplitBy(dto);
        validateFrequencySettings(dto, feed);
    }

    /**
     * Validates cron settings based on feed type
     */
    private void validateCronSettingsForFeedType(RuntimeConfigDto dto, Feeds feed) {
        Constant.FeedType feedType = feed.getFeedType();
        log.info("Validating cron settings for feed type: {}", feedType);
        if (feedType == Constant.FeedType.PULL) {
            if (dto.getCronSettings() == null) {
                throw new BadRequestException("cronSettings is required for PULL feeds");
            }
        } else if ((feedType == Constant.FeedType.PUSH || feedType == Constant.FeedType.PULL_WITH_NTFS) 
                && dto.getCronSettings() != null) {
            throw new BadRequestException("cronSettings is not allowed for PUSH or PULL_WITH_NTFS feeds");
        }
    }
    
    /**
     * Validates date ranges 
     */
    private void validateDateRanges(RuntimeConfigDto dto) {
        // Validate start and end dates
        LocalDate startDate = dto.getStartDate();
        LocalDate endDate = dto.getEndDate();
        
        if (startDate != null && endDate != null && !startDate.isBefore(endDate)) {
            throw new BadRequestException("startDate must be before endDate");
        }
        
        // Validate end and periodic start dates
        LocalDate periodicStartDate = dto.getPeriodicStartDate();
        
        if (endDate != null && periodicStartDate != null && !endDate.isBefore(periodicStartDate)) {
            throw new BadRequestException("endDate must be before periodicStartDate");
        }
    }
    
    /**
     * Validates the splitBy value
     */
    private void validateSplitBy(RuntimeConfigDto dto) {
        Integer splitBy = dto.getSplitBy();
        
        if (splitBy == null || !feedFrequencyRepository.existsById(splitBy)) {
            throw new BadRequestException("Invalid splitBy: " + splitBy + ". Must be a valid SplitBy.");
        }
    }
    
    /**
     * Validates frequency-specific settings
     */
    private void validateFrequencySettings(RuntimeConfigDto dto, Feeds feed) {
        Integer frequencyId = feed.getFrequencyId();
        
        if (frequencyId == null) {
            return; // Skip validation if frequency not set
        }
        
        FeedFrequency freqEntity = feedFrequencyRepository.findById(frequencyId)
                .orElseThrow(() -> new BadRequestException("Invalid frequencyId: " + frequencyId));
        
        if (frequencyId == 1) {
            validateDailyFrequencySettings(dto);
        } else {
            validateNonDailyFrequencySettings(dto, freqEntity);
        }
    }
    
    /**
     * Validates settings for daily frequency (frequencyId=1)
     */
    private void validateDailyFrequencySettings(RuntimeConfigDto dto) {
        if (dto.getLagOffset() != null && dto.getLagOffset() != 0) {
            throw new BadRequestException("lagOffset must be 0 for daily frequency");
        }
        
        if (dto.getLagTolerance() != null && dto.getLagTolerance() != 0) {
            throw new BadRequestException("lagTolerance must be 0 for daily frequency");
        }
    }
    
    /**
     * Validates settings for non-daily frequencies
     */
    private void validateNonDailyFrequencySettings(RuntimeConfigDto dto, FeedFrequency freqEntity) {
        Integer maxWindow = freqEntity.getFeedWindowDates();
        if (maxWindow == null) {
            maxWindow = Integer.MAX_VALUE;
        }
        
        Integer lagOffset = dto.getLagOffset() != null ? dto.getLagOffset() : 0;
        Integer lagTolerance = dto.getLagTolerance() != null ? dto.getLagTolerance() : 0;
        if(lagOffset < 0 || lagTolerance < 0 ) {
            throw new BadRequestException("lagOffset and lagTolerance must be zero or positive");
        }
        if (lagOffset > maxWindow || lagTolerance > maxWindow) {
            throw new BadRequestException(
                "lagOffset must be less than or equal to " + maxWindow + 
                " for frequency " + freqEntity.getFrequencyType()
            );
        }
        int sum = lagOffset + lagTolerance;
        if (sum >= maxWindow) {
            throw new BadRequestException(
                "lagOffset + lagTolerance must be less than " + maxWindow + 
                " for frequency " + freqEntity.getFrequencyType()
            );
        }
    }
}
