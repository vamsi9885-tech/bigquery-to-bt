package com.optum.dap.api;
import java.time.Instant;  
import java.util.List;

import org.springframework.http.HttpStatus;  
  
public record ApiError(Instant timestamp,  
                       int status,  
                       List<String> errors) {

                         /* Convenient factory methods */  
    public static ApiError of(HttpStatus status, String singleError) {  
        return new ApiError(Instant.now(), status.value(), List.of(singleError));  
    }  
  
    public static ApiError of(HttpStatus status, List<String> errorList) {  
        return new ApiError(Instant.now(), status.value(), errorList);  
    }  

} 