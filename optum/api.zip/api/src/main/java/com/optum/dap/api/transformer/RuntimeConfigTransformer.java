package com.optum.dap.api.transformer;

import com.optum.dap.api.constants.Constant;
import com.optum.dap.api.dto.RuntimeConfigDto;
import com.optum.dap.api.dto.CronSettingsDto;
import com.optum.dap.api.model.RuntimeSettings;
import com.optum.dap.api.model.RuntimeSettingConfig;
import com.optum.dap.api.model.ConnectorConfig;
import com.optum.dap.api.model.CronSettings;
import org.springframework.stereotype.Component;
import com.optum.dap.api.repository.IFeedFrequencyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.time.LocalDateTime;
import com.optum.dap.api.utils.Utils;

/**
 * Transformer for RuntimeConfig DTOs and Entity.
 * Handles mapping between DTOs and RuntimeSettings, including enum and JSONB serialization.
 * Also updates ConnectorConfig for spec fields.
 */
@Component
public class RuntimeConfigTransformer {

    @Autowired
    private IFeedFrequencyRepository feedFrequencyRepository;

    /**
     * Transforms a RuntimeSettings entity to a RuntimeConfigDto
     * 
     * @param entity The RuntimeSettings entity to transform
     * @param connectorConfig The ConnectorConfig providing spec information
     * @return The resulting RuntimeConfigDto
     */
    public RuntimeConfigDto toDto(RuntimeSettings entity, ConnectorConfig connectorConfig) {
        if (entity == null) return null;
        
        RuntimeConfigDto dto = new RuntimeConfigDto();
        dto.setIsAdhocRun(entity.isAdhocRun());
        dto.setExtractionType(entity.getExtractionType() != null ? 
                Constant.ExtractionType.fromValue(entity.getExtractionType()) : null);
        
        dto.setSplitBy(entity.getSplitBy());
        
        // Set splitByType if splitBy is available
        if (entity.getSplitBy() != null) {
            feedFrequencyRepository.findById(entity.getSplitBy())
                .ifPresent(freq -> dto.setSplitByType(freq.getFrequencyType()));
        }
        
        dto.setStartDate(entity.getAdhocStartDate());
        dto.setEndDate(entity.getAdhocEndDate());
        dto.setPeriodicStartDate(entity.getPeriodicStartDate() != null ? 
                entity.getPeriodicStartDate().toLocalDate() : null);
        
        dto.setLagOffset(entity.getLagOffset());
        dto.setLagTolerance(entity.getLagTolerance());
        dto.setNotifyType(entity.getNotifyType() != null ? 
                Constant.NotifyType.fromValue(entity.getNotifyType()) : null);
        dto.setEnableRunStatusNotification(entity.getEnableRunStatusNotification());
        
        // Update cron settings
        updateCronSettingsFromEntity(dto, entity);
        
        // Set connector config fields if available
        if (connectorConfig != null) {
            dto.setSpecName(connectorConfig.getSpecName());
            dto.setSpecVersion(connectorConfig.getSpecVersion());
        }
        
        return dto;
    }

    /**
     * Transforms a RuntimeConfigDto to a new RuntimeSettings entity
     * 
     * @param dto The RuntimeConfigDto to transform
     * @return The resulting RuntimeSettings entity
     */
    public RuntimeSettings toEntity(RuntimeConfigDto dto) {
        if (dto == null) return null;
        
        String loggedInUser = Utils.getLoggedInUsername();
        LocalDateTime now = LocalDateTime.now();
        
        // Use builder pattern for cleaner code and better readability
        RuntimeSettings entity = RuntimeSettings.builder()
                .isAdhocRun(dto.getIsAdhocRun() != null ? dto.getIsAdhocRun() : false)
                .extractionType(dto.getExtractionType() != null ? dto.getExtractionType().getValue() : null)
                .splitBy(dto.getSplitBy())
                .adhocStartDate(dto.getStartDate())
                .adhocEndDate(dto.getEndDate())
                .periodicStartDate(dto.getPeriodicStartDate() != null ? dto.getPeriodicStartDate().atStartOfDay() : null)
                .lagOffset(dto.getLagOffset())
                .lagTolerance(dto.getLagTolerance())
                .notifyType(dto.getNotifyType() != null ? dto.getNotifyType().getValue() : null)
                .enableRunStatusNotification(dto.getEnableRunStatusNotification())
                .modifiedBy(loggedInUser != null ? loggedInUser : "system")
                .modifiedDate(now)
                .build();
        
        // Update cron settings separately since it requires complex object creation
        if (dto.getCronSettings() != null) {
            updateCronSettingsFromDto(dto, entity);
        }
        
        return entity;
    }

    /**
     * Updates a RuntimeSettings entity from a RuntimeConfigDto
     * 
     * @param dto The source RuntimeConfigDto
     * @param entity The target RuntimeSettings entity to update
    //  */
    public void updateEntityFromDto(RuntimeConfigDto dto, RuntimeSettings entity) {
        if (dto == null || entity == null) return;
        
        // Update simple fields
        entity.setAdhocRun(dto.getIsAdhocRun() != null ? dto.getIsAdhocRun() : true);
        entity.setExtractionType(dto.getExtractionType() != null ? dto.getExtractionType().getValue() : null);
        entity.setSplitBy(dto.getSplitBy());
        entity.setAdhocStartDate(dto.getStartDate());
        entity.setAdhocEndDate(dto.getEndDate());
        entity.setPeriodicStartDate(dto.getPeriodicStartDate() != null ? dto.getPeriodicStartDate().atStartOfDay() : null);
        entity.setLagOffset(dto.getLagOffset());
        entity.setLagTolerance(dto.getLagTolerance());
        entity.setNotifyType(dto.getNotifyType() != null ? dto.getNotifyType().getValue() : null);
        entity.setEnableRunStatusNotification(dto.getEnableRunStatusNotification());
        
        // Update cron settings
        updateCronSettingsFromDto(dto, entity);
        
        // Update audit fields
        String loggedInUser = Utils.getLoggedInUsername();
        entity.setModifiedBy(loggedInUser != null ? loggedInUser : "system");
        entity.setModifiedDate(LocalDateTime.now());
    }
    
    /**
     * Updates the cron settings from DTO to entity
     * 
     * @param dto The source RuntimeConfigDto containing cron settings
     * @param entity The target RuntimeSettings entity to update
     */
    public void updateCronSettingsFromDto(RuntimeConfigDto dto, RuntimeSettings entity) {
        if (dto == null || entity == null || dto.getCronSettings() == null) return;
        
        CronSettingsDto dtoSettings = dto.getCronSettings();
        
        // Use builder pattern for cleaner, more maintainable code
        CronSettings cronSettings = CronSettings.builder()
                .timeOfDay(dtoSettings.getTimeOfDay())
                .dayOfWeek(dtoSettings.getDayOfWeek())
                .dayOfMonth(dtoSettings.getDayOfMonth())
                .monthOfYear(dtoSettings.getMonthOfYear())
                .build();
        
        // Use builder for RuntimeSettingConfig if available or create with minimal setup
        RuntimeSettingConfig configJson = new RuntimeSettingConfig();
        configJson.setCronSettings(cronSettings);
        entity.setRuntimeSettingConfig(configJson);
    }

    /**
     * Updates the cron settings from entity to DTO
     * 
     * @param dto The target RuntimeConfigDto to update
     * @param entity The source RuntimeSettings entity containing cron settings
     */
    public void updateCronSettingsFromEntity(RuntimeConfigDto dto, RuntimeSettings entity) {
        if (dto == null || entity == null || 
            entity.getRuntimeSettingConfig() == null || 
            entity.getRuntimeSettingConfig().getCronSettings() == null) {
            return;
        }
        
        CronSettings entitySettings = entity.getRuntimeSettingConfig().getCronSettings();
        
        // Create DTO with values from entity
        CronSettingsDto cronSettingsDto = new CronSettingsDto();
        cronSettingsDto.setTimeOfDay(entitySettings.getTimeOfDay());
        cronSettingsDto.setDayOfWeek(entitySettings.getDayOfWeek());
        cronSettingsDto.setDayOfMonth(entitySettings.getDayOfMonth());
        cronSettingsDto.setMonthOfYear(entitySettings.getMonthOfYear());
        
        dto.setCronSettings(cronSettingsDto);
    }

    /**
     * Updates connector configuration from DTO
     * 
     * @param dto The source RuntimeConfigDto containing connector config data
     * @param connectorConfig The target ConnectorConfig to update
     */
    public void updateConnectorConfigFromDto(RuntimeConfigDto dto, ConnectorConfig connectorConfig) {
        if (dto == null || connectorConfig == null) return;
        connectorConfig.setSpecName(dto.getSpecName());
        connectorConfig.setSpecVersion(dto.getSpecVersion());
    }
}