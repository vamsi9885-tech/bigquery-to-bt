package com.optum.dap.api.service.impl;

import com.optum.dap.api.dto.FileDto;
import com.optum.dap.api.exception.BadRequestException;
import com.optum.dap.api.exception.RecordAlreadyExistException;
import com.optum.dap.api.exception.RecordNotFoundException;
import com.optum.dap.api.exception.UnExpectedException;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.model.Files;
import com.optum.dap.api.repository.FeedsRepository;
import com.optum.dap.api.repository.IFileRepository;
import com.optum.dap.api.service.IAuditService;
import com.optum.dap.api.service.IFileService;
import com.optum.dap.api.validation.FileConfigValidator;
import com.optum.dap.api.transformer.FileTransformer;
import com.optum.dap.api.utils.Utils;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

import com.optum.dap.api.constants.Constant;
import com.optum.dap.api.utils.DeepCopyUtil;

/**
 * Service implementation for managing file configurations for feeds.
 */
@Slf4j
@Service
public class FileServiceImpl implements IFileService {
    @Autowired
    private IFileRepository fileRepository;
    @Autowired
    private FeedsRepository feedsRepository;
    @Autowired
    private FileTransformer fileTransformer;
    @Autowired
    private FileConfigValidator fileConfigValidator;
    @Autowired
    private IAuditService auditService;

    @Autowired
    private DeepCopyUtil deepCopyUtil;
    private static final String FILE_LABLE = "File";
    private static final String FILE_NOT_FOUND = "File not found: ";
       
    @Override
    public List<FileDto> getFiles(String clientId, String feedIdentifier) {
        String sanitizedClientId = Utils.sanitizeString(clientId);
        String sanitizedFeedIdentifier = Utils.sanitizeString(feedIdentifier);
        try {
            Feeds feed = getFeedOrThrow(feedIdentifier, clientId);
            List<Files> entities = fileRepository.findByFeedIdentifier(feed.getFeedIdentifier());
            return entities.stream().map(fileTransformer::toDto).collect(Collectors.toList());
        }
        catch (RecordNotFoundException e) {
            log.error("Feed not found for identifier: {}, clientid: {} error: {}", sanitizedFeedIdentifier, sanitizedClientId, e);
            throw new RecordNotFoundException("Feed not found: " + feedIdentifier);
        } catch (Exception e) {
            log.error("Unexpected error while retrieving files for feed: {}, error: {}", sanitizedFeedIdentifier, e);
            throw new UnExpectedException("An unexpected error occurred while retrieving files for feed: " + sanitizedFeedIdentifier, e); 
        } 
        
    }

    @Override
    @Transactional
    public void saveFiles(String clientId, String feedIdentifier, List<FileDto> files) {
        String sanitizedClientId = Utils.sanitizeString(clientId);
        String sanitizedFeedIdentifier = Utils.sanitizeString(feedIdentifier);
        log.info("Saving files for clientId={}, feedIdentifier={}", sanitizedClientId, sanitizedFeedIdentifier);
        try{
        Feeds feed = getFeedOrThrow(feedIdentifier, clientId);
        if (!feed.isActive()) {
            throw new BadRequestException("Cannot save files: Feed is not active. Feed name:" + sanitizedFeedIdentifier);
        }
        if (files == null || files.isEmpty()) {
            log.warn("No files provided for feed: {}", sanitizedFeedIdentifier);
            throw new BadRequestException("No files provided for feed: " + feedIdentifier);
        }
        // Delegate all validation to validator
        fileConfigValidator.validateCreateRequest(files, feed);
        log.info("Successfully validated file creation request for feed: {} ", sanitizedFeedIdentifier);
        for (FileDto dto : files) {
            if (dto.getPartCount() == null || dto.getPartCount() < 1) {
                dto.setPartCount(1);
            }
            if (dto.getPartStartSeq() == null || dto.getPartStartSeq() < 1) {
                dto.setPartStartSeq(1);
            }
            String loggedInUser = Utils.getLoggedInUsername();
            Files entity = fileTransformer.toEntity(dto, feed.getFeedIdentifier(), loggedInUser);
            log.info("Successfully created file entity for feed: {} and logicalFile : {}", sanitizedFeedIdentifier, Utils.sanitizeString(dto.getLogicalFileName()));
            auditService.logAudit( Constant.AuditType.FILE_CREATION,FILE_LABLE, entity, null, clientId, UUID.fromString(feedIdentifier));
            fileRepository.save(entity);
        }
        log.info("Successfully saved files for feed: {}.", sanitizedFeedIdentifier);
        }
        catch (RecordAlreadyExistException e) {
            log.error("File already exists for feed: {} and client {}, error: {}", sanitizedFeedIdentifier, sanitizedClientId, e);
            throw new RecordAlreadyExistException("Given Logical File name already exists for feed: " + feedIdentifier);
        } catch (BadRequestException e) {
            log.error("Bad request while saving files for feed: {} and client {}, error: {}", sanitizedFeedIdentifier, sanitizedClientId, e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error while saving files for feed: {} and clientid: {} , error {}", sanitizedFeedIdentifier, sanitizedClientId, e);
            throw new UnExpectedException("An unexpected error occurred while saving files for feed: " + sanitizedFeedIdentifier, e);
        }
    }

    @Override
    @Transactional
    public void updateFile(String clientId, String feedIdentifier, String logicalFileName, FileDto file) {
        String sanitizedClientId = Utils.sanitizeString(clientId);
        String sanitizedFeedIdentifier = Utils.sanitizeString(feedIdentifier);
        String sanitizedLogicalFileName = Utils.sanitizeString(logicalFileName);
        log.info("Updating file for clientId={}, feedIdentifier={}, logicalFileName={}", 
                sanitizedClientId, 
                sanitizedFeedIdentifier, 
                sanitizedLogicalFileName);
        try{
        Feeds feed = getFeedOrThrow(feedIdentifier, clientId);
        if (!feed.isActive()) {
            throw new BadRequestException("Cannot update file: Feed is not active. Feed name:" + feedIdentifier);
        }
        Files fileDAO = fileRepository.findByFeedIdentifierAndLogicalFileName(feed.getFeedIdentifier(), logicalFileName)
                .orElseThrow(() -> new RecordNotFoundException(FILE_NOT_FOUND + logicalFileName));
        // Delegate all validation to validator
        Files oldEntity = deepCopyUtil.deepCopy(fileDAO, Files.class);
        fileConfigValidator.validateUpdateRequest(file, feed);
        log.info("Successfully validated file update request for feed: {} and logical file name: {}", sanitizedFeedIdentifier, sanitizedLogicalFileName);
        if (file.getPartCount() == null || file.getPartCount() < 1) {
            file.setPartCount(1);
        }
        if (file.getPartStartSeq() == null || file.getPartStartSeq() < 1) {
            file.setPartStartSeq(1);
        }
        String loggedInUser = Utils.getLoggedInUsername();
        Files updated = fileTransformer.updateToEntity(fileDAO, file, feed.getFeedIdentifier(), loggedInUser);
        fileRepository.save(updated);
        log.info("Successfully updated file entity for feed: {} and logical file name: {}", sanitizedFeedIdentifier, sanitizedLogicalFileName);
        auditService.logAudit( Constant.AuditType.FILE_UPDATE,FILE_LABLE, updated, oldEntity, clientId, UUID.fromString(feedIdentifier));
    }
    catch (RecordNotFoundException e) {
            log.error("File not found for feed: {} and logical file name: {}", sanitizedFeedIdentifier, sanitizedLogicalFileName, e);
            throw new RecordNotFoundException(FILE_NOT_FOUND + logicalFileName);
        } catch (BadRequestException | RecordAlreadyExistException e) {
            // RecordAlreadyExistException is caught here to handle cases where the logical file name already exists
            log.error("Bad request  or Record already exist while updating file for feed: {} and logical file name: {}", sanitizedFeedIdentifier, sanitizedLogicalFileName, e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error while updating file for feed: {} and logical file name: {}", sanitizedFeedIdentifier, sanitizedLogicalFileName, e);
            throw new UnExpectedException("An unexpected error occurred while updating file for feed: " + sanitizedFeedIdentifier, e);
        }
    }

    @Override
    @Transactional
    public void deleteFile(String clientId, String feedIdentifier, String logicalFileName) {
       String sanitizedClientId = Utils.sanitizeString(clientId);
        String sanitizedFeedIdentifier = Utils.sanitizeString(feedIdentifier);
        String sanitizedLogicalFileName = Utils.sanitizeString(logicalFileName);
        log.info("Deleting file for clientId={}, feedIdentifier={}, logicalFileName={}", 
                sanitizedClientId, 
                sanitizedFeedIdentifier, 
                sanitizedLogicalFileName);
       try{
        Feeds feed = getFeedOrThrow(feedIdentifier, clientId);
        if (!feed.isActive()) {
            throw new BadRequestException("Cannot delete file:Feed is not active. Feed name:" + feedIdentifier);
        }
        Files file = fileRepository.findByFeedIdentifierAndLogicalFileName(feed.getFeedIdentifier(), logicalFileName)
                .orElseThrow(() -> new RecordNotFoundException(FILE_NOT_FOUND + logicalFileName));
        log.info("Successfully found file entity for feed: {} and logical file name: {}", sanitizedFeedIdentifier, sanitizedLogicalFileName);
        fileRepository.deleteByFeedIdentifierAndLogicalFileName(feed.getFeedIdentifier(), logicalFileName);
        log.info("Successfully deleted file entity for feed: {} and logical file name: {}", sanitizedFeedIdentifier, sanitizedLogicalFileName);
        auditService.logAudit( Constant.AuditType.FILE_DELETE,FILE_LABLE, null, file, clientId, UUID.fromString(feedIdentifier));
        }
         catch (RecordNotFoundException e) {
            log.error("File not found for feed: {} and logical file name: {} and error {}", sanitizedFeedIdentifier, sanitizedLogicalFileName, e);
            throw new RecordNotFoundException(FILE_NOT_FOUND + logicalFileName);
        } catch (BadRequestException e) {
            log.error("Bad request while deleting file for feed: {} and logical file name: {} and error :{}", sanitizedFeedIdentifier, sanitizedFeedIdentifier, e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error while deleting file for feed: {} and logical file name: {} and error :{}", sanitizedFeedIdentifier, sanitizedFeedIdentifier, e.getMessage());
            throw new UnExpectedException("An unexpected error occurred while deleting file for feed: " + feedIdentifier, e);
        }
    }

    private Feeds getFeedOrThrow(String feedIdentifier, String clientId) {
        UUID feedId = UUID.fromString(feedIdentifier);
        Feeds feed = feedsRepository.findById(feedId)
                .orElseThrow(() -> new RecordNotFoundException("Feed not found: " + feedIdentifier));
        if (feed.getClient() == null || !feed.getClient().getClientId().equals(clientId)) {
            throw new RecordNotFoundException("Feed does not belong to the specified client");
        }
        return feed;
    }
}
