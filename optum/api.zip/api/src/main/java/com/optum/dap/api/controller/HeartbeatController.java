package com.optum.dap.api.controller;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * REST controller to handle heartbeat requests.
 */
@Slf4j
@RestController
@RequestMapping("/api/heartbeat")
public class HeartbeatController {

    /**
     * Health check endpoint.
     *
     * @return service status and current timestamp.
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> heartbeat() {
        log.info("Heartbeat endpoint called.");
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("timestamp", Instant.now().toString());
        return ResponseEntity.ok(response);
    }
}
