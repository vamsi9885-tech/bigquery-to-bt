package com.optum.dap.api.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

/**
 * Annotation for validating connection settings based on feed type.
 * This validation ensures that:
 * - For PULL feeds, connection type must not be NTFS and ntfsFolderPath must be null
 * - For PULL_WITH_NTFS feeds, connection type must be NTFS and ntfsFolderPath must not be blank
 * - For PUSH feeds, connection settings are not required
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = ConnectionSettingsValidator.class)
public @interface ConditionalConnectionSettingsValidation {
    String message() default "Invalid connection settings for feed type";
    
    Class<?>[] groups() default {};
    
    Class<? extends Payload>[] payload() default {};
}
