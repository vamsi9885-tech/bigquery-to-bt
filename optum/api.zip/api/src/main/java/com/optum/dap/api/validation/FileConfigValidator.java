package com.optum.dap.api.validation;

import com.optum.dap.api.dto.FileDto;
import com.optum.dap.api.exception.BadRequestException;
import com.optum.dap.api.exception.RecordAlreadyExistException;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.repository.IFileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Validator for FileConfig DTOs.
 * Centralizes all validation logic for file creation and update.
 */
@Component
@RequiredArgsConstructor
public class FileConfigValidator {

    private final IFileRepository fileRepository;

    /**
     * Validates all business rules for file creation.
     * @param files List<FileDto>
     * @param feed Feeds
     */
    public void validateCreateRequest(List<FileDto> files, Feeds feed) {
        for (FileDto dto : files) {
            validateByFeedType(dto, feed);
            if (fileRepository.existsByFeedIdentifierAndLogicalFileName(feed.getFeedIdentifier(), dto.getLogicalFileName())) {
                throw new RecordAlreadyExistException("File with logicalFileName " + dto.getLogicalFileName() + " already exists for this feed");
            }
        }
    }

    /**
     * Validates all business rules for file update.
     * @param dto FileDto
     * @param feed Feeds
     */
    public void validateUpdateRequest(FileDto dto, Feeds feed) {
        validateByFeedType(dto, feed);
    }

    /**
     * Validates file DTO based on feed type.
     * @param dto FileDto
     * @param feed Feeds
     */
    private void validateByFeedType(FileDto dto, Feeds feed) {
        String feedType = feed.getFeedType().name();
        if ("PULL".equalsIgnoreCase(feedType)) {
            if (dto.getFileId() == null || dto.getFileId().isEmpty()) {
                throw new BadRequestException("fileId is mandatory for Pull feeds");
            }
            if (dto.getFileNameFormat() == null || dto.getFileNameFormat().isEmpty()) {
                throw new BadRequestException("fileNameFormat is mandatory for Pull feeds");
            }
        }
        // For PUSH and PULL_WITH_NTFS, fileId and fileNameFormat may be null; no action needed.
        // filter and parameters can always be null.
    }
}