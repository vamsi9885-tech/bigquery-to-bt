package com.optum.dap.api.transformer;

import com.optum.dap.api.dto.FeedConfigCreateRequestDto;
import com.optum.dap.api.dto.FeedConfigUpdateRequestDto;
import com.optum.dap.api.dto.ExtractionSettingsDto;
import com.optum.dap.api.dto.ConnectionSettingsDto;
import com.optum.dap.api.dto.FileTransferSettingsDto;
import com.optum.dap.api.dto.FileTransferSettingsDetailDto;
import com.optum.dap.api.dto.FeedConfigDto;
import com.optum.dap.api.dto.FeedResponseDto;
import com.optum.dap.api.dto.ParameterDto;
import com.optum.dap.api.model.FeedConfig;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.model.Clients;
import com.optum.dap.api.model.ConnectionSettings;
import com.optum.dap.api.model.ConnectorConfig;
import com.optum.dap.api.model.FileTransferSettingsDetail;
import com.optum.dap.api.model.FileTransferSettings;
import com.optum.dap.api.model.FeedFrequency;
import com.optum.dap.api.model.ExtractionSettings;
import com.optum.dap.api.model.Parameters;
import com.optum.dap.api.service.IFeedFrequencyService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.optum.dap.api.utils.Utils;
import com.optum.dap.api.transformer.CommonTransformer;

/**
 * Transformer for FeedConfig DTOs and Entity.
 * Handles mapping between DTOs and Feeds, including frequency type from FeedFrequency.
 */
@Component
public class FeedConfigTransformer {

    @Autowired
    private IFeedFrequencyService feedFrequencyResolver;
    

    /**
     * Converts FeedConfigCreateRequestDto to Feeds.
     * @param dto FeedConfigCreateRequestDto
     * @param client Clients entity
     * @return Feeds entity
     */
    public Feeds toEntity(FeedConfigCreateRequestDto dto, Clients client) {
        Feeds entity = new Feeds();
        
        // Map basic feed attributes
        mapBasicFeedAttributes(dto, entity);
        
        // Setup connector config
        setupConnectorConfig(entity, dto.getConnectorType(), dto.getConnectorVersion());
        
        // Map feed configuration
        mapFeedConfigToEntity(dto.getFeedConfig(), entity);
        
        String loggedInUser = Utils.getLoggedInUsername();
        LocalDateTime now = LocalDateTime.now();
        // Set audit fields for new entity
        entity.setClient(client);
        entity.setCreatedBy(loggedInUser);
        entity.setCreatedDate(now);
        entity.setModifiedBy(loggedInUser);
        entity.setModifiedDate(now);
        
        return entity;
    }

    /**
     * Updates Feeds from FeedConfigUpdateRequestDto.
     * @param dto FeedConfigUpdateRequestDto
     * @param entity Feeds entity to update
     * @param client Clients entity
     */
    public void updateEntityFromDto(FeedConfigUpdateRequestDto dto, Feeds entity, Clients client) {
        // Map basic feed attributes
        entity.setFeedName(dto.getFeedName());
        entity.setFeedType(dto.getFeedType());
        entity.setActive(dto.getIsActive());
        entity.setStatus(dto.getStatus());
        entity.setFrequencyId(dto.getFrequencyId());
        // Update connector config
        setupConnectorConfig(entity, dto.getConnectorType(), dto.getConnectorVersion());
        // Map feed configuration
        mapFeedConfigToEntity(dto.getFeedConfig(), entity);
        // Update audit fields
        entity.setClient(client);
        entity.setModifiedBy( Utils.getLoggedInUsername());
        entity.setModifiedDate(LocalDateTime.now());
    }
    
    /**
     * Maps basic feed attributes from DTO to entity
     * @param dto Source DTO with feed attributes
     * @param entity Target feed entity
     */
    private void mapBasicFeedAttributes(FeedConfigCreateRequestDto dto, Feeds entity) {
        entity.setFeedName(dto.getFeedName());
        entity.setFeedType(dto.getFeedType());
        entity.setActive(dto.getIsActive());
        entity.setStatus(dto.getStatus());
        entity.setFrequencyId(dto.getFrequencyId());
    }
    
    /**
     * Sets up connector configuration for the feed entity
     * @param entity Feed entity to update
     * @param connectorType Connector type
     * @param connectorVersion Connector version
     */
    private void setupConnectorConfig(Feeds entity, String connectorType, String connectorVersion) {
        ConnectorConfig connectorConfig = entity.getConnectorConfig();
        if (connectorConfig == null) {
            connectorConfig = new ConnectorConfig();
            entity.setConnectorConfig(connectorConfig);
        }
        connectorConfig.setConnectorType(connectorType);
        connectorConfig.setEmrVersion(connectorVersion);
    }
    
    /**
     * Maps feed configuration from DTO to entity
     * @param feedConfigDto Source feed configuration DTO
     * @param entity Target feed entity
     */
    private void mapFeedConfigToEntity(FeedConfigDto feedConfigDto, Feeds entity) {
        FeedConfig feedConfig = new FeedConfig();
        
        mapConnectionSettings(feedConfigDto.getConnectionSettings(), feedConfig);
        mapExtractionSettings(feedConfigDto.getExtractionSettings(), feedConfig);
        mapFileTransferSettings(feedConfigDto.getFileTransferSettings(), feedConfig);
        
        entity.setFeedConfig(feedConfig);
    }
    
    /**
     * Maps connection settings from DTO to entity
     * @param connectionSettingsDto Source connection settings DTO
     * @param feedConfig Target feed configuration
     */
    private void mapConnectionSettings(ConnectionSettingsDto connectionSettingsDto, FeedConfig feedConfig) {
        if (connectionSettingsDto != null) {
            ConnectionSettings connectionSettings = new ConnectionSettings();
            connectionSettings.setConnectionString(connectionSettingsDto.getConnectionString());
            connectionSettings.setType(connectionSettingsDto.getType());
            connectionSettings.setNtfsFolderPath(connectionSettingsDto.getNtfsFolderPath());
            feedConfig.setConnectionSettings(connectionSettings);
        }
    }
    
    /**
     * Maps extraction settings from DTO to entity
     * @param extractionSettingsDto Source extraction settings DTO
     * @param feedConfig Target feed configuration
     */
    private void mapExtractionSettings(ExtractionSettingsDto extractionSettingsDto, FeedConfig feedConfig) {
        if (extractionSettingsDto != null) {
            ExtractionSettings extractionSettings = new ExtractionSettings();
            extractionSettings.setColumnDelimiter(extractionSettingsDto.getColumnDelimiter());
            extractionSettings.setRowDelimiter(extractionSettingsDto.getRowDelimiter());
            extractionSettings.setQuote(extractionSettingsDto.getQuote());
            extractionSettings.setStorageBasePath(extractionSettingsDto.getStorageBasePath());
            extractionSettings.setFilter(extractionSettingsDto.getFilter());
            extractionSettings.setDataCleansing(extractionSettingsDto.getDataCleansing());
            extractionSettings.setRollingDate(extractionSettingsDto.getRollingDate());
            extractionSettings.setFileNameFormat(extractionSettingsDto.getFileNameFormat());
            extractionSettings.setParameters(CommonTransformer.convertDtoListToEntityList(extractionSettingsDto.getParameters()));
            feedConfig.setExtractionSettings(extractionSettings);
        }
    }
    
        /**
     * Maps file transfer settings from DTO to entity
     * @param fileTransferSettingsDto Source file transfer settings DTO
     * @param feedConfig Target feed configuration
     */
    private void mapFileTransferSettings(FileTransferSettingsDto fileTransferSettingsDto, FeedConfig feedConfig) {
        if (fileTransferSettingsDto != null) {
            FileTransferSettings fileTransferSettingsEntity = new FileTransferSettings();
            fileTransferSettingsEntity.setType(fileTransferSettingsDto.getType());
            
            FileTransferSettingsDetailDto detailsDto = fileTransferSettingsDto.getSettings();
            if (detailsDto != null) {
                FileTransferSettingsDetail detailsEntity = new FileTransferSettingsDetail();
                detailsEntity.setEnable(detailsDto.getEnable());
                detailsEntity.setHostName(detailsDto.getHostName());
                detailsEntity.setKnownHostFile(detailsDto.getKnownHostFile());
                detailsEntity.setLandingDirectory(detailsDto.getLandingDirectory());
                detailsEntity.setUserName(detailsDto.getUserName());
                fileTransferSettingsEntity.setFileTransferSettingsDetail(detailsEntity);
            }
            feedConfig.setFileTransferSettings(fileTransferSettingsEntity);
        }
    }

    
    /**
     * Converts Feeds to FeedResponseDto.
     * Maps all fields for full response, including frequency type from FeedFrequency.
     * @param entity Feeds entity
     * @return FeedResponseDto
     */
    public FeedResponseDto toResponseDto(Feeds entity) {
        FeedResponseDto dto = new FeedResponseDto();
        dto.setFeedId(entity.getFeedIdentifier() != null ? entity.getFeedIdentifier().toString() : null);
        dto.setFeedName(entity.getFeedName());
        dto.setActive(entity.isActive());
        dto.setStatus(entity.getStatus());
        dto.setFeedType(entity.getFeedType());

        String frequencyType = null;
        if (entity.getFrequencyId() != null) {
            FeedFrequency freqEntity = feedFrequencyResolver.resolveById(entity.getFrequencyId());
            frequencyType = freqEntity.getFrequencyType();
            dto.setFrequencyId(freqEntity.getFrequencyId());
        }
        dto.setFeedFrequency(frequencyType);


        if (entity.getConnectorConfig() != null) {
            dto.setConnectorType(entity.getConnectorConfig().getConnectorType());
            dto.setConnectorVersion(entity.getConnectorConfig().getEmrVersion());
        }

        // Map feed config to DTO
        mapEntityFeedConfigToDto(entity, dto);

        return dto;
    }
    
    /**
     * Maps feed configuration from entity to DTO
     * @param entity Source feed entity
     * @param dto Target response DTO
     */
    private void mapEntityFeedConfigToDto(Feeds entity, FeedResponseDto dto) {
        FeedConfig feedConfig = entity.getFeedConfig();
        if (feedConfig == null) {
            return;
        }
        
        FeedConfigDto feedConfigDto = new FeedConfigDto();
        
        // Map connection settings
        if (feedConfig.getConnectionSettings() != null) {
            ConnectionSettingsDto connectionSettingsDto = new ConnectionSettingsDto();
            connectionSettingsDto.setConnectionString(feedConfig.getConnectionSettings().getConnectionString());
            connectionSettingsDto.setType(feedConfig.getConnectionSettings().getType());
            connectionSettingsDto.setNtfsFolderPath(feedConfig.getConnectionSettings().getNtfsFolderPath());
            feedConfigDto.setConnectionSettings(connectionSettingsDto);
        }
        
        // Map extraction settings
        mapEntityExtractionSettingsToDto(feedConfig, feedConfigDto);
        
        // Map file transfer settings
        mapEntityFileTransferSettingsToDto(feedConfig, feedConfigDto);
        
        dto.setFeedConfig(feedConfigDto);
    }
    
    /**
     * Maps extraction settings from entity to DTO
     * @param feedConfig Source feed configuration
     * @param feedConfigDto Target feed configuration DTO
     */
    private void mapEntityExtractionSettingsToDto(FeedConfig feedConfig, FeedConfigDto feedConfigDto) {
        ExtractionSettings extractionSettings = feedConfig.getExtractionSettings();
        if (extractionSettings != null) {
            ExtractionSettingsDto extractionSettingsDto = new ExtractionSettingsDto();
            extractionSettingsDto.setColumnDelimiter(extractionSettings.getColumnDelimiter());
            extractionSettingsDto.setRowDelimiter(extractionSettings.getRowDelimiter());
            extractionSettingsDto.setQuote(extractionSettings.getQuote());
            extractionSettingsDto.setStorageBasePath(extractionSettings.getStorageBasePath());

            extractionSettingsDto.setDataCleansing(extractionSettings.getDataCleansing());
            extractionSettingsDto.setRollingDate(extractionSettings.getRollingDate());
            extractionSettingsDto.setFileNameFormat(extractionSettings.getFileNameFormat());
            extractionSettingsDto.setParameters(CommonTransformer.mapParametersToParameterDtos(extractionSettings.getParameters()));
            extractionSettingsDto.setFilter(extractionSettings.getFilter());
            feedConfigDto.setExtractionSettings(extractionSettingsDto);
        }
    }
    
    /**
     * Maps file transfer settings from entity to DTO
     * @param feedConfig Source feed configuration
     * @param feedConfigDto Target feed configuration DTO
     */
    private void mapEntityFileTransferSettingsToDto(FeedConfig feedConfig, FeedConfigDto feedConfigDto) {
        if (feedConfig.getFileTransferSettings() != null) {
            FileTransferSettingsDto fileTransferSettingsDto = new FileTransferSettingsDto();
            fileTransferSettingsDto.setType(feedConfig.getFileTransferSettings().getType());
            
            FileTransferSettingsDetail details = feedConfig.getFileTransferSettings().getFileTransferSettingsDetail();
            if (details != null) {
                FileTransferSettingsDetailDto detailsDto = new FileTransferSettingsDetailDto();
                detailsDto.setEnable(details.getEnable());
                detailsDto.setHostName(details.getHostName());
                detailsDto.setKnownHostFile(details.getKnownHostFile());
                detailsDto.setLandingDirectory(details.getLandingDirectory());
                detailsDto.setUserName(details.getUserName());
                fileTransferSettingsDto.setSettings(detailsDto);
            }
            feedConfigDto.setFileTransferSettings(fileTransferSettingsDto);
        }
    }
    public FeedConfigDto toFeedConfigDto(FeedConfig entity) {
        if (entity == null) return null;

        FeedConfigDto dto = new FeedConfigDto();
        dto.setExtractionSettings(toExtractionSettingsDto(entity.getExtractionSettings()));
        dto.setConnectionSettings(toConnectionSettingsDto(entity.getConnectionSettings()));
        dto.setFileTransferSettings(toFileTransferSettingsDto(entity.getFileTransferSettings()));
        return dto;
    }

    private ExtractionSettingsDto toExtractionSettingsDto(ExtractionSettings entity) {
        if (entity == null) return null;

        ExtractionSettingsDto dto = new ExtractionSettingsDto();
        dto.setRollingDate(entity.getRollingDate());
        dto.setFileNameFormat(entity.getFileNameFormat());
        dto.setRowDelimiter(entity.getRowDelimiter());
        dto.setColumnDelimiter(entity.getColumnDelimiter());
        dto.setQuote(entity.getQuote());
        dto.setStorageBasePath(entity.getStorageBasePath());
        dto.setFilter(entity.getFilter());
        dto.setParameters(CommonTransformer.mapParametersToParameterDtos(entity.getParameters()));
        dto.setDataCleansing(entity.getDataCleansing());
        return dto;
    }

    private ConnectionSettingsDto toConnectionSettingsDto(ConnectionSettings entity) {
        if (entity == null) return null;

        ConnectionSettingsDto dto = new ConnectionSettingsDto();
        dto.setType(entity.getType());
        dto.setConnectionString(entity.getConnectionString());
        dto.setNtfsFolderPath(entity.getNtfsFolderPath());
        return dto;
    }

    private FileTransferSettingsDto toFileTransferSettingsDto(FileTransferSettings entity) {
        if (entity == null) return null;
    
        FileTransferSettingsDto dto = new FileTransferSettingsDto();
        dto.setType(entity.getType());
        // Ensure the `settings` field exists in `FileTransferSettings` and is correctly mapped
        dto.setSettings(entity.getFileTransferSettingsDetail() != null ? toFileTransferSettingsDetailDto(entity.getFileTransferSettingsDetail()) : null);
        return dto;
    }

    private FileTransferSettingsDetailDto toFileTransferSettingsDetailDto(FileTransferSettingsDetail entity) {
        if (entity == null) return null;

        FileTransferSettingsDetailDto dto = new FileTransferSettingsDetailDto();
        dto.setHostName(entity.getHostName());
        dto.setUserName(entity.getUserName());
        dto.setKnownHostFile(entity.getKnownHostFile());
        dto.setLandingDirectory(entity.getLandingDirectory());
        dto.setEnable(entity.getEnable());
        return dto;
    }
}