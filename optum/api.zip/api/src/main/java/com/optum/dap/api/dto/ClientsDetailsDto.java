package com.optum.dap.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * Data Transfer Object for client details.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientsDetailsDto {
    private String clientId;
    private String clientName;
    private boolean isActive;
    @JsonProperty("isActive")
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }
}
