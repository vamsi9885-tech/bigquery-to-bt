package com.optum.dap.api.dto;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import jakarta.validation.Valid;
import com.optum.dap.api.constants.Constant.FeedType;
import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.validation.ConditionalExtractionSettingsValidation;
import com.optum.dap.api.validation.ConditionalConnectionSettingsValidation;
import com.optum.dap.api.validation.ConditionalFileTransferSettingsValidation;

/**
 * DTO for creating a new feed configuration.
 */
@Data
@ConditionalExtractionSettingsValidation
@ConditionalConnectionSettingsValidation
@ConditionalFileTransferSettingsValidation
public class FeedConfigCreateRequestDto {

    @NotBlank(message = "Feed name must not be blank")
    @Pattern(regexp = "^[a-zA-Z0-9_-]+$", message = "Input must contain letters and numbers.")
    @Size(max = 255, message = "Feed Name must be less than 255 characters long")
    @Valid
    private String feedName;

    @NotNull(message = "Feed type must not be null")
    @Valid
    private FeedType feedType;

    @NotNull(message = "Active flag must not be null")
    @Valid
    private Boolean isActive;

    @NotNull(message = "Feed status must not be null")
    @Valid
    private FeedStatus status;

    @NotNull(message = "frequencyId must not be null")
    @Valid
    private Integer frequencyId;

    @NotBlank(message = "Connector type must not be blank")
    @Valid
    private String connectorType;

    @NotBlank(message = "Connector version must not be blank")
    @Valid
    private String connectorVersion;

    @NotNull(message = "Feed config must not be null")
    @Valid
    private FeedConfigDto feedConfig;
}