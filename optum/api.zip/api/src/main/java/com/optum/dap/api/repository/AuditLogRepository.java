package com.optum.dap.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.optum.dap.api.model.AuditLog;
import java.util.UUID;

public interface  AuditLogRepository extends JpaRepository<AuditLog, UUID> {
}
