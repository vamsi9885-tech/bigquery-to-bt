package com.optum.dap.api.service.impl;

import com.optum.dap.api.service.ISessionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.time.Instant;
import java.time.format.DateTimeParseException;

/**
 * Implementation of session service to handle session-related operations
 */


@Service
@Slf4j
public class SessionServiceImpl implements ISessionService {

    /**
     * Checks if the current user session is active
     * @return true if the session is active, false otherwise
     */

    private static final String SESSION_LAST_ACCESSED_TIME = "sessionLastAccessedTime";

    @Override
    public boolean isSessionActive() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        // Check if authentication exists and user is authenticated (not anonymous)
        boolean isActive = authentication != null && 
                          authentication.isAuthenticated() && 
                          !authentication.getPrincipal().equals("anonymousUser");
        
        log.debug("Session active check: {}", isActive);
        return isActive;
    }
    
    /**
     * Checks if the current user session is active and not timed out
     * @return true if the session is active and not timed out, false otherwise
     */
    @Override
    public boolean isSessionActiveWithTimeout() {
        // First check if the session is active using the existing method
        if (!isSessionActive()) {
            log.debug("Session is not active, returning false");
            return false;
        }
        
        // Get the current HTTP session
        HttpSession session = getCurrentSession();
        if (session == null) {
            log.debug("No HTTP session found, returning false");
            return false;
        }
        
        // Get the current time
        Instant currentTime = Instant.now();
        
        // Check for the session attribute
        Object sessionLastAccessedTimeObj = session.getAttribute(SESSION_LAST_ACCESSED_TIME);
        Instant sessionLastAccessedTime = null;
        
        // Handle different types or missing value
        if (sessionLastAccessedTimeObj == null) {
            log.debug("Setting initial session last accessed time");
            session.setAttribute(SESSION_LAST_ACCESSED_TIME, currentTime.toString());
            return true;
        } else {
            // Convert the stored value to Instant
            try {
                if (sessionLastAccessedTimeObj instanceof String) {
                    sessionLastAccessedTime = Instant.parse((String) sessionLastAccessedTimeObj);
                } else if (sessionLastAccessedTimeObj instanceof Instant) {
                    sessionLastAccessedTime = (Instant) sessionLastAccessedTimeObj;
                } else {
                    log.warn("Invalid type for sessionLastAccessedTime: {}", 
                            sessionLastAccessedTimeObj.getClass().getName());
                    // Reset the session time if invalid type
                    session.setAttribute(SESSION_LAST_ACCESSED_TIME, currentTime.toString());
                    return true;
                }
            } catch (DateTimeParseException e) {
                log.warn("Failed to parse sessionLastAccessedTime: {}", e.getMessage());
                // Reset the session time if parsing fails
                session.setAttribute(SESSION_LAST_ACCESSED_TIME, currentTime.toString());
                return true;
            }
        }
        
        // Get the max inactive interval in seconds
        int maxInactiveInterval = session.getMaxInactiveInterval();
        
        // Calculate expiration time
        Instant expirationTime = sessionLastAccessedTime.plusSeconds(maxInactiveInterval);
        
        // Check if the session has expired
        boolean isValid = currentTime.isBefore(expirationTime);
        
        if (!isValid) {
            session.invalidate();
            log.debug("Session has expired. Last accessed: {}, max inactive interval: {} seconds", 
                     sessionLastAccessedTime, maxInactiveInterval);
        }
        
        return isValid;
    }
    
    /**
     * Helper method to get the current HTTP session
     * @return the current HTTP session or null if not available
     */
    private HttpSession getCurrentSession() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attr == null) {
            return null;
        }
        
        HttpServletRequest request = attr.getRequest();
        return request.getSession(false);
    }
}