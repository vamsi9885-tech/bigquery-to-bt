package com.optum.dap.api.dto;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Data
public class ClientRequestDto {
    @NotNull(message = "Client Id cannot be null")
    @Valid
    @Pattern(regexp = "^[a-z0-9_-]+$", message = "Input must contain only lower case letters and numbers.")
    @Size(max = 16, message = "Client Id must be less than 16 characters long")
    private String clientId;

    @NotNull(message = "Client Name cannot be null")
    @Valid
    @Pattern(regexp = "^[a-zA-Z0-9_ -]+$", message = "Input must contain only letters, numbers, underscore and spaces.")
    @Size(max = 255, message = "Client Name must be less than 255 characters long")
    private String clientName;

    @NotNull(message = "Active status cannot be null")
    private boolean isActive;

    @JsonProperty("isActive")
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }
    @Valid
    private ClientConfigDto clientConfig;
    public ClientRequestDto() {
        this.clientConfig = new ClientConfigDto();
        this.isActive = true;
    }
}
