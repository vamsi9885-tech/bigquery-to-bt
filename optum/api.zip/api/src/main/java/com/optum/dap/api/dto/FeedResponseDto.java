package com.optum.dap.api.dto;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.dap.api.constants.Constant.FeedStatus;
import com.optum.dap.api.constants.Constant.FeedType;
import jakarta.validation.Valid;

/**
 * DTO for feed config response.
 */
@Data
public class FeedResponseDto {
    private String feedId;
    private String feedName;
    private boolean isActive;
    private FeedStatus status;
    private FeedType feedType;
    private String feedFrequency;
    private int frequencyId;
    private String connectorType;
    private String connectorVersion;
    @Valid
    private FeedConfigDto feedConfig;

    @JsonProperty("isActive")
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }
}