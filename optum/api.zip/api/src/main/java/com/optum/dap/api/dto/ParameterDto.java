package com.optum.dap.api.dto;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;

/**
 * DTO for extraction parameter key-value pairs.
 */
@Data
public class ParameterDto {
    @NotBlank(message = "param name must not be blank")
    private String paramName;
    @NotBlank(message = "param value must not be blank")
    private String paramValue;
}