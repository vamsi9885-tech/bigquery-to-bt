package com.optum.dap.api.transformer;

import jakarta.persistence.Converter;
import com.optum.dap.api.model.FileConfig;

@Converter(autoApply = false)
public class FileConfigJsonConverter extends GenericJsonbConverter<FileConfig> {
    public FileConfigJsonConverter() {
        super(FileConfig.class);
    }
}