package com.optum.dap.api.controller;

import com.optum.dap.api.dto.FeedFrequencyResponseDto;
import com.optum.dap.api.service.IFeedFrequencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * REST controller for feed frequency API.
 */
@RestController
@RequestMapping("/api/feedfrequency")
public class FeedFrequencyController {

    @Autowired
    private IFeedFrequencyService feedFrequencyService;

    /**
     * GET /api/feedfrequency
     * @return List of feed frequencies
     */
    @GetMapping
    public ResponseEntity<List<FeedFrequencyResponseDto>> getFeedFrequencies() {
        List<FeedFrequencyResponseDto> result = feedFrequencyService.getAllFeedFrequencies();
        return ResponseEntity.ok(result);
    }
}