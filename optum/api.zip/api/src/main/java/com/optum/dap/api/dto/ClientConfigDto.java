package com.optum.dap.api.dto;
import lombok.Data;
import com.optum.dap.api.validation.SemicolonSeparatedEmails;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

@Data
public class ClientConfigDto {

    public ClientConfigDto(){
        this.preserveArchives = true; // Default value
        this.feedCompletionNotificationEnabled = true; // Default value
        this.purgeOldFilesDays = 90; // Default value
        this.internalNotificationEmails= "";
        this.externalNotificationEmails = "";

    }
    @SemicolonSeparatedEmails
    private String internalNotificationEmails;

    @SemicolonSeparatedEmails
    private String externalNotificationEmails;

    @NotNull(message = "Preserve archives must not be null")
    private Boolean preserveArchives;

    @NotNull(message = "Feed completion notification must not be null")
    private Boolean feedCompletionNotificationEnabled;

    @Min(value = 0, message = "Purge old files days must be zero or positive")
    @Max(value = 365, message = "Purge old files days cannot exceed 365")
    private int purgeOldFilesDays;

}
