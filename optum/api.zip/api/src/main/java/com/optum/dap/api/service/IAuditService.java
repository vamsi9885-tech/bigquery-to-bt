package com.optum.dap.api.service;

import java.util.UUID;
import com.optum.dap.api.constants.Constant.AuditType;


public interface IAuditService {
    
    public void logAudit(AuditType action, String entityName, Object newValue, Object oldValue, String clientId, UUID feedIdentifier);
}
