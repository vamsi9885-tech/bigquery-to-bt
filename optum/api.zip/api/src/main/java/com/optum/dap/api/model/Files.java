package com.optum.dap.api.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.optum.dap.api.dto.FileDto;
import com.optum.dap.api.transformer.FeedConfigJsonConverter;
import com.optum.dap.api.transformer.GenericJsonbConverter;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

import com.optum.dap.api.transformer.FileConfigJsonConverter;

/**
 * Entity representing a file configuration for a feed.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "files")
@IdClass(FilesId.class)
public class Files {

    @Id
    @Column(name = "feed_identifier", nullable = false)
    private UUID feedIdentifier;

    @Id
    @Column(name = "logical_file_name", nullable = false)
    private String logicalFileName;

    @Column(name = "file_config", columnDefinition = "jsonb")
    @JdbcTypeCode(SqlTypes.JSON)
    @Convert(converter = FileConfigJsonConverter.class)
    private FileConfig fileConfig;


    @Column(name = "is_active", nullable = false)
    private boolean isActive;

    @Column(name = "modified_by", nullable = false)
    private String modifiedBy;

    @Column(name = "modified_date", nullable = false)
    private LocalDateTime modifiedDate;

    @Column(name = "created_by", nullable = false)
    private String createdBy;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "feed_identifier", referencedColumnName = "feed_identifier", insertable = false, updatable = false)
    @JsonIgnore
    private Feeds feed;
}