package com.optum.dap.api.service.impl;

import com.optum.dap.api.dto.ClientsDetailsDto;
import com.optum.dap.api.dto.ClientsResponseDto;
import com.optum.dap.api.dto.ClientRequestDto;
import com.optum.dap.api.model.Clients;
import com.optum.dap.api.projection.IClientsProjection;
import com.optum.dap.api.repository.ClientsRepository;
import com.optum.dap.api.dto.ClientFeedsResponseDto;
import com.optum.dap.api.service.IClientsService;
import com.optum.dap.api.transformer.ClientDetailsTransformer;
import com.optum.dap.api.model.Feeds;
import com.optum.dap.api.constants.Constant;
import lombok.extern.slf4j.Slf4j;
import com.optum.dap.api.repository.FeedsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.optum.dap.api.service.IAuditService;

import com.optum.dap.api.model.ClientConfig;

import java.util.List;
import com.optum.dap.api.utils.Utils;
import com.optum.dap.api.utils.DeepCopyUtil;
import com.optum.dap.api.constants.Constant.AuditType;

import com.optum.dap.api.exception.*;

/**
 * Implementation of IClientsService.
 */
@Slf4j
@Service
public class ClientsServiceImpl implements IClientsService {

    @Autowired
    private ClientsRepository clientsRepository;

    @Autowired
    private ClientDetailsTransformer clientDetailsTransformer;
    
    @Autowired
    private FeedsRepository feedsRepository;

    @Autowired
    private IAuditService auditService;

    @Autowired
    private DeepCopyUtil deepCopyUtil;

    /**
     * {@inheritDoc}
     */
    @Override
    public List<ClientsDetailsDto> getAllClients() {
        log.info("Fetching all client details");
        List<IClientsProjection> clients = clientsRepository.findAllProjectedBy();
        log.info("Number of clients fetched: {}", clients.size());
        if (clients.isEmpty()) {
            log.info("No clients details found Returning empty list");
        }
        return clientDetailsTransformer.toClientsDetailsDtoList(clients);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ClientsResponseDto getClientDetailsById(String clientId) {
        String sanitizedClientId = Utils.sanitizeString(clientId);
        log.info("Fetching client details for clientId: {}", sanitizedClientId);
        Clients client = clientsRepository.findById(clientId)
                .orElseThrow(() -> {
                    log.error("Client not found for id: {}", sanitizedClientId);
                    return new RecordNotFoundException(String.format(Constant.CLIENT_NOT_FOUND, clientId));
                });
        return clientDetailsTransformer.toClientsResponseDto(client);
    }

    @Override
    public void createClient(ClientRequestDto requestDto) {
        
        String clientId = requestDto.getClientId();
        String sanitizedClientId = Utils.sanitizeString(clientId);
        log.info("Creating new client with ID: {}", sanitizedClientId);

        if (clientsRepository.existsById(clientId)) {
            log.error("Client with ID {} already exists", sanitizedClientId);
            throw new RecordAlreadyExistException(String.format("Client with ID %s already exists", clientId));
        }

        try {
            Clients client = clientDetailsTransformer.toClientsEntity(requestDto);
            log.info("Client object created: {}", sanitizedClientId);
            clientsRepository.save(client);

            auditService.logAudit(AuditType.CLIENT_CREATE, "Clients", client, null, clientId, null);
            log.info("Client created successfully with ID: {}", sanitizedClientId);
        } catch (Exception e) {
            log.error("Exception occured while creating new Client: {}", e.getMessage());
            throw new UnExpectedException("Exception occurred while creating new Client", e);
        }
    }

    @Override
    public void updateClient(String clientId, ClientRequestDto requestDto) {
        String sanitizedClientId = Utils.sanitizeString(clientId);
        log.info("Updating client with ID: {}", sanitizedClientId);

        
        try {
            // Validate client IDs match
            if (!clientId.equals(requestDto.getClientId())) {
                log.error("Client ID mismatch: path={}, body={}", sanitizedClientId, Utils.sanitizeString(requestDto.getClientId()));
                throw new BadRequestException("Client ID in request body must match URL path");
            }
            
            // Fetch client
            Clients client = clientsRepository.findById(clientId)
                .orElseThrow(() -> {
                    log.error("Client not found with ID: {}", sanitizedClientId);
                    return new RecordNotFoundException(String.format(Constant.CLIENT_NOT_FOUND, sanitizedClientId));
                });
            Clients oldClientValue = deepCopyUtil.deepCopy(client, Clients.class);
            // Check if attempting to update inactive client without activating it
            if (!client.isActive() && !requestDto.isActive()) {
                log.error("Cannot update inactive client: {}", sanitizedClientId);
                throw new BadRequestException("Inactive clients cannot be updated without activating them");
            }

            // Update client properties
            updateClientFields(client, requestDto);
            clientsRepository.save(client);
            auditService.logAudit(AuditType.CLIENT_UPDATE, "Clients", client, oldClientValue, clientId, null);

            log.info("Client {} updated successfully", sanitizedClientId);
        } catch (BadRequestException | RecordNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("Failed to update client {}: {}", sanitizedClientId, e.getMessage());
            throw new UnExpectedException("Failed to update client: " + e.getMessage(), e);
        }
    }

    private void updateClientFields(Clients client, ClientRequestDto requestDto) {
        String userName = Utils.getLoggedInUsername();
        client.setClientName(requestDto.getClientName());
        client.setActive(requestDto.isActive());
        client.setClientConfig(clientDetailsTransformer.toClientConfig(requestDto.getClientConfig()));
        client.setModifiedBy(userName); // Replace with authenticated user if available
        client.setModifiedDate(java.time.LocalDateTime.now());
    }

    @Override
    public ClientFeedsResponseDto getAllFeedsByClientId(String clientId) {
        String sanitizedClientId = Utils.sanitizeString(clientId);
        log.info("Fetching all active feeds for clientId: {}", sanitizedClientId);

        try {
            // Fetch client details
            Clients client = clientsRepository.findById(clientId)
                    .orElseThrow(() -> {
                        log.error("Client not found for id: {}", sanitizedClientId);
                        return new RecordNotFoundException(String.format(Constant.CLIENT_NOT_FOUND, clientId));
                    });

            // Fetch feeds with status = Active for the client
            List<Feeds> feeds = feedsRepository.findByClient_ClientIdAndStatus(clientId, Constant.FeedStatus.ACTIVE);

            // Transform client and feeds data into response DTO
            ClientFeedsResponseDto response = clientDetailsTransformer.toClientFeedsResponseDto(client, feeds);

            log.info("Feeds fetched successfully for clientId: {}", sanitizedClientId);
            return response;
        } catch (BadRequestException | RecordNotFoundException | MissingConfigurationException ex) {
            log.error("Error fetching feeds for clientId {}: {}", sanitizedClientId, ex.getMessage());
            throw ex;
        }  catch (Exception ex) {
            log.error("Unexpected error while fetching feeds for clientId {}: {}", sanitizedClientId, ex.getMessage());
            throw new UnExpectedException("Failed to fetch feeds for clientId: " + sanitizedClientId, ex);
        }
    }


}
