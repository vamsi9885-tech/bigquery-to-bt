package com.optum.dap.api.repository;

import com.optum.dap.api.model.RuntimeSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.UUID;

/**
 * Repository for runtime settings.
 */
@Repository
public interface IRuntimeSettingsRepository extends JpaRepository<RuntimeSettings, UUID> {
    Optional<RuntimeSettings> findByFeedIdentifier(UUID feedIdentifier);
}
