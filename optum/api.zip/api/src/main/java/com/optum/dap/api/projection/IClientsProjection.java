package com.optum.dap.api.projection;

// Clients 
public interface IClientsProjection {
    String getClientId();
    String getClientName();
    boolean getIsActive();
}
