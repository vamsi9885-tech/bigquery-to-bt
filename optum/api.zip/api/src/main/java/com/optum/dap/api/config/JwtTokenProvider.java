package com.optum.dap.api.config;

import java.io.Serializable;
import java.security.interfaces.RSAPublicKey;
import java.time.Instant;
import java.net.URI;
import java.net.URL;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.stereotype.Component;

import jakarta.security.auth.message.AuthException;
import lombok.extern.slf4j.Slf4j;
import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.UrlJwkProvider;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.optum.dap.api.properties.OIDCProperties;

/**
 * Provider for JWT token operations including verification and claim extraction
 */
@Slf4j
@Component
public class JwtTokenProvider {
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private OIDCProperties oidcProperties;

    /**
     * Verifies the JWT signature against the JWKS endpoint
     *
     * @param jwtToken the JWT token to verify
     * @return true if the signature is valid, false otherwise
     */
    public boolean verifyJwtSignature(String jwtToken) {
        try {
            DecodedJWT jwt = JWT.decode(jwtToken);
            
            // Retrieve public keys from JWKS endpoint for signature verification
            URI jwkSetUri = URI.create(oidcProperties.getJwkSetUri());
            JwkProvider provider = new UrlJwkProvider(jwkSetUri.toURL());
            Jwk jwk = provider.get(jwt.getKeyId());

            Algorithm algorithm = Algorithm.RSA256((RSAPublicKey) jwk.getPublicKey(), null);
            algorithm.verify(jwt); // verify the digital signature
            
            // Check if token is expired
            if (jwt.getExpiresAt().before(Date.from(Instant.now()))) {
                log.warn("Token verification failed: Token has expired");
                return false;
            }
            
            return true;
        } catch (TokenExpiredException e) {
            log.warn("Token verification failed: Token has expired", e);
            return false;
        } catch (JWTVerificationException e) {
            log.error("Token verification failed: Invalid JWT signature", e);
            return false;
        } catch (JwkException e) {
            log.error("Token verification failed: Error retrieving JWK", e);
            return false;
        } catch (Exception e) {
            log.error("Token verification failed: Unexpected error", e);
            return false;
        }
    }

    /**
     * Extracts a claim from a JWT token
     *
     * @param jwtToken  the JWT token to analyze
     * @param claimName the name of the claim to extract
     * @return the value of the claim as a String
     * @throws AuthException if the token signature is invalid
     */
    public String getClaimFromToken(String jwtToken, String claimName) throws AuthException {
        if (!verifyJwtSignature(jwtToken)) {
            throw new AuthException("Invalid JWT Signature");
        }
        
        try {
            DecodedJWT jwt = JWT.decode(jwtToken);
            Claim claim = jwt.getClaim(claimName);
            
            if (claim.isNull()) {
                log.debug("Claim '{}' not found in token", claimName);
                return null;
            }
            
            return claim.asString();
        } catch (Exception e) {
            log.error("Error extracting claim from token", e);
            throw new AuthException("Error processing JWT token: " + e.getMessage());
        }
    }
    
    /**
     * Extracts all claims from a JWT token
     *
     * @param jwtToken the JWT token to analyze
     * @return the decoded JWT with all claims
     * @throws AuthException if the token signature is invalid
     */
    public DecodedJWT getAllClaims(String jwtToken) throws AuthException {
        if (!verifyJwtSignature(jwtToken)) {
            throw new AuthException("Invalid JWT Signature");
        }
        
        return JWT.decode(jwtToken);
    }
}
