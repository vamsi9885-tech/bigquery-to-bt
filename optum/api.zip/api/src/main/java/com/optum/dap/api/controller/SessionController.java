package com.optum.dap.api.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.oidc.OidcIdToken;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import com.optum.dap.api.dto.UserDto;
import com.optum.dap.api.properties.OIDCProperties;
import com.optum.dap.api.service.ISessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.RequestParam;



@Slf4j
@RestController
@RequestMapping("/api/session")
public class SessionController {
    /**
     * OIDC properties. Marked as optional to avoid unsatisfied dependency in test context.
     */
    @Autowired(required = false)
    private OIDCProperties oidcProperties;

    @GetMapping("/me")
    public ResponseEntity<UserDto> getLoggedInUserDetails() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || "anonymousUser".equals(authentication.getPrincipal())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        if (authentication.getPrincipal() instanceof org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser) {
            DefaultOidcUser userDetails = (DefaultOidcUser)authentication.getPrincipal();
            log.info("Login User details: {}", userDetails);
            UserDto userDto = new UserDto();
            userDto.setUserId(userDetails.getPreferredUsername());
            userDto.setUserEmail(userDetails.getEmail());
            userDto.setUserName(userDetails.getClaim("name").toString());
            return ResponseEntity.ok(userDto);
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    @GetMapping("/logout")
    public RedirectView logoutget(
            HttpServletRequest request,Authentication authentication) {
        // send logout URL to client so they can initiate logout
        String logoutUrl = this.oidcProperties.getLogoutEndpoint();
        Map<String, String> logoutDetails = new HashMap<>();
          if (authentication != null && authentication.getPrincipal() instanceof DefaultOidcUser) {
            DefaultOidcUser oidcUser = (DefaultOidcUser) authentication.getPrincipal();
            OidcIdToken idToken = oidcUser.getIdToken();
            if (idToken != null) {
                String idTokenValue = idToken.getTokenValue();
                logoutUrl = logoutUrl +"?id_token="+idTokenValue;
            }

        }

        logoutDetails.put("logoutUrl", logoutUrl);
        HttpSession session = request.getSession();
        if (session != null) {
            request.getSession(false).invalidate();
        }
        return new RedirectView(logoutUrl);
    }


    // @GetMapping("/is-active")
    // public ResponseEntity<Boolean> isSessionActive() {
    //     Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    //     boolean isActive = authentication != null && authentication.isAuthenticated();
    //     return ResponseEntity.ok(isActive);
    // }


    @Autowired
    private ISessionService sessionService;

    /**
     * Endpoint to check if the user session is active
     * @return Boolean indicating if the session is active
     */
    @GetMapping("/is-active")
    public ResponseEntity<Boolean> isSessionActive() {
        return ResponseEntity.ok(sessionService.isSessionActiveWithTimeout());
    }
    

}