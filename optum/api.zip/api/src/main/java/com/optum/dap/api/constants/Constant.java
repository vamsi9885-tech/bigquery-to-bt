package com.optum.dap.api.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Application-wide constants and enums.
 */
public class Constant {

    // Error message constants
    public static final String CLIENT_NOT_FOUND = "Client with ID %s not found";
    
    public enum FeedType {
        PULL("pull"),
        PUSH("push"),
        PULL_WITH_NTFS("pull_with_ntfs");

        private final String value;
        FeedType(String value) { this.value = value; }
        @JsonValue
        public String getValue() { return value; }
        @JsonCreator
        public static FeedType fromValue(String value) {
            for (FeedType type : values()) {
                if (type.value.equalsIgnoreCase(value)) {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown FeedType: " + value);
        }
    }

    public enum SplitBy {
        DAILY(1),
        WEEKLY(2),
        BI_WEEKLY(3),
        SEMI_MONTHLY(4),
        MONTHLY(5),
        YEARLY(6);

        private final int value;
        SplitBy(int value) { this.value = value; }
        @JsonValue
        public int getValue() { return value; }
        @JsonCreator
        public static SplitBy fromValue(int value) {
            for (SplitBy type : values()) {
                if (type.value == value) {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown SplitBy: " + value);
        }
    }


    public enum FeedStatus {
        ACTIVE("active"),
        PENDING("pending");

        private final String value;
        FeedStatus(String value) { this.value = value; }
        @JsonValue
        public String getValue() { return value; }
        @JsonCreator
        public static FeedStatus fromValue(String value) {
            for (FeedStatus status : values()) {
                if (status.value.equalsIgnoreCase(value)) {
                    return status;
                }
            }
            throw new IllegalArgumentException("Unknown FeedStatus: " + value);
        }
    }

    public enum ConnectionType {
        MSSQL("mssql"),
        NTFS("ntfs"),
        MYSQL("mysql"),
        ORACLE("oracle"),
        POSTGRESQL("postgresql");

        private final String value;
        ConnectionType(String value) { this.value = value; }
        @JsonValue
        public String getValue() { return value; }
        @JsonCreator
        public static ConnectionType fromValue(String value) {
            for (ConnectionType type : values()) {
                if (type.value.equalsIgnoreCase(value)) {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown ConnectionType: " + value);
        }
    }

    public enum FileTransferType {
        ECG_SFTP("ecg_sftp");

        private final String value;
        FileTransferType(String value) { this.value = value; }
        @JsonValue
        public String getValue() { return value; }
        @JsonCreator
        public static FileTransferType fromValue(String value) {
            for (FileTransferType type : values()) {
                if (type.value.equalsIgnoreCase(value)) {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown FileTransferType: " + value);
        }
    }

    public enum RowDelimiter {
        CRLF("\\r\\n"),
        LF("\\n"),
        CR("\\r");
    
        private final String value;
        RowDelimiter(String value) {
            this.value = value;
        }
        @JsonValue
        public String getValue() { return value; }
        @JsonCreator
        public static RowDelimiter fromValue(String value) {
            for (RowDelimiter delimiter : values()) {
                if (delimiter.value.equals(value)) {
                    return delimiter;
                }
            }
            throw new IllegalArgumentException("Unknown RowDelimiter: " + value);
        }
    }

    /**
     * Extraction type for feeds (periodic, historic, sample).
     */
    public enum ExtractionType {
        PERIODIC("periodic"),
        HISTORIC("historic"),
        SAMPLE("sample");

        private final String value;
        ExtractionType(String value) { this.value = value; }
        @JsonValue
        public String getValue() { return value; }
        @JsonCreator
        public static ExtractionType fromValue(String value) {
            for (ExtractionType type : values()) {
                if (type.value.equalsIgnoreCase(value)) {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown ExtractionType: " + value);
        }
    }

    /**
     * Notification type for feeds (standard, once_post_window, monthend).
     */
    public enum NotifyType {
        STANDARD("standard"),
        ONCE_POST_WINDOW("once_post_window"),
        ONCE_PER_CADENCE("once_per_cadence"),
        MONTHEND("monthend");

        private final String value;
        NotifyType(String value) { this.value = value; }
        @JsonValue
        public String getValue() { return value; }
        @JsonCreator
        public static NotifyType fromValue(String value) {
            for (NotifyType type : values()) {
                if (type.value.equalsIgnoreCase(value)) {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown NotifyType: " + value);
        }
    }

    public static final int CORRELATION_ID_FILTER = 1;
    public static final int JWT_AUTHENTICATION_FILTER = 2;
    public static final int REQUEST_CACHING_FILTER = 3;
    public static final int USERNAME_HEADER_FILTER = 4;
    public static final int REQUEST_LOGGING_FILTER = 5;
    public static final int SESSION_ATTRIBUTE_FILTER = 6;
    
    public enum AuditType {
        CLIENT_CREATE("Client_Creation"),
        CLIENT_UPDATE("Client_Updation"),
        FEED_CREATE("Feed_Creation"),
        FEED_UPDATE("Feed_Updation"),
        FILE_UPDATE("File_Updation"),
        FILE_CREATION("File_Creation"),
        FILE_DELETE("File_Deletion"),
        CONNECTORCONFIG_UPDATE("Connectorconfig_Updation"),
        RUNTIMESETTINGS_UPDATE("RunTimeSettings_Updation");

        private final String value;
        AuditType(String value) { this.value = value; }
        @JsonValue
        public String getValue() { return value; }
        @JsonCreator
        public static AuditType fromValue(String value) {
            for (AuditType type : values()) {
                if (type.value.equalsIgnoreCase(value)) {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown AuditType: " + value);
        }
    }
}
