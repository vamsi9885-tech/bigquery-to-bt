package com.optum.dap.api.model;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FileConfig {
    @JsonProperty("file_id")
    private String fileId;

    @JsonProperty("order")
    private Integer order;

    @JsonProperty("file_name_format")
    private String fileNameFormat;

    @JsonProperty("part_count")
    private Integer partCount;

    @JsonProperty("part_start_seq")
    private Integer partStartSeq;
    
    @JsonProperty("filter")
    private String filter;

    @JsonProperty("is_mandatory")
    private Boolean isMandatory;

    @JsonProperty("parameters")
    private List<Parameters> parameters;
}

