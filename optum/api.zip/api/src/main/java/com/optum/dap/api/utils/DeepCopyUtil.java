package com.optum.dap.api.utils;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;

@Service
@Slf4j
public class DeepCopyUtil {
    @Autowired
    private ObjectMapper objectMapper;

    public <T> T deepCopy(T object, Class<T> clazz) {
        try {
            return objectMapper.readValue(objectMapper.writeValueAsBytes(object), clazz);
        } catch (Exception e) {
            log.error("Error during deep copy: {}", e.getMessage(), e);
            return null;
        }
    }
}
