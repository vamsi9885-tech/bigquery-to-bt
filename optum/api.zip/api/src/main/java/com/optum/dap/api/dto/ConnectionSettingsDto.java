package com.optum.dap.api.dto;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.optum.dap.api.constants.Constant.ConnectionType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;

/**
 * DTO for connection settings in feed config.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConnectionSettingsDto {

    private ConnectionType type;

    private String connectionString;

    private String ntfsFolderPath;

}