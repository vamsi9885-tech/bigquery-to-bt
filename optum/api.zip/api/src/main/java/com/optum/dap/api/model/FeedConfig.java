package com.optum.dap.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * POJO representing the feed_config JSON structure stored in Feeds.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeedConfig {
    @JsonProperty("extraction_settings")
    private ExtractionSettings extractionSettings;
    
    @JsonProperty("connection_settings")
    private ConnectionSettings connectionSettings;

    @JsonProperty("file_transfer_settings")
    private FileTransferSettings fileTransferSettings;
}