package com.optum.dap.api.dto;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.Valid;
import lombok.Data;


/**
 * DTO for client details response including config and feeds.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientsResponseDto {
    private String clientId;
    private String clientName;
    private boolean isActive;
    @JsonProperty("isActive")
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }


    @Valid
    private ClientConfigDto clientConfig;
    private List<ClientFeedDto> feeds;
}