package com.optum.dap.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CronSettings {
    
   @JsonProperty("time_of_day")
    private String timeOfDay;

    @JsonProperty("day_of_week")
    private String dayOfWeek;

    @JsonProperty("day_of_month")
    private String dayOfMonth;

    @JsonProperty("month_of_year")
    private String monthOfYear;

}
