package com.optum.dap.api.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import com.optum.dap.api.constants.Constant.FileTransferType;

@Data
public class FileTransferSettingsDto {
    @NotNull(message = "Type must not be null")
    private FileTransferType type;

    @Valid
    private FileTransferSettingsDetailDto settings;
}