INSERT INTO feed_frequency (frequency_id, frequency_type, feed_window_dates, supported_feed_type) VALUES
(7, 'quarterly', 90, 'All'),
(8, 'halfyearly', 180, 'All');
