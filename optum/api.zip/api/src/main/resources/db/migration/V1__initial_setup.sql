-- -- V1__initial_setup.sql


-- -- -- Create tables
CREATE TABLE IF NOT EXISTS clients (
   client_id varchar(255) PRIMARY KEY,
   client_name varchar(255) NOT NULL,
   is_active boolean NOT NULL DEFAULT true,
   client_config JSONB,
   modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
   created_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
   created_by varchar(255) NOT NULL,
   modified_by varchar(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS feed_frequency (
    frequency_id SERIAL PRIMARY KEY,
    frequency_type VARCHAR(255) NOT NULL,
    feed_window_dates INT,
    supported_feed_type VARCHAR(255)
);

INSERT INTO feed_frequency (frequency_id, frequency_type, feed_window_dates, supported_feed_type) VALUES
(1, 'daily', 1, 'All'),
(2, 'weekly', 7, 'All'),
(3, 'biweekly', 14, 'All'),
(4, 'semimonthly', 15, 'All'),
(5, 'monthly', 28, 'All'),
(6, 'yearly', 365, 'All');

CREATE TABLE IF NOT EXISTS feeds (
    feed_identifier UUID NOT NULL UNIQUE,
    feed_name VARCHAR(255) NOT NULL,
    feed_status VARCHAR(255) NOT NULL,
    feed_type VARCHAR(255) NOT NULL,
    feed_config JSONB,
    is_active BOOLEAN NOT NULL,
    client_id VARCHAR(255) NOT NULL,
    frequency_id INT NOT NULL,
    modified_by VARCHAR(255) NOT NULL,
    modified_date TIMESTAMP NOT NULL,
    created_by VARCHAR(255) NOT NULL,
    created_date TIMESTAMP NOT NULL,
    PRIMARY KEY (feed_identifier),
    FOREIGN KEY (client_id) REFERENCES clients(client_id),
    FOREIGN KEY (frequency_id) REFERENCES feed_frequency(frequency_id)
);

CREATE TABLE IF NOT EXISTS connector_config (
    connector_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connector_type VARCHAR(255) NOT NULL,
    emr_version VARCHAR(255) NOT NULL,
    spec_name VARCHAR(255),
    spec_version VARCHAR(255),
    feed_identifier UUID UNIQUE,
    FOREIGN KEY (feed_identifier) REFERENCES feeds(feed_identifier)
);

CREATE TABLE IF NOT EXISTS files (
    feed_identifier UUID NOT NULL,
    logical_file_name VARCHAR(255) NOT NULL,
    file_config JSONB, -- contains fileId, order, fileNameFormat, parameters, filters, isMandatory, partCount
    is_active BOOLEAN NOT NULL,
    modified_by VARCHAR(255) NOT NULL,
    modified_date TIMESTAMP NOT NULL,
    created_by VARCHAR(255) NOT NULL,
    created_date TIMESTAMP NOT NULL,
    PRIMARY KEY (feed_identifier, logical_file_name),
    FOREIGN KEY (feed_identifier) REFERENCES feeds (feed_identifier)
);

CREATE TABLE IF NOT EXISTS run_time_settings (
    run_time_config_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    feed_identifier UUID NOT NULL,
    is_adhoc_run VARCHAR(255) NOT NULL,
    extraction_type VARCHAR(255),
    split_by INT,
    adhoc_start_date DATE,
    adhoc_end_date DATE,
    periodic_start_date DATE,
    lag_offset INTEGER,
    lag_tolerance INTEGER,
    notify_type VARCHAR(255),
    enable_run_status_notification boolean NOT NULL DEFAULT true,
    run_time_setting_config JSONB,
    FOREIGN KEY (feed_identifier) REFERENCES feeds (feed_identifier),
    FOREIGN KEY (split_by) REFERENCES feed_frequency (frequency_id),
    modified_by VARCHAR(255) NOT NULL,
    modified_date TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    audit_id UUID NOT NULL PRIMARY KEY DEFAULT gen_random_uuid(),
    audit_type VARCHAR(255) NOT NULL,
    action_by VARCHAR(255) NOT NULL,
    action_on  TIMESTAMP NOT NULL,
    entity_name VARCHAR(255) NOT NULL,
    old_value JSONB,
    new_value JSONB,
    client_id VARCHAR(255) NOT NULL,
    feed_identifier UUID
);