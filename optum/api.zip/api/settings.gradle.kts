rootProject.name = "api"

pluginManagement {
    repositories {
        gradlePluginPortal() // For plugins from the Gradle Plugin Portal
        mavenCentral()      // For plugins from Maven Central
        maven(url = "https://centraluhg.jfrog.io/artifactory/glb-gradle-vir/")
        maven(url = "https://centraluhg.jfrog.io/artifactory/glb-gradle-vir/")
        maven(url = "https://centraluhg.jfrog.io/artifactory/glb-gradle-plugins-rem/")
    }
}
