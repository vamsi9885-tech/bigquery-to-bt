# Follow the below steps to run the codeql scan.
# Open https://appsec.optum.com/secure-coding/codeql-local-setup.
# Follow step 1 in the repository location.
# Follow step 2 if codeql is not installed in your machine.
# For step 3 & 4, run this script from current folder path to create database and analyze the code.
sudo rm -r outputs
mkdir outputs
codeql database create ./outputs/apiCodeQlDb --overwrite --language=java --source-root ../../../api
codeql database analyze ./outputs/apiCodeQlDb ../../../../codeql-main/java/ql/src/codeql-suites/java-security-extended.qls --format=sarif-latest --output=./outputs/codeqlAnalysis_security-extended.sarif --ram=16000 --max-disk-cache=100000 --threads=0 --no-rerun
