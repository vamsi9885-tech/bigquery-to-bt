plugins {
	java
	jacoco
	id("org.springframework.boot") version "3.5.3"
	id("io.spring.dependency-management") version "1.1.7"
	id("maven-publish")
}

group = "com.optum.dap"
version = "1.0.4"

// Set the base name for the artifact
val artifactBaseName = "dap-api"

// Disable the plain JAR task so only the bootJar is produced
tasks.jar {
	enabled = false
    archiveBaseName.set(artifactBaseName)
    archiveVersion.set(version.toString())
    archiveClassifier.set("") 
}

// Configure the Spring Boot executable JAR task
tasks.bootJar {
    archiveBaseName.set(artifactBaseName)
    archiveVersion.set(version.toString())
    archiveClassifier.set("") 
}

java {
	toolchain {
		languageVersion = JavaLanguageVersion.of(21)
	}
}

repositories {
 mavenCentral()
    maven {
        url = uri("https://centraluhg.jfrog.io/artifactory/dap-maven-vir/")
    }
    mavenLocal()
    flatDir {
        dirs("libs")
    }
}

dependencies {
	// Spring dependencies
	implementation("org.springframework.boot:spring-boot-starter-web")
	implementation("org.apache.tomcat.embed:tomcat-embed-core:11.0.8")
	implementation("org.springframework.boot:spring-boot-starter-logging")
	implementation("jakarta.persistence:jakarta.persistence-api")
	implementation("org.springframework.boot:spring-boot-starter-security")
        implementation("org.springframework.security:spring-security-oauth2-resource-server")
	implementation("org.springframework.security:spring-security-oauth2-jose")
	implementation("org.springframework.security:spring-security-oauth2-core")
	implementation("org.springframework.security:spring-security-oauth2-client")
	implementation("org.springframework.boot:spring-boot-starter-validation")
	implementation("org.springframework.boot:spring-boot-starter-thymeleaf:3.5.0")
	implementation("org.springframework.session:spring-session-jdbc")
	implementation("com.auth0:java-jwt:4.4.0")
	implementation("com.auth0:jwks-rsa:0.22.1")

	// Lombok dependencies
	compileOnly("org.projectlombok:lombok")
	annotationProcessor("org.projectlombok:lombok")
	testCompileOnly("org.projectlombok:lombok")
	testAnnotationProcessor("org.projectlombok:lombok")
	// Database dependencies
	runtimeOnly("org.postgresql:postgresql")
	implementation("org.springframework.boot:spring-boot-starter-jdbc")
	implementation("org.springframework.boot:spring-boot-starter-data-jpa")
	testImplementation("com.h2database:h2")
	implementation("org.postgresql:postgresql:42.7.3")
	// Flyway dependencies
	implementation("org.flywaydb:flyway-core:11.3.2")
	implementation("org.flywaydb:flyway-database-postgresql:11.3.2")
	// Logback dependencies
	implementation("net.logstash.logback:logstash-logback-encoder:7.4") 

	testImplementation("ch.qos.logback:logback-classic:1.5.16")
	testImplementation("ch.qos.logback:logback-core:1.5.16")
	// Swagger dependencies
	implementation("org.springdoc:springdoc-openapi-starter-webmvc-ui:2.8.8")
	testImplementation("org.springframework.security:spring-security-test")
	// Test dependencies

testImplementation("org.springframework.boot:spring-boot-starter-test"){
		exclude(module="junit")
	}
	testImplementation("org.junit.jupiter:junit-jupiter-api")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")
	// Servlet API dependency
	implementation("jakarta.servlet:jakarta.servlet-api:6.0.0")
	implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.15.2")

}

tasks.test {
    finalizedBy(tasks.jacocoTestReport) // report is always generated after tests run
}

tasks.withType<Test> {
	useJUnitPlatform()
}

tasks.jacocoTestReport {
    dependsOn(tasks.test) // tests are required to run before generating the report
	reports {
        xml.required = true
    }
}

publishing {
    publications {
        create<MavenPublication>("mavenJava") {
            artifact(tasks.bootJar.get()) {
                classifier = ""
            }
            groupId = project.group.toString()
            artifactId = artifactBaseName
            version = project.version.toString()
        }
    }
    repositories {
        maven {
            url = if (version.toString().endsWith("SNAPSHOT")) {
                uri("https://centraluhg.jfrog.io/artifactory/dap-maven-snapshots-vir")
            } else {
                uri("https://centraluhg.jfrog.io/artifactory/dap-maven-releases-vir")
            }
            credentials {
                username = "token"
                password = System.getenv("JF_ARTIFACTORY_ACCESS_TOKEN")
            }
        }
    }
}
