# Hub Table: hub_pimsctp_accident

## Table Purpose
The `hub_pimsctp_accident` table serves as a centralized repository for accident information related to Compulsory Third Party (CTP) insurance claims. It consolidates accident data from the PIMS system, including location details, timing information, and accident circumstances. This hub table supports downstream analytics, reporting, and operational processes by providing a single source of truth for accident-related information in CTP claims.

## Source Data
This table sources data from the following PIMS tables in `d_gi_lak_pims` database:

1. **dl_CTPAccident** - Primary accident details, dates and identifiers
2. **dl_CARAccidentCircumstance** - Circumstances surrounding the accident
3. **dl_CARAccidentProfile** - Accident profile descriptions
4. **dl_TIMAddress** - Location information for accidents
5. **dl_TIMSuburb**, **dl_TIMState**, **dl_TIMCountry** - Geographic hierarchy for location
6. **dl_CONAddressStreetType** - Street type information for addresses
7. **dl_TIMPolicyClaim** - Link to relevant policy claims
8. **dl_TIMContactTypeInsurer** - Insurer information

### Source to Target Relationships
The tables are joined using object instance and class number pairs (`instid`/`clsno`) following the PIMS object model. Key relationships include:

- `dl_TIMPolicyClaim` to `dl_CTPAccident` using `myAccident_instid` and `myAccident_clsno`
- `dl_CTPAccident` to `dl_CARAccidentProfile` using `myAccidentProfile_instid` and `myAccidentProfile_clsno`
- `dl_CTPAccident` to `dl_CARAccidentCircumstance` using `myAccidentCircumstance_instid` and `myAccidentCircumstance_clsno`
- `dl_CTPAccident` to `dl_TIMAddress` using `myAccidentLocation_instid` and `myAccidentLocation_clsno`
- `dl_TIMAddress` to geographic tables (`dl_TIMSuburb`, `dl_TIMState`, `dl_TIMCountry`) and to `dl_CONAddressStreetType`

## Schema Details

| Column Name | Data Type | Description | Source |
|-------------|-----------|-------------|--------|
| `acc_profile` | STRING | Description from accident profile | dl_CARAccidentProfile.aDescription |
| `acc_circum` | STRING | Description of accident circumstances | dl_CARAccidentCircumstance.aDescription |
| `acc_no` | STRING | Unique accident identifier | dl_CTPAccident.aUniqueID |
| `acc_ads_involv` | STRING | ADS involvement flag (Unknown/Yes/No) | dl_CTPAccident.aADSInvolved with code conversion |
| `acc_blameless_flg` | STRING | Flag indicating if accident was blameless | dl_CTPAccident.aIsBlameless |
| `acc_coord` | DECIMAL(18,6) | Geographical coordinates of accident | dl_CTPAccident.aCoordinates |
| `acc_created_ts` | STRING | Timestamp when record was created | dl_CTPAccident._timestamp where _operation = 'C' |
| `acc_entrd_dt` | STRING | Date when accident was entered | Date part of dl_CTPAccident._timestamp |
| `acc_dt` | STRING | Date of accident | Date part of dl_CTPAccident.aDateTimeOfAccident |
| `acc_yr` | STRING | Year of accident | Year extracted from dl_CTPAccident.aDateTimeOfAccident |
| `acc_yr_grp_fnl_tgt` | STRING | Year group for finalization targets | Derived from acc_yr |
| `acc_rcvd_dt` | STRING | Date notification was received | dl_CTPAccident.aDateTimeNotified |
| `acc_rptd_police_dt` | STRING | Date reported to police | dl_CTPAccident.aPoliceDateReported |
| `acc_loc` | STRING | Full accident location address | Concatenated from address components |
| `acc_police_rpt_unavail` | STRING | Police report availability | Based on dl_CTPAccident.aPoliceReportAvailable |
| `acc_police_attnd_scene` | STRING | Police attendance flag | dl_CTPAccident.aPoliceAttend with code conversion |
| `acc_postcd` | INTEGER | Accident location postcode | dl_TIMAddress.aPostCode |
| `acc_state` | STRING | Accident location state | dl_TIMState.aName |
| `acc_st_nm` | STRING | Street name | dl_TIMAddress.aStreetName |
| `acc_st_nm_type` | STRING | Concatenated street name and type | Concatenated from components |
| `acc_st_type_cd` | STRING | Street type code | dl_ConAddressStreetType.aCode |
| `acc_suburb` | STRING | Suburb name | dl_TIMSuburb.aName |
| `acc_tmtime` | STRING | Time of accident (HH:MM) | Time part of dl_CTPAccident.aDateTimeOfAccident |
| `acc_police_rpt_no` | STRING | Police report number | dl_CTPAccident.aEventNumber |
| `acc_null_flg` | STRING | Null flag indicator | To be confirmed in implementation |
| `acc_nulled_dt` | STRING | Date of nullification | To be confirmed in implementation |
| `acc_nulled_rs` | STRING | Reason for nullification | To be confirmed in implementation |
| `acc_mnging_insur_cd` | STRING | Managing insurer code | To be confirmed in implementation |
| `rec_sha` | STRING | 256 Byte Hash key for change tracking | Generated from record values |
| `active_dt` | STRING | Active date in YYYY-MM-DD format | Current processing date |
| `active_ym` | STRING | Active year-month | Derived from active_dt |
| `record_version_no` | BIGINT | Version number of the record | Generated incrementally |
| `load_dt` | STRING | Load date in YYYY-MM-DD format | Current processing date |
| `source_system_cd` | STRING | Source system code | Fixed as "PIMS" |

## Business Rules

### Address Filtering
Only address records with `aType = 100` (indicating an Accident location) are included in the join.

### Code Conversions
1. **ADS Involvement (acc_ads_involv)**:
   - 0 = "Unknown"
   - 1 = "Yes"
   - 2 = "No"

2. **Police Attendance (acc_police_attnd_scene)**:
   - 0 = "Unknown"
   - 1 = "Yes"
   - 2 = "No"

3. **Police Report Availability (acc_police_rpt_unavail)**:
   - false = "report unavailable"
   - true = "report available"

### Year Grouping for Finalization Targets
The field `acc_yr_grp_fnl_tgt` is calculated as follows:
- "Last 3 Years" = Accident year is within current year or two prior calendar years
- "Tail Accident Years" = All other claims (accident year older than last 3 years)

This grouping is used for monitoring performance against finalization targets.

### Record Versioning
Records are versioned based on accident date (`acc_dt`) and received date (`acc_rcvd_dt`), with the most recent records retained.

### Police Report Number Notes
The field `acc_police_rpt_no` is known by different names in different states:
- QLD: "TIN/QPRIME Number"
- NSW: "Event Number" 
- SA: "VCR Number"

## Dependencies
This table depends on the following tables and data sources:
- All source tables in the `d_gi_lak_pims` database listed in the Source Data section.
- No direct dependencies on other hub or mart tables.

## Update Frequency
This table is refreshed on a daily basis.

## Example Usage

### Retrieving Accident Details for a Specific Claim
```sql
SELECT a.*
FROM d_gi_hub_ctp.hub_pimsctp_accident a
JOIN d_gi_hub_ctp.hub_pimsctp_claim c ON a.acc_no = c.related_acc_no
WHERE c.claim_no = '123456789'
```

### Finding All Accidents in a Specific Year Group
```sql
SELECT acc_no, acc_dt, acc_loc, acc_police_rpt_no
FROM d_gi_hub_ctp.hub_pimsctp_accident
WHERE acc_yr_grp_fnl_tgt = 'Last 3 Years'
AND acc_dt >= '2024-01-01'
AND acc_state = 'NSW'
```

### Analyzing Accidents by State and ADS Involvement
```sql
SELECT acc_state, acc_ads_involv, COUNT(*) as accident_count
FROM d_gi_hub_ctp.hub_pimsctp_accident
WHERE active_dt = '2025-06-16'  -- Latest active date
GROUP BY acc_state, acc_ads_involv
ORDER BY acc_state, accident_count DESC
```

### Finding Accidents with Missing Information
```sql
SELECT acc_no, acc_dt, acc_loc
FROM d_gi_hub_ctp.hub_pimsctp_accident
WHERE acc_profile IS NULL
OR acc_circum IS NULL
OR acc_police_rpt_no IS NULL
```
