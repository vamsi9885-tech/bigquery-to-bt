#!/bin/python
#####################################################
# File Name: hub_pimsctp_accident.py
# Type: Pyspark
# Purpose: This script will transform PIMS CTP Accident data into hub_pimsctp_accident table.
# Created: 16/06/2025
# Last Updated: 16/06/2025
# Author: Data Engineering Team
#####################################################

import sys
sys.dont_write_bytecode = True

from src.utils.df_utils import *
import pyspark.sql.functions as sf
from pyspark.sql.types import DecimalType, StringType, DateType
from src.run.custom_logging import *


def hub_pimsctp_accident(spark, props, app_logger):
    """
    Transform PIMS CTP Accident data into hub_pimsctp_accident table.

    Args:
        spark: Spark session object
        props: Properties dictionary containing configuration
        app_logger: Logger object for application logging    Returns:
        DataFrame: Transformed accident data
    """
    try:
        app_logger.info(__name__, "Starting transformation for hub_pimsctp_accident")
        # Not using target_table variable since we use target_tbl directly
        # Load required source tables using selective_df
        app_logger.info(__name__, "Loading source tables")
        
        source_db = props.get("SOURCE_DB")
        target_db = props.get("TARGET_DB")
        target_tbl = props.get("TARGET_TBL")
        
        # Get source table names from config
        policy_claim_df = selective_df(spark, f"{source_db}.{props.get('SOURCE_TBL_POLICY_CLAIM')}", "ALL")
        accident_df = selective_df(spark, f"{source_db}.{props.get('SOURCE_TBL_CTP_ACCIDENT')}", "ALL")
        accident_profile_df = selective_df(spark, f"{source_db}.{props.get('SOURCE_TBL_ACCIDENT_PROFILE')}", "ALL")
        accident_circum_df = selective_df(spark, f"{source_db}.{props.get('SOURCE_TBL_ACCIDENT_CIRCUMSTANCE')}", "ALL")
        address_df = selective_df(spark, f"{source_db}.{props.get('SOURCE_TBL_ADDRESS')}", "ALL")
        suburb_df = selective_df(spark, f"{source_db}.{props.get('SOURCE_TBL_SUBURB')}", "ALL")
        state_df = selective_df(spark, f"{source_db}.{props.get('SOURCE_TBL_STATE')}", "ALL")
        country_df = selective_df(spark, f"{source_db}.{props.get('SOURCE_TBL_COUNTRY')}", "ALL")
        street_type_df = selective_df(spark, f"{source_db}.{props.get('SOURCE_TBL_STREET_TYPE')}", "ALL")

        app_logger.info(__name__, "Loaded all source tables successfully")

        # Join all tables according to the relationships defined in the dictionary
        df = (policy_claim_df
             .join(accident_df,
                   (policy_claim_df.myAccident_instid == accident_df.oid_instid) &
                   (policy_claim_df.myAccident_clsno == accident_df.oid_clsno),
                   "left")
             .join(accident_profile_df,
                   (accident_df.myAccidentProfile_instid == accident_profile_df.oid_instid) &
                   (accident_df.myAccidentProfile_clsno == accident_profile_df.oid_clsno),
                   "left")
             .join(accident_circum_df,
                   (accident_df.myAccidentCircumstance_instid == accident_circum_df.oid_instid) &
                   (accident_df.myAccidentCircumstance_clsno == accident_circum_df.oid_clsno),
                   "left")
             .join(address_df,
                   (accident_df.myAccidentLocation_instid == address_df.oid_instid) &
                   (accident_df.myAccidentLocation_clsno == address_df.oid_clsno),
                   "left")
             .join(suburb_df,
                   (address_df.mySuburb_instid == suburb_df.oid_instid) &
                   (address_df.mySuburb_clsno == suburb_df.oid_clsno),
                   "left")
             .join(state_df,
                   (address_df.myState_instid == state_df.oid_instid) &
                   (address_df.myState_clsno == state_df.oid_clsno),
                   "left")
             .join(country_df,
                   (state_df.myCountry_instid == country_df.oid_instid) &
                   (state_df.myCountry_clsno == country_df.oid_clsno),
                   "left")
             .join(street_type_df,
                   (address_df.myStreetType_instid == street_type_df.oid_instid) &
                   (address_df.myStreetType_clsno == street_type_df.oid_clsno),
                   "left"))

        app_logger.info(__name__, "Completed table joins successfully")

        # Apply address type filter
        df = df.filter(address_df.aType == 100)  # Filter for accident location addresses

        # Apply transformations as per dictionary definitions
        result_df = df.select(
            accident_profile_df.aDescription.alias('acc_profile'),
            accident_circum_df.aDescription.alias('acc_circum'),
            accident_df.aUniqueID.alias('acc_no'),
            sf.when(accident_df.aADSInvolved == 0, 'Unknown')
              .when(accident_df.aADSInvolved == 1, 'Yes')
              .when(accident_df.aADSInvolved == 2, 'No')
              .alias('acc_ads_involv'),
            accident_df.aIsBlameless.alias('acc_blameless_flg'),
            accident_df.aCoordinates.cast(DecimalType(18,6)).alias('acc_coord'),
            sf.when(accident_df._operation == 'C', accident_df._timestamp).alias('acc_created_ts'),
            sf.to_date(sf.when(accident_df._operation == 'C', accident_df._timestamp)).alias('acc_entrd_dt'),
            sf.to_date(accident_df.aDateTimeOfAccident).alias('acc_dt'),
            sf.year(accident_df.aDateTimeOfAccident).alias('acc_yr'),
            sf.when(sf.year(accident_df.aDateTimeOfAccident) >= sf.year(sf.current_date()) - 2, 'Last 3 Years')
              .otherwise('Tail Accident Years')
              .alias('acc_yr_grp_fnl_tgt'),
            accident_df.aDateTimeNotified.alias('acc_rcvd_dt'),
            accident_df.aPoliceDateReported.alias('acc_rptd_police_dt'),
            sf.concat_ws(' ',
                        address_df.aUnitNumber,
                        address_df.aPropertyName,
                        address_df.aLevel,
                        address_df.aStreetNumber,
                        address_df.aStreetName,
                        suburb_df.aName,
                        state_df.aName,
                        country_df.aName,
                        address_df.aPostCode
                       ).alias('acc_loc'),
            sf.when(accident_df.aPoliceReportAvailable == False, 'report unavailable')
              .when(accident_df.aPoliceReportAvailable == True, 'report available')
              .alias('acc_police_rpt_unavail'),
            sf.when(accident_df.aPoliceAttend == 0, 'Unknown')
              .when(accident_df.aPoliceAttend == 1, 'Yes')
              .when(accident_df.aPoliceAttend == 2, 'No')
              .alias('acc_police_attnd_scene'),
            address_df.aPostCode.alias('acc_postcd'),
            state_df.aName.alias('acc_state'),
            address_df.aStreetName.alias('acc_st_nm'),
            sf.concat_ws(' ', address_df.aStreetName, street_type_df.aName).alias('acc_st_nm_type'),
            street_type_df.aCode.alias('acc_st_type_cd'),
            suburb_df.aName.alias('acc_suburb'),
            sf.date_format(accident_df.aDateTimeOfAccident, 'HH:mm').alias('acc_tmtime'),
            accident_df.aEventNumber.alias('acc_police_rpt_no'),
            sf.lit('PIMS').alias('source_system_cd')
        )        # Standard column name conversion to lowercase
        for col_name in result_df.columns:
            if col_name != col_name.lower():
                result_df = result_df.withColumnRenamed(col_name, col_name.lower())
                
        # Handle blank values as NULL
        columns_to_check = [col for col in result_df.columns]
        result_df = blank_as_null(result_df, columns_to_check)
        
        # Add created_at timestamp for row versioning
        result_df = result_df.withColumn('created_at', sf.current_timestamp())
        
        # Get latest records using deduplication
        result_df = get_latest_row(
            result_df,
            partition_keys=['acc_no'],
            order_keys='created_at'
        )        # Add active_dt column first (required for add_audit_columns)
        result_df = result_df.withColumn('active_dt', sf.current_date())
          # Add standard audit columns for hub table
        source_system = props.get("SOURCE_SYSTEM")
        result_df = add_audit_columns(
            result_df,
            source_system,
            excluded_columns=['record_version_no', 'load_dt', 'active_ym'],
            source_dt_format='yyyy-MM-dd'
        )
        # Note: No need to explicitly create SHA field as it's already handled by the add_audit_columns function
        app_logger.info(__name__, f"Created {result_df.count()} records for hub_pimsctp_accident table")
        app_logger.info(__name__, "Completed all transformations successfully")
        
        # Save data to Hive table        app_logger.info(__name__, f"Saving data to {target_db}.{target_tbl}")
        save_hive(spark=spark, 
                 df=result_df, 
                 columns_obj=props, 
                 hive_db_name=target_db,
                 hive_table_name=target_tbl, 
                 app_logger=app_logger, 
                 mode="append_partition",
                 partition_column="source,active_ym")
        
        app_logger.info(__name__, f"Successfully completed hub_pimsctp_accident processing")
        return result_df

    except Exception as e:
        app_logger.error(__name__, f"Error in hub_pimsctp_accident: {str(e)}")
        app_logger.error(__name__, "Oops!", sys.exc_info()[0], "occurred.")
        sys.exit(1)
