
# DAP Regression Automation

## Repository Structure

```
.github/
└── workflows/                # CI/CD workflows for regression automation

config/
└── test_config.json          # Central config file to register test cases

regression/
└── test_cases/
    └── <test_id>/
        ├── input_files/      # Input test files for the test case
        └── sql_files/        # SQL files for post-run validations
```

---

## Overview

`dap_regression_automation` is a flexible and extensible repository designed to support automated regression testing in the DAP project. It simplifies the execution, management, and validation of test cases using a standardized, repeatable framework. Currently, this covers only the PUSH Regression Suite for DAP. 

---

## Adding a New Test Case

### 1. Create a Feature Branch

Start by creating a feature branch from `main`:

---

### 2. Add a Test Case Folder

Navigate to the `regression/test_cases/` directory and create a new subdirectory for your test case:

```
regression/test_cases/
└── <test_id>/
    ├── input_files/
    │   └── <input_file>.txt
    └── sql_files/
        ├── <validation_sql>.sql
        └── <error_check_sql>.sql
```

- `input_files/`: Contains the raw files to be used during testing  
- `sql_files/`: Contains SQL scripts used for output validation and error checks  

---

### 3. Register the Test Case in `test_config.json`

In the `config/` directory, update the `test_config.json` file by adding a new entry for your test case. Use the following template:

```json
{
  "ID": "<unique_id>",
  "Rally_Number": "<optional_jira_or_rally_ticket>",
  "TestID": "<unique_test_identifier>",
  "Test_Name": "<brief_test_name>",
  "Test_Case_Description": "<detailed_description_of_the_test>",
  "PostTest_SQL": "<test_id>/sql_files/<validation_sql>.sql",
  "ErrorSQL": "<test_id>/sql_files/<error_check_sql>.sql",
  "Test_File_Names": "<expected_file_name.txt>",
  "IsActive": "true",
  "Test_Tags": ["<tag1>", "<tag2>"],
  "Client": "<client_or_project_name>",
  "Feed_Name": "<feed_name_to_be_validated>",
  "Target_PB_Folder": "/mnt/data/{env}/bronze/<feed_name>/polishedbronze/periodic/current/<date>/<entity>/",
  "Test_Group": "<logical_grouping_name>"
}
```

> 📌 Ensure paths, file names, and field values align with the test case design and naming conventions.

---

### 4. Implement Validation Logic

Update the `Regression_Validation` notebook or validation script with the logic to handle the new test case:

- Load and execute SQL files referenced in `test_config.json`  
- Perform data validation: row counts for source and target file
- Log the result (pass/fail) for reporting and audit  

---

## Final Checklist

- [ ] Feature branch created from `main`
- [ ] Folder structure created under `regression/test_cases/<test_id>/`
- [ ] Input and SQL files added appropriately
- [ ] Entry registered in `test_config.json` with valid metadata and paths
- [ ] Validation logic implemented in the `Regression_Validation` notebook
- [ ] Test run verified locally and code pushed for review

---

## Best Practices

- Maintain consistent naming conventions for files, folders, and identifiers  
- Validate SQL scripts manually before integrating  
- Use clear, descriptive `TestID` and `Test_Name` values  
- Activate the test case only after full verification (`IsActive: true`) 

---


# How to Trigger the `RegressionTrigger` Workflow (Clean Execution Guide)

This guide provides detailed steps to trigger the `RegressionTrigger` GitHub Actions workflow cleanly for manual executions.

---

## ✅ 1. Manual Trigger (Using GitHub UI)

**Steps:**
1. Navigate to your repository on GitHub.
2. Click on the **"Actions"** tab.
3. Select the `RegressionTrigger` workflow.
4. Click on the **"Run workflow"** dropdown.
5. Choose the desired branch (e.g., `main`, `feature/*`).
6. Fill out any required inputs (e.g., `client`, `env`, `specfile`).
7. Click **"Run workflow"**.

**Best Practices:**
- Ensure no conflicting workflow is currently running.
- Check logs of `conditional-run` to confirm workflow is permitted.

---

## 🧼 Clean Execution Checklist

| Step | Description |
|------|-------------|
| ✅ execute_delete_queries | Cleans up DB tables from previous test runs. |
| ✅ Prerequisites-for-Build | Removes old folders and prepares fresh directories. |
| ✅ call-build-workflow | Triggers Build workflow to ensure latest code. |
| ✅ upload_files | Uploads latest input files to ADLS. |
| ✅ sleep-job | Waits for 60 minutes (ensures system readiness). |
| ✅ databricks-notebook | Executes test notebook and generates regression report. |

---

## 📌 Tips
- Always monitor workflow logs for errors or skipped steps.
- Avoid triggering multiple workflows in parallel for the same `client` and `env`.

