SELECT 
   CASE WHEN COUNT(*) = 3 THEN 1 ELSE 0 END AS success_flag 
FROM 
  file_arrival_status fas 
  JOIN file_master fm 
  ON fm.cadence_id = fas.cadence_id 
  AND fm.feed_id = fas.feed_id 
WHERE 
    (fas.file_name = 'TC055_appointments_20250309_part_03.txt' AND fas.part = '3')
    OR (fas.file_name = 'TC055_appointments_20250309_part_04.txt' AND fas.part = '4')
    OR (fas.file_name = 'TC055_appointments_20250309_part_05.txt' AND fas.part = '5')
    AND fas.feed_name = 'centura_monthly_autotest' 
    AND fas.client_name = 'regressionv1' 
    AND fas.logical_file_name = 'appointments' 
    AND fm.arrived_flag = 'true'
    AND is_type_casting_success = 'true'
    AND processed_row_count = source_row_count