SELECT 
    CASE WHEN COUNT(*) = 1 THEN 1 ELSE 0 END AS success_flag 
FROM  
    file_master fm 
JOIN 
    feed_master fem 
    ON fm.feed_id = fem.feed_id
join cadence_master cm on 
    cm.cadence_id = fm.cadence_id
where fem.landed_file_name = 'TC031_devices_20240910_part_001.dat' 
and fm.file_name = 'TC031_devices_20240910_part_001.dat'
 and replace(concat(fm.adhoc_start_date,'_',fm.adhoc_end_date),'-','') = cm.output_folder_name
 and source_row_count = processed_row_count
 and failed_row_count = 0
 and is_type_casting_success = true