SELECT 
    fm.error_message 
FROM  
    file_master fm 
JOIN 
    feed_master fem 
    ON fm.feed_id = fem.feed_id
where fem.landed_file_name = 'TC031_devices_20240910_part_001.dat' 
and fm.file_name = 'TC031_devices_20240910_part_001.dat'
 