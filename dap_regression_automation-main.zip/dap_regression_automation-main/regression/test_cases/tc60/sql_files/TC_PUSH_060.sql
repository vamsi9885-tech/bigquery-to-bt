WITH DateDiffValidation AS (
    -- Query 1: Validates the 14-day difference(Biweekly) for the first 10 records.
    -- Returns a single row with 'is_valid' = 1 or 0.
    SELECT
        CASE
            WHEN COUNT(CASE WHEN (window_start_date - prev_date) != 14 THEN 1 END) > 0 THEN 0
            ELSE 1
        END AS is_valid
    FROM (
        SELECT
            window_start_date,
            LAG(window_start_date, 1) OVER (ORDER BY window_start_date ASC) AS prev_date
        FROM
            file_arrival_status
        WHERE
            feed_name = 'centura_daily_autotestv6' AND logical_file_name = 'claims'
        ORDER BY
            window_start_date ASC
        LIMIT 10
    ) AS Top10WithLag
),

SpecificFileValidation AS (
    -- Query 2: Validates that a specific file record exists and meets all criteria.
    -- Returns a single row with 'is_valid' = 1 or 0.
    SELECT
        CASE WHEN COUNT(*) = 1 THEN 1 ELSE 0 END AS is_valid
    FROM
        file_arrival_status fas
    JOIN
        file_master fm ON fm.cadence_id = fas.cadence_id AND fm.feed_id = fas.feed_id
    WHERE
        fas.file_name = 'TC060_claims_part_0001_20250614.csv'
        AND fas.feed_name = 'centura_daily_autotestv6'
        AND fas.client_name = 'regressionv1'
        AND fas.logical_file_name = 'claims'
        AND fas.feed_frequency = 'biweekly'
        AND fm.arrived_flag = 'true' -- Note: This is a string 'true', not a boolean
        AND is_type_casting_success = 'true' -- Note: This is a string 'true'
        AND processed_row_count = source_row_count
)

-- Final Step: Combine the results from the two validation CTEs
SELECT
    CASE
        WHEN dv.is_valid = 1 AND sfv.is_valid = 1 THEN 1
        ELSE 0
    END AS success_flag
FROM
    DateDiffValidation dv,
    SpecificFileValidation sfv