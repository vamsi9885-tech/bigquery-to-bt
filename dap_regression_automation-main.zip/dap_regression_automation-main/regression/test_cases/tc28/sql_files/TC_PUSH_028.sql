SELECT
CASE WHEN COUNT(*) = 1 THEN 1 ELSE 0 END AS success_flag
FROM
file_arrival_status fas
JOIN
file_master fm
ON fm.cadence_id = fas.cadence_id
AND fm.feed_id = fas.feed_id
JOIN
feed_master fem
ON fas.feed_id = fem.feed_id
JOIN
cadence_master cm
ON cm.cadence_id = fas.cadence_id
WHERE
fas.file_name = 'TC028_claims_20240904_part_0001.csv'
AND fas.feed_name = 'centura_daily_autotest'
AND fas.client_name = 'regressionv1'
AND fas.logical_file_name = 'claims'
AND fm.arrived_flag = 't'
AND is_type_casting_success = 't'
AND processed_row_count = source_row_count
AND cm.feed_type = 'push'
AND cm.output_folder_name = '20240904'
AND fem.modified_by = 'adf'
AND fem.created_by = 'adf'
AND fm.failed_row_count = 0
AND fm.adhoc_end_date = '2024-05-15'
AND fm.adhoc_start_date = '2024-04-15'
AND fm.connector = 'epsi_push'
AND fm.start_date = '2024-09-04'
AND fas.file_name_format = '^.*(claims)_(\d{8})_part_([0-9]+).*'
AND fas.extraction_type = 'periodic'
AND fas.feed_frequency = 'daily'
AND fas.is_adhoc_run = 'f'
AND fas.notify_type = 'monthend'
AND fas.window_start_date = '2024-09-04'
AND fas.lag_offset = 0
AND fas.expectation_date = '2024-09-04'
AND fas.lag_tolerance = 0
AND fas.cutoff_date = '2024-09-04'
AND fas.window_end_date = '2024-09-04';