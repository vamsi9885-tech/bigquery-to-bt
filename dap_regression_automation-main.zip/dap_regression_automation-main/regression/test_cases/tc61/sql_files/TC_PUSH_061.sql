SELECT
 CASE WHEN COUNT(*) = 1 THEN 1 ELSE 0 END AS success_flag
FROM
    file_arrival_status fas
JOIN
    file_master fm ON fm.cadence_id = fas.cadence_id AND fm.feed_id = fas.feed_id
WHERE
    fas.file_name = 'TC061_claims_20250702_part_0001.csv'
    AND fas.feed_name = 'centura_monthly_autotestv2'
    AND fas.client_name = 'regressionv1'
    AND fas.logical_file_name = 'claims'
    AND fas.feed_frequency = 'monthly'
    AND fm.arrived_flag = 'true' 
    AND is_type_casting_success = 'true' 
    AND processed_row_count = source_row_count
    AND notify_type = 'once_per_cadence'
    AND yellow_email_start_date = yellow_email_end_date
    AND red_email_start_date = red_email_end_date