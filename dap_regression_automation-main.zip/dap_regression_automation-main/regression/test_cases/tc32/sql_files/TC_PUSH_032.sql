 SELECT 
  CASE WHEN count(distinct fas.feed_id) = 3 THEN 1 ELSE 0 END AS success_flag 
FROM 
  file_arrival_status fas 
  JOIN file_master fm ON fm.cadence_id = fas.cadence_id 
  AND fm.feed_id = fas.feed_id 
WHERE 
  fas.file_name in ('TC032_payers_20240903_part_0001.csv' , 'TC032_devices_20240903_part_001.dat' , 'TC032_claims_20240903_part_001.csv')
  AND fas.feed_name = 'centura_daily_autotest' 
  AND fas.client_name = 'regressionv1' 
  AND fas.logical_file_name in ('payers','devices' , 'claims')
  AND fm.arrived_flag = 'true'
  AND is_type_casting_success = 'true'
  AND processed_row_count = source_row_count 