
# 🧪 RegressionTrigger GitHub Workflow - Overview & Analysis

This workflow automates the PUSH Regression Suite for DAP. It supports both **manual and scheduled** executions, including build of client, upload of data files, db validation via notebook execution, and result collection.

---

## 🚀 Trigger Types

- **Manual Run**: Triggered via `workflow_dispatch` with input parameters.
- **Scheduled Run**: Triggered daily at **12:30 AM UTC** via cron.
- **Push Trigger**: Executes on code pushes to the `main` branch.

---

## 📌 Inputs Accepted

| Input Name             | Description                                           | Default                     |
|------------------------|-------------------------------------------------------|-----------------------------|
| `client_id`            | Client identifier                                     | `regressionv1`              |
| `environment`          | Target environment (dev, qa, integration)            | `qa`                        |
| `client_resource_name` | Resource name (e.g., `hsodev` or `release`)          | `hsodev`                    |
| `specfile_name`        | Name of the specification file (no extension)        | `EIS Modules Requirements`  |
| `release_version`      | Optional release version                             | (empty)                     |
| `include_jar`          | Boolean to include JAR in deployment                 | `true`                      |

---

## ✅ Job-by-Job

### 1. `conditional-run`  
**Purpose**: Prevents execution if the scheduled run is not explicitly allowed.  
- ✅ Skips the workflow when `REGRESSION_AUTOMATION_RUN != true`.

---

### 2. `execute_delete_queries`  
**Purpose**: Cleans up relevant database tables via Azure Function App before test execution.  
- 📂 Reads `clear.json` from repo.  
- 🔄 Executes delete queries like: This is necessary to ensure that we start with clean DB and there is no reference to past runs. 
  - `file_master_delete_query`
  - `cadence_master_delete_query`
  - `feed_master_delete_query`
  - `client_feed_config_delete_query`
---

### 3. `Prerequisites-for-Build`  
**Purpose**: Clears specific ADLS folders and sets up deployment directories.  
- 🔒 Logs in to Azure.  
- ❌ Deletes polished bronze files for specific feeds and dates.
- 🗂 Creates necessary folders for build prep.

---

### 4. `call-build-workflow`  
**Purpose**: Reuses the `Build.yml` workflow from another repo to compile the client artifact.  
- 🧱 Takes in inputs and builds client deployment package.

---

### 5. `upload_files`  
**Purpose**: Expands and uploads selected test case files to Azure Data Lake Storage (ADLS).  
- 📦 Expands files (e.g., to ~1GB) for volume testing.  
- 🔄 Uploads `input_files` to the following path:
  ```
  data/<env>/bronze/<feed>/tarnishedbronze/landed_feed_files/
  ```

---

### 6. `sleep-job`  
**Purpose**: Waits for triggered ADF executions to successfully process the uploaded files.  
- ⏱ Sleeps for **60 minutes** to allow time for completion.

---

### 7. `databricks-notebokok`  
**Purpose**: Executes regression validation logic written in psql in Databricks Notebook to captures results.  
Includes several substeps:

#### ➤ Update Databricks Repo  
- 🔁 Switches repo to current branch.

#### ➤ Trigger Regression Notebook  
- 🎯 Invokes `Regression_Validation` notebook with selected parameters.

#### ➤ Poll for Completion  
- ⏳ Waits until the notebook run finishes (up to 30 mins).
- ✅ Handles job success/failure scenarios with detailed logs.

#### ➤ Fetch and Format Notebook Output  
- 📄 Parses `.notebook_output.result` for:
  - ✅ Test case results
  - ⚙️ ADF pipeline run summary

#### ➤ Upload Markdown Summary  
- 📤 Stores the formatted summary as a GitHub artifact.

---

## 📄 Generated Report Summary

The final output is a **Markdown file (`dap_regression_summary.md`)** containing:

### 🧪 Test Case Report

| Test Case ID | Status  | Description     | Error Message      |
|--------------|---------|------------------|---------------------|
| TC001        | Passed  | Sample test case | N/A                 |
| TC002        | Failed  | Field mismatch   | Missing col 'xyz'   |

---

### ⚙️ ADF Run Report

| File Name              | Run ID | Status | Duration (min) | Message         |
|------------------------|--------|--------|----------------|-----------------|
| devices_20240722.txt   | 2345   | Success| 12             | Completed OK    |
| errorfile_20240722.txt | 2389   | Failed | 3              | Timeout Error   |

---

## 🧠 Summary

This GitHub Actions workflow automates the full regression cycle with:

- 🔄 Cleanup of stale test data  
- 📦 Automated client artifact build  
- 📁 Uploading test case files  
- 🚀 Triggering notebook-based regression logic  
- 📊 Auto-generated markdown report  
