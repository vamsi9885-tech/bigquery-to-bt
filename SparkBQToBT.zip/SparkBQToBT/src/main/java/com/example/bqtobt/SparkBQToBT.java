package com.example.bqtobt;

import com.google.cloud.bigtable.admin.v2.BigtableTableAdminClient;
import com.google.cloud.bigtable.admin.v2.models.CreateTableRequest;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.BigtableDataSettings;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.apache.spark.sql.*;
import org.apache.spark.sql.types.DataTypes;
import org.json.JSONObject;

import java.util.*;

public class SparkBQToBT {

    public static void main(String[] args) throws Exception {
        Map<String, String> argsMap = parseArgs(args);

        SparkSession spark = SparkSession.builder()
            .appName("BigQuery to Bigtable")
            .master("yarn")
            .config("spark.jars.packages", "com.google.cloud.spark:spark-bigquery-with-dependencies_2.12:0.30.0,com.google.cloud.spark:spark-bigtable-with-dependencies_2.12-0.4.0.jar,com.google.cloud.bigtable:bigtable-hbase-2.x-hadoop:2.26.1")
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
            .getOrCreate();

        spark.conf().set("viewsEnabled", "true");
        spark.conf().set("materializationProject", argsMap.get("gear_project_id"));
        spark.conf().set("materializationDataset", "temp");

        JSONObject dictResults = loadJson(argsMap.get("gear_project_id"), argsMap.get("json_file"));
        String catalog = loadCatalog(dictResults, argsMap.get("bt_table_name"));
        createBigtableTable(dictResults, argsMap);

        Dataset<Row> df = fetchBigQueryData(spark, dictResults);
        df = castColumnsToString(df, dictResults);
        exportDataToBigtable(df, catalog, argsMap);
    }

    public static Map<String, String> parseArgs(String[] args) {
        Map<String, String> argsMap = new HashMap<>();
        for (String arg : args) {
            if (arg.startsWith("--")) {
                String[] kv = arg.substring(2).split("=", 2);
                if (kv.length == 2) argsMap.put(kv[0], kv[1]);
            }
        }
        return argsMap;
    }

    public static JSONObject loadJson(String bucketName, String jsonFile) throws Exception {
        Storage storage = StorageOptions.getDefaultInstance().getService();
        Blob blob = storage.get(bucketName, jsonFile);
        String jsonStr = new String(blob.getContent());
        return new JSONObject(jsonStr);
    }

    public static String loadCatalog(JSONObject dictResults, String btTableName) {
        JSONObject catalog = new JSONObject();
        JSONObject table = new JSONObject();
        table.put("name", btTableName);
        table.put("tableCoder", "PrimitiveType");
        catalog.put("table", table);
        catalog.put("rowkey", "bq_rowkey");
        catalog.put("columns", dictResults.getJSONObject("column_mapping"));
        return catalog.toString();
    }

    public static void createBigtableTable(JSONObject dictResults, Map<String, String> argsMap) throws Exception {
        Set<String> columnFamilies = new HashSet<>();
        JSONObject columnMapping = dictResults.getJSONObject("column_mapping");
        for (String key : columnMapping.keySet()) {
            if (!"bq_rowkey".equals(key)) {
                columnFamilies.add(columnMapping.getJSONObject(key).getString("cf"));
            }
        }

        String projectId = argsMap.get("bt_project_name");
        String instanceId = argsMap.get("instance_id");
        String tableId = argsMap.get("bt_table_name");

        try (BigtableTableAdminClient adminClient = BigtableTableAdminClient.create(projectId, instanceId)) {
            if (!adminClient.exists(tableId)) {
                adminClient.createTable(CreateTableRequest.of(tableId));
                for (String cf : columnFamilies) {
                    adminClient.createColumnFamily(tableId, cf);
                }
            }
        }
    }

    public static Dataset<Row> fetchBigQueryData(SparkSession spark, JSONObject dictResults) {
        String query = "SELECT concat(Request_ID,'-',current_date) as bq_rowkey , * FROM `prj-d-gbl-gar-epgear.temp.cars_logs`";
        return spark.read().format("bigquery").option("query", query).load().cache();
    }

    public static Dataset<Row> castColumnsToString(Dataset<Row> df, JSONObject dictResults) {
        JSONObject columnMapping = dictResults.getJSONObject("column_mapping");
        for (String col : columnMapping.keySet()) {
            if (Arrays.asList(df.columns()).contains(col)) {
                df = df.withColumn(col, df.col(col).cast(DataTypes.StringType));
            }
        }
        return df;
    }

    public static void exportDataToBigtable(Dataset<Row> df, String catalog, Map<String, String> argsMap) {
        df.write().format("bigtable")
            .option("catalog", catalog)
            .option("spark.bigtable.project.id", argsMap.get("bt_project_name"))
            .option("spark.bigtable.instance.id", argsMap.get("instance_id"))
            .option("spark.bigtable.enable.batch_mutate.flow_control", "true")
            .option("spark.bigtable.app_profile.id", "gear_load")
            .option("spark.bigtable.create.new.table", "false")
            .save();
    }
}